import React, { useState } from 'react';
import { WeightUnit } from '../types/gym';
import { Language, TRANSLATIONS } from '../utils/i18n';
import { InfinityGymLogo } from './InfinityGymLogo';
import { Play, Timer, Download, Upload, RotateCcw, Flame, Globe, Menu, X as XIcon } from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  weightUnit: WeightUnit;
  onToggleUnit: () => void;
  lang: Language;
  onToggleLanguage: () => void;
  hasActiveWorkout: boolean;
  activeWorkoutDuration: string;
  onOpenActiveWorkout: () => void;
  onStartNewWorkout: () => void;
  onOpenMotivation: () => void;
  onExport: () => void;
  onImport: () => void;
  onReset: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  weightUnit,
  onToggleUnit,
  lang,
  onToggleLanguage,
  hasActiveWorkout,
  activeWorkoutDuration,
  onOpenActiveWorkout,
  onStartNewWorkout,
  onOpenMotivation,
  onExport,
  onImport,
  onReset
}) => {
  const t = TRANSLATIONS[lang];
  const isArabic = lang === 'ar';
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navTabs = [
    { id: 'dashboard', label: t.dashboard, emoji: '🏠' },
    { id: 'routines', label: t.routines, emoji: '📋' },
    { id: 'history', label: t.history, emoji: '📅' },
    { id: 'exercises', label: t.exercises, emoji: '💪' },
    { id: 'analytics', label: t.analytics, emoji: '📊' },
    { id: 'body', label: t.body, emoji: '📏' },
    { id: 'tools', label: t.tools, emoji: '🔧' }
  ];

  const handleTabSelect = (id: string) => {
    setActiveTab(id);
    setMobileMenuOpen(false);
  };

  return (
    <>
      <header className="sticky top-0 z-40 bg-[#0c0d12]/98 backdrop-blur-md border-b border-[#252837] shadow-xl">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 sm:h-20 gap-2">

            {/* Brand Logo */}
            <div
              className="flex items-center gap-2.5 cursor-pointer group flex-shrink-0"
              onClick={() => setActiveTab('dashboard')}
            >
              <div className="p-1 rounded-2xl bg-gradient-to-br from-zinc-800 via-zinc-900 to-black border border-zinc-700/80 shadow-md group-hover:border-zinc-400 transition-all">
                <InfinityGymLogo size="sm" showText={false} />
              </div>

              <div className="flex flex-col">
                <span className="font-black text-base sm:text-xl tracking-wider text-white uppercase" style={{ letterSpacing: '0.08em' }}>
                  {isArabic ? 'إنفينيتي' : 'INFINITY'}
                  <span className="hidden xs:inline">{isArabic ? ' جيم' : ' GYM'}</span>
                </span>
                <p className="text-[10px] sm:text-xs text-zinc-400 hidden sm:block">
                  {t.appSubtitle}
                </p>
              </div>
            </div>

            {/* Center Navigation — desktop only */}
            <nav className="hidden xl:flex items-center gap-1.5 bg-[#14161f] p-1.5 rounded-2xl border border-[#262838]">
              {navTabs.map(tab => {
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`px-3.5 py-2 text-sm font-bold rounded-xl transition-all ${
                      isActive
                        ? 'bg-zinc-800 text-white shadow-sm border border-zinc-650'
                        : 'text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800/60'
                    }`}
                  >
                    {tab.label}
                  </button>
                );
              })}
            </nav>

            {/* Right Action Tools */}
            <div className="flex items-center gap-1.5 sm:gap-2">

              {/* Language Switcher */}
              <button
                onClick={onToggleLanguage}
                className="flex items-center gap-1 px-2.5 sm:px-3 py-1.5 text-xs sm:text-sm font-bold rounded-xl bg-zinc-900 border border-zinc-750 text-zinc-200 hover:bg-zinc-800 hover:border-zinc-500 transition-all"
                title="Switch Language / تغيير اللغة"
              >
                <Globe size={13} className="text-zinc-400 sm:hidden" />
                <Globe size={14} className="text-zinc-400 hidden sm:block" />
                <span className="hidden sm:inline">{isArabic ? 'English' : 'عربي'}</span>
              </button>

              {/* Unit Toggle — hidden on very small screens */}
              <button
                onClick={onToggleUnit}
                title="Toggle Weight Unit"
                className="hidden xs:flex items-center gap-1 px-2.5 sm:px-3 py-1.5 text-xs sm:text-sm font-bold rounded-xl bg-zinc-900 border border-zinc-750 text-zinc-300 hover:bg-zinc-800 hover:border-zinc-500 transition-all"
              >
                <span className={weightUnit === 'kg' ? 'text-white font-extrabold' : 'text-zinc-500'}>KG</span>
                <span className="text-zinc-600">/</span>
                <span className={weightUnit === 'lbs' ? 'text-white font-extrabold' : 'text-zinc-500'}>LBS</span>
              </button>

              {/* Data Tools — desktop only */}
              <div className="hidden lg:flex items-center gap-1">
                <button
                  onClick={onExport}
                  title="Backup data to JSON"
                  className="p-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white hover:border-zinc-600 transition-all text-xs"
                >
                  <Download size={15} />
                </button>
                <button
                  onClick={onImport}
                  title="Restore data from JSON"
                  className="p-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white hover:border-zinc-600 transition-all text-xs"
                >
                  <Upload size={15} />
                </button>
                <button
                  onClick={onReset}
                  title="Reset sample data"
                  className="p-2 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-500 hover:text-zinc-300 hover:border-zinc-600 transition-all text-xs"
                >
                  <RotateCcw size={15} />
                </button>
              </div>

              {/* Active Workout or Start New */}
              {hasActiveWorkout ? (
                <button
                  onClick={onOpenActiveWorkout}
                  className="flex items-center gap-1.5 px-3 sm:px-3.5 py-2 rounded-2xl bg-emerald-500/15 border border-emerald-500/50 text-emerald-300 hover:bg-emerald-500/25 text-xs sm:text-sm font-extrabold animate-pulse transition-all shadow-lg shadow-emerald-500/10"
                >
                  <Timer size={15} className="text-emerald-400" />
                  <span className="font-mono">{activeWorkoutDuration}</span>
                </button>
              ) : (
                <button
                  onClick={onStartNewWorkout}
                  className="flex items-center gap-1.5 px-3 sm:px-5 py-2 rounded-2xl bg-white text-black hover:bg-zinc-200 text-xs sm:text-sm font-black transition-all shadow-lg active:scale-95 min-h-[36px]"
                >
                  <Play size={14} fill="currentColor" />
                  <span className="hidden sm:inline">{t.startWorkout}</span>
                </button>
              )}

              {/* Hamburger — tablet and phone, hidden on xl+ */}
              <button
                onClick={() => setMobileMenuOpen(o => !o)}
                className="xl:hidden flex items-center justify-center w-9 h-9 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-300 hover:text-white hover:border-zinc-500 transition-all"
                title="Menu"
              >
                {mobileMenuOpen ? <XIcon size={18} /> : <Menu size={18} />}
              </button>
            </div>
          </div>

          {/* Slim horizontal scrollable nav — tablet (md–xl) only */}
          <div className="hidden md:flex xl:hidden items-center overflow-x-auto py-2 border-t border-[#1e202d] gap-1 no-scrollbar">
            {navTabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-3.5 py-1.5 rounded-xl whitespace-nowrap transition-all font-bold text-sm flex-shrink-0 ${
                  activeTab === tab.id
                    ? 'bg-zinc-800 text-white shadow-sm'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </header>

      {/* Mobile Full-Screen Drawer Menu (phone only — < md) */}
      {mobileMenuOpen && (
        <div
          className="fixed inset-0 z-50 md:hidden"
          dir={isArabic ? 'rtl' : 'ltr'}
        >
          {/* Backdrop */}
          <div
            className="absolute inset-0 bg-black/70 backdrop-blur-sm"
            onClick={() => setMobileMenuOpen(false)}
          />

          {/* Drawer panel */}
          <div className={`absolute top-0 ${isArabic ? 'right-0' : 'left-0'} h-full w-72 max-w-[85vw] bg-[#0d0e14] border-${isArabic ? 'l' : 'r'} border-[#252837] flex flex-col shadow-2xl`}>
            {/* Drawer header */}
            <div className="flex items-center justify-between p-5 border-b border-[#1e202d]">
              <div className="flex items-center gap-2.5">
                <InfinityGymLogo size="sm" showText={false} />
                <span className="font-black text-lg text-white uppercase tracking-wider">
                  {isArabic ? 'إنفينيتي جيم' : 'INFINITY GYM'}
                </span>
              </div>
              <button
                onClick={() => setMobileMenuOpen(false)}
                className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
              >
                <XIcon size={20} />
              </button>
            </div>

            {/* Nav tabs list */}
            <nav className="flex-1 overflow-y-auto p-4 space-y-1.5">
              {navTabs.map(tab => (
                <button
                  key={tab.id}
                  onClick={() => handleTabSelect(tab.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3.5 rounded-2xl text-start font-bold transition-all text-base ${
                    activeTab === tab.id
                      ? 'bg-zinc-800 text-white border border-zinc-650 shadow'
                      : 'text-zinc-300 hover:bg-zinc-800/60 hover:text-white'
                  }`}
                >
                  <span className="text-xl">{tab.emoji}</span>
                  <span>{tab.label}</span>
                </button>
              ))}
            </nav>

            {/* Drawer footer — extra actions */}
            <div className="p-4 border-t border-[#1e202d] space-y-3">
              {/* Motivation Letter */}
              <button
                onClick={() => { onOpenMotivation(); setMobileMenuOpen(false); }}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl bg-zinc-900 border border-zinc-800 text-zinc-200 hover:border-zinc-500 transition-all font-bold text-sm"
              >
                <Flame size={18} className="text-amber-400" />
                <span>{t.motivationLetter}</span>
              </button>

              {/* Unit toggle */}
              <button
                onClick={onToggleUnit}
                className="w-full flex items-center justify-between px-4 py-3 rounded-2xl bg-zinc-900 border border-zinc-800 text-zinc-200 hover:border-zinc-500 transition-all font-bold text-sm"
              >
                <span>{isArabic ? 'وحدة الوزن' : 'Weight Unit'}</span>
                <span className="font-mono font-black text-white bg-zinc-700 px-2 py-0.5 rounded-lg">{weightUnit.toUpperCase()}</span>
              </button>

              {/* Data management row */}
              <div className="flex items-center gap-2">
                <button onClick={() => { onExport(); setMobileMenuOpen(false); }} title="Backup" className="flex-1 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white transition-all text-xs flex items-center justify-center gap-1.5 font-bold">
                  <Download size={14} />
                  <span>{isArabic ? 'تصدير' : 'Export'}</span>
                </button>
                <button onClick={() => { onImport(); setMobileMenuOpen(false); }} title="Restore" className="flex-1 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white transition-all text-xs flex items-center justify-center gap-1.5 font-bold">
                  <Upload size={14} />
                  <span>{isArabic ? 'استيراد' : 'Import'}</span>
                </button>
                <button onClick={() => { onReset(); setMobileMenuOpen(false); }} title="Reset" className="flex-1 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-500 hover:text-zinc-300 transition-all text-xs flex items-center justify-center gap-1.5 font-bold">
                  <RotateCcw size={14} />
                  <span>{isArabic ? 'إعادة' : 'Reset'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

import { Routine } from '../types/gym';

export const DEFAULT_ROUTINES: Routine[] = [
  {
    id: 'routine-ppl-push',
    name: 'Push: Chest, Delts & Triceps',
    description: 'Hypertrophy and strength focus for pressing muscles. Emphasizes chest development and shoulder mass.',
    targetSplit: 'Push / Pull / Legs',
    estimatedMinutes: 65,
    exercises: [
      { exerciseId: 'ex-bench-press', targetSets: 4, targetReps: '6-8', defaultRestSeconds: 120 },
      { exerciseId: 'ex-incline-db-press', targetSets: 3, targetReps: '8-10', defaultRestSeconds: 90 },
      { exerciseId: 'ex-overhead-press', targetSets: 3, targetReps: '8-10', defaultRestSeconds: 90 },
      { exerciseId: 'ex-db-lateral-raise', targetSets: 4, targetReps: '12-15', defaultRestSeconds: 60 },
      { exerciseId: 'ex-rope-pushdown', targetSets: 3, targetReps: '10-12', defaultRestSeconds: 60 },
      { exerciseId: 'ex-overhead-cable-extension', targetSets: 3, targetReps: '12-15', defaultRestSeconds: 60 }
    ]
  },
  {
    id: 'routine-ppl-pull',
    name: 'Pull: Back & Biceps',
    description: 'Complete back thickness and lat width builder paired with heavy bicep overload.',
    targetSplit: 'Push / Pull / Legs',
    estimatedMinutes: 65,
    exercises: [
      { exerciseId: 'ex-deadlift', targetSets: 3, targetReps: '5', defaultRestSeconds: 180 },
      { exerciseId: 'ex-pullup', targetSets: 3, targetReps: '6-10', defaultRestSeconds: 120 },
      { exerciseId: 'ex-barbell-row', targetSets: 4, targetReps: '8-10', defaultRestSeconds: 90 },
      { exerciseId: 'ex-lat-pulldown', targetSets: 3, targetReps: '10-12', defaultRestSeconds: 90 },
      { exerciseId: 'ex-face-pull', targetSets: 4, targetReps: '15', defaultRestSeconds: 60 },
      { exerciseId: 'ex-barbell-curl', targetSets: 3, targetReps: '8-10', defaultRestSeconds: 75 },
      { exerciseId: 'ex-hammer-curl', targetSets: 3, targetReps: '10-12', defaultRestSeconds: 60 }
    ]
  },
  {
    id: 'routine-ppl-legs',
    name: 'Legs & Core Destroyer',
    description: 'Quad builder, posterior chain development, and athletic core strength.',
    targetSplit: 'Push / Pull / Legs',
    estimatedMinutes: 60,
    exercises: [
      { exerciseId: 'ex-barbell-squat', targetSets: 4, targetReps: '6-8', defaultRestSeconds: 150 },
      { exerciseId: 'ex-romanian-deadlift', targetSets: 4, targetReps: '8-10', defaultRestSeconds: 120 },
      { exerciseId: 'ex-leg-press', targetSets: 3, targetReps: '10-12', defaultRestSeconds: 90 },
      { exerciseId: 'ex-lying-leg-curl', targetSets: 3, targetReps: '10-12', defaultRestSeconds: 60 },
      { exerciseId: 'ex-standing-calf-raise', targetSets: 4, targetReps: '12-15', defaultRestSeconds: 60 },
      { exerciseId: 'ex-hanging-leg-raise', targetSets: 3, targetReps: '12-15', defaultRestSeconds: 60 }
    ]
  },
  {
    id: 'routine-upper-power',
    name: 'Upper Body Power & Hypertrophy',
    description: 'Ideal for 4-day Upper/Lower splits. High compound frequency for maximum upper body development.',
    targetSplit: 'Upper / Lower',
    estimatedMinutes: 60,
    exercises: [
      { exerciseId: 'ex-bench-press', targetSets: 4, targetReps: '5-8', defaultRestSeconds: 120 },
      { exerciseId: 'ex-barbell-row', targetSets: 4, targetReps: '6-8', defaultRestSeconds: 120 },
      { exerciseId: 'ex-overhead-press', targetSets: 3, targetReps: '8-10', defaultRestSeconds: 90 },
      { exerciseId: 'ex-pullup', targetSets: 3, targetReps: '8-10', defaultRestSeconds: 90 },
      { exerciseId: 'ex-skull-crusher', targetSets: 3, targetReps: '10-12', defaultRestSeconds: 60 },
      { exerciseId: 'ex-incline-db-curl', targetSets: 3, targetReps: '10-12', defaultRestSeconds: 60 }
    ]
  },
  {
    id: 'routine-lower-power',
    name: 'Lower Body Strength & Glutes',
    description: 'Heavy squats and hip thrusts for maximum lower body horsepower.',
    targetSplit: 'Upper / Lower',
    estimatedMinutes: 55,
    exercises: [
      { exerciseId: 'ex-barbell-squat', targetSets: 4, targetReps: '5-6', defaultRestSeconds: 150 },
      { exerciseId: 'ex-barbell-hip-thrust', targetSets: 4, targetReps: '8-10', defaultRestSeconds: 120 },
      { exerciseId: 'ex-leg-extension', targetSets: 3, targetReps: '12-15', defaultRestSeconds: 60 },
      { exerciseId: 'ex-lying-leg-curl', targetSets: 3, targetReps: '10-12', defaultRestSeconds: 60 },
      { exerciseId: 'ex-standing-calf-raise', targetSets: 4, targetReps: '15', defaultRestSeconds: 60 }
    ]
  },
  {
    id: 'routine-full-body',
    name: 'Full Body Foundations',
    description: 'Time-efficient full body routine hitting every major muscle group in one session.',
    targetSplit: 'Full Body',
    estimatedMinutes: 50,
    exercises: [
      { exerciseId: 'ex-barbell-squat', targetSets: 3, targetReps: '8', defaultRestSeconds: 120 },
      { exerciseId: 'ex-bench-press', targetSets: 3, targetReps: '8', defaultRestSeconds: 120 },
      { exerciseId: 'ex-seated-cable-row', targetSets: 3, targetReps: '10', defaultRestSeconds: 90 },
      { exerciseId: 'ex-db-lateral-raise', targetSets: 3, targetReps: '12', defaultRestSeconds: 60 },
      { exerciseId: 'ex-rope-pushdown', targetSets: 3, targetReps: '12', defaultRestSeconds: 60 },
      { exerciseId: 'ex-barbell-curl', targetSets: 3, targetReps: '10', defaultRestSeconds: 60 }
    ]
  }
];

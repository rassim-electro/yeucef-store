export type Language = 'en' | 'ar';

export interface Translations {
  // Brand & Slogan
  appName: string;
  appSubtitle: string;
  pcEdition: string;
  heroHeadline: string;
  heroSubheadline: string;
  
  // Navigation
  dashboard: string;
  routines: string;
  history: string;
  exercises: string;
  analytics: string;
  body: string;
  tools: string;
  motivationLetter: string;

  // Actions
  startWorkout: string;
  startEmptyWorkout: string;
  startRoutine: string;
  finishWorkout: string;
  minimize: string;
  cancel: string;
  save: string;
  delete: string;
  addExercise: string;
  addSet: string;
  plateCalc: string;
  oneRmCalc: string;
  overloadAdvisor: string;
  warmupRamp: string;

  // Dashboard Stats
  totalVolume: string;
  cumulativeWeight: string;
  workoutsLogged: string;
  fullSessions: string;
  weeklyStreak: string;
  inPast7Days: string;
  prsAchieved: string;
  recordedPrs: string;
  quickLaunch: string;
  quickLaunchSub: string;
  strengthWall: string;
  strengthWallSub: string;
  gymUtilityTools: string;
  gymUtilityToolsSub: string;
  recentActivity: string;
  coachTip: string;
  coachTipText: string;

  // Table Headers & Exercise
  set: string;
  type: string;
  weight: string;
  reps: string;
  rpe: string;
  done: string;
  completed: string;
  duration: string;
  exercisesCount: string;
  searchPlaceholder: string;
  filterByMuscle: string;
  equipment: string;
  properForm: string;
  executionSteps: string;
  techniqueCues: string;

  // Motivation Letter
  motivationTitle: string;
  motivationSubtitle: string;
  motivationGreeting: string;
  motivationBodyP1: string;
  motivationBodyP2: string;
  motivationRule1Title: string;
  motivationRule1Desc: string;
  motivationRule2Title: string;
  motivationRule2Desc: string;
  motivationRule3Title: string;
  motivationRule3Desc: string;
  motivationClosing: string;
  enterGymBtn: string;
  doNotShowAgain: string;
}

export const TRANSLATIONS: Record<Language, Translations> = {
  en: {
    appName: 'INFINITY GYM',
    appSubtitle: 'Forge Strength • Track Progress • Progressive Overload',
    pcEdition: 'PC Edition',
    heroHeadline: 'WHERE STRENGTH HAS NO LIMITS',
    heroSubheadline: 'Track every pound, master progressive overload, and build an unbreakable physique with laser precision.',

    dashboard: 'Dashboard',
    routines: 'Routines',
    history: 'History',
    exercises: 'Exercise Guide',
    analytics: 'Analytics',
    body: 'Body Tracker',
    tools: 'Calculators',
    motivationLetter: 'Motivation Letter',

    startWorkout: 'Start Workout',
    startEmptyWorkout: 'Start Empty Workout',
    startRoutine: 'Start Routine',
    finishWorkout: 'Finish Workout 🔥',
    minimize: 'Minimize',
    cancel: 'Cancel',
    save: 'Save',
    delete: 'Delete',
    addExercise: 'Add Exercise',
    addSet: 'Add Set',
    plateCalc: 'Plate Calculator',
    oneRmCalc: '1RM Calculator',
    overloadAdvisor: 'Overload Advisor',
    warmupRamp: 'Warm-up Ramp',

    totalVolume: 'Total Volume',
    cumulativeWeight: 'Cumulative weight moved',
    workoutsLogged: 'Workouts Logged',
    fullSessions: 'Full sessions completed',
    weeklyStreak: 'Weekly Streak',
    inPast7Days: 'In the past 7 days',
    prsAchieved: 'PRs Achieved',
    recordedPrs: 'Exercises with personal records',
    quickLaunch: 'Quick Launch Workout Splits',
    quickLaunchSub: 'Choose a proven routine to start logging instantly',
    strengthWall: 'Strength Wall of Fame (PRs)',
    strengthWallSub: 'Your top estimated 1-Rep Max achievements',
    gymUtilityTools: 'Gym Power Tools',
    gymUtilityToolsSub: 'Scientific calculations to optimize every set',
    recentActivity: 'Most Recent Session',
    coachTip: '💡 Coach Rule:',
    coachTipText: 'Progressive Overload is King. Do not just move weight — dominate the eccentric and fight for one extra rep every single week.',

    set: 'Set',
    type: 'Type',
    weight: 'Weight',
    reps: 'Reps',
    rpe: 'RPE',
    done: 'Done',
    completed: 'Completed',
    duration: 'Duration',
    exercisesCount: 'Exercises',
    searchPlaceholder: 'Search exercises by name or muscle...',
    filterByMuscle: 'Filter by muscle group',
    equipment: 'Equipment',
    properForm: 'Proper Execution',
    executionSteps: 'Execution Steps',
    techniqueCues: 'Technique Cues & Form Safeguards',

    motivationTitle: 'THE WARRIOR’S CREED',
    motivationSubtitle: 'A Message to Every Lifter Entering Infinity Gym',
    motivationGreeting: 'Welcome to the Iron Brotherhood.',
    motivationBodyP1: 'When you step into this space, leave excuses at the door. Transformation is not born of casual wishing — it is carved out of cold steel, focused discipline, and the relentless pursuit of progressive overload.',
    motivationBodyP2: 'The iron never lies to you. 100 kilograms is 100 kilograms anywhere on earth. It does not care if you had a bad day, if it is raining, or if you feel tired. When you master the iron, you master your own mind.',
    motivationRule1Title: '1. DISCIPLINE OVER MOTIVATION',
    motivationRule1Desc: 'Motivation is an emotional spark that fades. Discipline is the steel chain that pulls you to the gym when your feelings tell you to stay in bed.',
    motivationRule2Title: '2. THE LAW OF PROGRESSIVE OVERLOAD',
    motivationRule2Desc: 'Do not repeat the exact same weights and reps forever. Demand one more rep. Add 2.5 kg. Make your body adapt through controlled, uncompromising effort.',
    motivationRule3Title: '3. FORM BEFORE EGO',
    motivationRule3Desc: 'Dropping weight to achieve a full, deep stretch and explosive contraction builds 10x more muscle than half-reps with inflated ego weights. Respect your joints.',
    motivationClosing: 'Your future self is waiting on the other side of these sets. Step up, brace your core, and conquer.',
    enterGymBtn: 'Enter the Gym & Crush It 🔥',
    doNotShowAgain: 'Don\'t show this welcome message automatically on startup'
  },
  ar: {
    appName: 'إنفينيتي جيم',
    appSubtitle: 'اصنع قوتك • تتبع تقدمك • التطور التدريجي المستمر',
    pcEdition: 'نسخة الكمبيوتر',
    heroHeadline: 'حيث تنتهي حدود القوة',
    heroSubheadline: 'تتبع كل كيلوغرام ترفعه، طبق مبدأ التطور التدريجي العلمي، وابنِ جسماً قوياً لا يُقهر بدقة متناهية.',

    dashboard: 'لوحة التحكم',
    routines: 'جداول التمارين',
    history: 'سجل التمارين',
    exercises: 'دليل التمارين',
    analytics: 'التحليلات والتقدم',
    body: 'قياسات الجسم',
    tools: 'الحاسبات والأدوات',
    motivationLetter: 'رسالة التحفيز',

    startWorkout: 'ابدأ التمرين',
    startEmptyWorkout: 'تمرين حر جديد',
    startRoutine: 'ابدأ الجدول',
    finishWorkout: 'إنهاء التمرين 🔥',
    minimize: 'تصغير',
    cancel: 'إلغاء',
    save: 'حفظ',
    delete: 'حذف',
    addExercise: 'إضافة تمرين',
    addSet: 'إضافة جولة',
    plateCalc: 'حاسبة الأوزان والبار',
    oneRmCalc: 'حاسبة أقصى وزن 1RM',
    overloadAdvisor: 'مستشار التطور التدريجي',
    warmupRamp: 'مصفوفة الإحماء',

    totalVolume: 'إجمالي الحجم التدريبي',
    cumulativeWeight: 'مجموع الأوزان المرفوعة',
    workoutsLogged: 'التمارين المكتملة',
    fullSessions: 'جلسات تمرين منتهية',
    weeklyStreak: 'سلسلة الأيام الأسبوعية',
    inPast7Days: 'خلال الـ 7 أيام الماضية',
    prsAchieved: 'الأرقام القياسية',
    recordedPrs: 'تمارين تم كسر رقمها القياسي',
    quickLaunch: 'جداول التمارين الجاهزة',
    quickLaunchSub: 'اختر جدولاً مجرباً وابدأ تسجيل جولتك فوراً',
    strengthWall: 'لوحة الشرف للأرقام القياسية',
    strengthWallSub: 'أعلى أوزان تم تحقيقها (تقدير 1-Rep Max)',
    gymUtilityTools: 'أدوات القوة الرياضية',
    gymUtilityToolsSub: 'حسابات رياضية وعلمية لتحسين كل جولة',
    recentActivity: 'آخر تمرين تم إنجازه',
    coachTip: '💡 قاعدة المدرب:',
    coachTipText: 'التطور التدريجي (Progressive Overload) هو سر البناء العضلي. لا ترفع الوزن بعشوائية — تحكم في النزول السلبي وقاتل من أجل تكرار إضافي كل أسبوع.',

    set: 'الجولة',
    type: 'النوع',
    weight: 'الوزن',
    reps: 'التكرارات',
    rpe: 'الجهد (RPE)',
    done: 'تم',
    completed: 'مكتمل',
    duration: 'المدة',
    exercisesCount: 'التمارين',
    searchPlaceholder: 'ابحث عن التمرين بالاسم أو العضلة...',
    filterByMuscle: 'تصفية حسب المجموعة العضلية',
    equipment: 'الأداة المستخدمة',
    properForm: 'التكنيك الصحيح',
    executionSteps: 'خطوات الأداء الصحيحة',
    techniqueCues: 'توجيهات الأداء وحماية المفاصل',

    motivationTitle: 'عهد المحارب الرياضي',
    motivationSubtitle: 'رسالة ملهمة لكل بطل يدخل إنفينيتي جيم',
    motivationGreeting: 'أهلاً بك في عرين الحديد والهمة العالية.',
    motivationBodyP1: 'عندما تخطو بقدميك إلى هذا التطبيق وإلى الصالة الرياضية، اترك الأعذار خلف ظهرك. التغيير الجذري وبناء القوة الحقيقية لا يأتيان بالتمني، بل يُصنعان من الإصرار والالتزام ومواجهة الحديد البارد بلا تردد.',
    motivationBodyP2: 'الحديد لا يكذب أبداً. وزن 100 كيلوغرام يظل 100 كيلوغرام في أي مكان على وجه الأرض. لا يهتم إن كنت متعباً أو إن كان يومك شاقاً. عندما تنتصر على الحديد، تنتصر على ضعفك وتبني عقليتك قبل عضلاتك.',
    motivationRule1Title: '١. الانضباط قبل الحماس والشعور',
    motivationRule1Desc: 'الحماس شعلة سريعة الانطفاء. أما الانضباط فهو العهد الذي يوقظك ويقودك للتمرين عندما يخبرك عقلك بالكسل والنوم.',
    motivationRule2Title: '٢. قانون التطور التدريجي الإلزامي',
    motivationRule2Desc: 'إياك أن تكرر نفس الأوزان والتكرارات لشهور. اطلب من عضلاتك تكراراً إضافياً، أو أضف 2.5 كيلوغرام. هذا هو المفتاح العلمي الوحيد لنمو الألياف العضلية.',
    motivationRule3Title: '٣. التكنيك الصحيح قبل الغرور',
    motivationRule3Desc: 'إنقاص الوزن من أجل مدى حركي كامل وانقباض عضلي عميق يبني عضلات أقوى بعشر مرات من نصف رفعة متهورة تؤذي المفاصل.',
    motivationClosing: 'نسختك الأقوى والأفضل تنتظرك بعد هذه الجولات. تنفس بعمق، استجمع تركيزك، وكن لا يُقهر.',
    enterGymBtn: 'ادخل الصالة وابدأ التحدي 🔥',
    doNotShowAgain: 'عدم إظهار هذه الرسالة تلقائياً عند فتح التطبيق'
  }
};

const LANG_KEY = 'infinity_gym_lang_v1';
const MOTIVATION_SEEN_KEY = 'infinity_gym_hide_motivation_v1';

export function loadLanguage(): Language {
  try {
    const val = localStorage.getItem(LANG_KEY);
    return val === 'ar' ? 'ar' : 'en';
  } catch {
    return 'en';
  }
}

export function saveLanguage(lang: Language) {
  try {
    localStorage.setItem(LANG_KEY, lang);
  } catch (e) {
    console.error('Failed to save language', e);
  }
}

export function loadHideMotivation(): boolean {
  try {
    return localStorage.getItem(MOTIVATION_SEEN_KEY) === 'true';
  } catch {
    return false;
  }
}

export function saveHideMotivation(hide: boolean) {
  try {
    localStorage.setItem(MOTIVATION_SEEN_KEY, hide ? 'true' : 'false');
  } catch (e) {
    console.error('Failed to save motivation preference', e);
  }
}

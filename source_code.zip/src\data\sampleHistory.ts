import { CompletedWorkout, BodyMeasurement } from '../types/gym';

export const SAMPLE_WORKOUTS: CompletedWorkout[] = [
  {
    id: 'wk-sample-1',
    name: 'Push: Chest, Delts & Triceps',
    routineId: 'routine-ppl-push',
    startTime: new Date(Date.now() - 1000 * 60 * 60 * 24 * 6).toISOString(),
    endTime: new Date(Date.now() - 1000 * 60 * 60 * 24 * 6 + 1000 * 60 * 62).toISOString(),
    durationMinutes: 62,
    totalVolume: 5240,
    prsAchieved: 1,
    notes: 'Felt strong on bench press today! Paused slightly at the chest.',
    exercises: [
      {
        exerciseId: 'ex-bench-press',
        exerciseName: 'Barbell Bench Press',
        muscleGroup: 'Chest',
        sets: [
          { id: 's1', setNumber: 1, type: 'Warmup', weight: 40, reps: 10, completed: true },
          { id: 's2', setNumber: 2, type: 'Normal', weight: 70, reps: 8, completed: true, rpe: 7 },
          { id: 's3', setNumber: 3, type: 'Normal', weight: 75, reps: 8, completed: true, rpe: 8 },
          { id: 's4', setNumber: 4, type: 'Normal', weight: 80, reps: 6, completed: true, rpe: 9 }
        ]
      },
      {
        exerciseId: 'ex-incline-db-press',
        exerciseName: 'Incline Dumbbell Press',
        muscleGroup: 'Chest',
        sets: [
          { id: 's5', setNumber: 1, type: 'Normal', weight: 26, reps: 10, completed: true, rpe: 8 },
          { id: 's6', setNumber: 2, type: 'Normal', weight: 28, reps: 8, completed: true, rpe: 8.5 },
          { id: 's7', setNumber: 3, type: 'Normal', weight: 28, reps: 8, completed: true, rpe: 9 }
        ]
      },
      {
        exerciseId: 'ex-db-lateral-raise',
        exerciseName: 'Dumbbell Lateral Raise',
        muscleGroup: 'Shoulders',
        sets: [
          { id: 's8', setNumber: 1, type: 'Normal', weight: 12, reps: 15, completed: true },
          { id: 's9', setNumber: 2, type: 'Normal', weight: 12, reps: 14, completed: true },
          { id: 's10', setNumber: 3, type: 'Normal', weight: 12, reps: 12, completed: true }
        ]
      },
      {
        exerciseId: 'ex-rope-pushdown',
        exerciseName: 'Tricep Rope Pushdown',
        muscleGroup: 'Triceps',
        sets: [
          { id: 's11', setNumber: 1, type: 'Normal', weight: 25, reps: 12, completed: true },
          { id: 's12', setNumber: 2, type: 'Normal', weight: 27.5, reps: 10, completed: true }
        ]
      }
    ]
  },
  {
    id: 'wk-sample-2',
    name: 'Pull: Back & Biceps',
    routineId: 'routine-ppl-pull',
    startTime: new Date(Date.now() - 1000 * 60 * 60 * 24 * 4).toISOString(),
    endTime: new Date(Date.now() - 1000 * 60 * 60 * 24 * 4 + 1000 * 60 * 65).toISOString(),
    durationMinutes: 65,
    totalVolume: 6180,
    prsAchieved: 2,
    notes: 'Hit 130kg on deadlift for 5 reps clean. Great lat pump on pulldowns.',
    exercises: [
      {
        exerciseId: 'ex-deadlift',
        exerciseName: 'Conventional Barbell Deadlift',
        muscleGroup: 'Back',
        sets: [
          { id: 's13', setNumber: 1, type: 'Warmup', weight: 70, reps: 8, completed: true },
          { id: 's14', setNumber: 2, type: 'Normal', weight: 110, reps: 5, completed: true, rpe: 7 },
          { id: 's15', setNumber: 3, type: 'Normal', weight: 120, reps: 5, completed: true, rpe: 8 },
          { id: 's16', setNumber: 4, type: 'Normal', weight: 130, reps: 5, completed: true, rpe: 9 }
        ]
      },
      {
        exerciseId: 'ex-lat-pulldown',
        exerciseName: 'Lat Pulldown',
        muscleGroup: 'Back',
        sets: [
          { id: 's17', setNumber: 1, type: 'Normal', weight: 65, reps: 10, completed: true },
          { id: 's18', setNumber: 2, type: 'Normal', weight: 70, reps: 10, completed: true },
          { id: 's19', setNumber: 3, type: 'Normal', weight: 70, reps: 8, completed: true }
        ]
      },
      {
        exerciseId: 'ex-barbell-curl',
        exerciseName: 'Barbell Bicep Curl',
        muscleGroup: 'Biceps',
        sets: [
          { id: 's20', setNumber: 1, type: 'Normal', weight: 30, reps: 10, completed: true },
          { id: 's21', setNumber: 2, type: 'Normal', weight: 32.5, reps: 8, completed: true }
        ]
      }
    ]
  },
  {
    id: 'wk-sample-3',
    name: 'Legs & Core Destroyer',
    routineId: 'routine-ppl-legs',
    startTime: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2).toISOString(),
    endTime: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2 + 1000 * 60 * 58).toISOString(),
    durationMinutes: 58,
    totalVolume: 5890,
    prsAchieved: 1,
    notes: 'Deep squats, focused on knee alignment and full hip extension.',
    exercises: [
      {
        exerciseId: 'ex-barbell-squat',
        exerciseName: 'Barbell Back Squat',
        muscleGroup: 'Quads',
        sets: [
          { id: 's22', setNumber: 1, type: 'Warmup', weight: 60, reps: 10, completed: true },
          { id: 's23', setNumber: 2, type: 'Normal', weight: 95, reps: 8, completed: true, rpe: 7.5 },
          { id: 's24', setNumber: 3, type: 'Normal', weight: 102.5, reps: 6, completed: true, rpe: 8.5 },
          { id: 's25', setNumber: 4, type: 'Normal', weight: 105, reps: 6, completed: true, rpe: 9 }
        ]
      },
      {
        exerciseId: 'ex-romanian-deadlift',
        exerciseName: 'Romanian Deadlift (RDL)',
        muscleGroup: 'Hamstrings',
        sets: [
          { id: 's26', setNumber: 1, type: 'Normal', weight: 80, reps: 10, completed: true },
          { id: 's27', setNumber: 2, type: 'Normal', weight: 85, reps: 8, completed: true }
        ]
      },
      {
        exerciseId: 'ex-standing-calf-raise',
        exerciseName: 'Standing Calf Raise',
        muscleGroup: 'Calves',
        sets: [
          { id: 's28', setNumber: 1, type: 'Normal', weight: 75, reps: 15, completed: true },
          { id: 's29', setNumber: 2, type: 'Normal', weight: 80, reps: 12, completed: true }
        ]
      }
    ]
  }
];

export const SAMPLE_MEASUREMENTS: BodyMeasurement[] = [
  {
    id: 'bm-1',
    date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 21).toISOString().split('T')[0],
    weight: 79.4,
    bodyFatPercent: 16.5,
    chestCm: 102,
    waistCm: 84,
    armsCm: 37.5,
    thighsCm: 59,
    notes: 'Starting baseline measurement'
  },
  {
    id: 'bm-2',
    date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 14).toISOString().split('T')[0],
    weight: 79.0,
    bodyFatPercent: 16.1,
    chestCm: 102.5,
    waistCm: 83.5,
    armsCm: 37.8,
    thighsCm: 59.2,
    notes: 'Good progress, calories on point'
  },
  {
    id: 'bm-3',
    date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 7).toISOString().split('T')[0],
    weight: 78.5,
    bodyFatPercent: 15.6,
    chestCm: 103,
    waistCm: 82.5,
    armsCm: 38.0,
    thighsCm: 59.5,
    notes: 'Waist down, chest and arms up!'
  },
  {
    id: 'bm-4',
    date: new Date().toISOString().split('T')[0],
    weight: 78.2,
    bodyFatPercent: 15.2,
    chestCm: 103.5,
    waistCm: 82.0,
    armsCm: 38.2,
    thighsCm: 60.0,
    notes: 'Leaning out while building lean mass'
  }
];

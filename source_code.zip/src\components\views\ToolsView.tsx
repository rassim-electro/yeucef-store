import React, { useState } from 'react';
import { WeightUnit } from '../../types/gym';
import { calculate1RM, calculatePlates } from '../../utils/calculators';
import {
  Award,
  Layers,
  Flame,
  Activity,
  ArrowRight,
  TrendingUp,
  ShieldCheck,
  Zap
} from 'lucide-react';

interface ToolsViewProps {
  weightUnit: WeightUnit;
}

export const ToolsView: React.FC<ToolsViewProps> = ({ weightUnit }) => {
  const [activeTool, setActiveTool] = useState<'1rm' | 'plate' | 'warmup'>('1rm');

  // 1RM tool states
  const [rmWeight, setRmWeight] = useState(85);
  const [rmReps, setRmReps] = useState(6);

  // Plate tool states
  const [targetWeight, setTargetWeight] = useState(100);
  const [barWeight, setBarWeight] = useState(weightUnit === 'kg' ? 20 : 45);

  // Warmup tool states
  const [workWeight, setWorkWeight] = useState(100);

  const rmResult = calculate1RM(rmWeight, rmReps);
  const plateResult = calculatePlates(targetWeight, weightUnit, barWeight);

  const emptyBar = weightUnit === 'kg' ? 20 : 45;
  const warmupStages = [
    {
      stage: 'Set 1: Barbell Only',
      weight: emptyBar,
      reps: '10-15 reps',
      purpose: 'Synovial fluid lubrication & groove patterning'
    },
    {
      stage: 'Set 2: Light Warmup',
      weight: Math.round(((workWeight * 0.5) / 2.5)) * 2.5,
      reps: '5 reps',
      purpose: 'Muscle fiber recruitment'
    },
    {
      stage: 'Set 3: Moderate Acclimation',
      weight: Math.round(((workWeight * 0.7) / 2.5)) * 2.5,
      reps: '3 reps',
      purpose: 'Neuromuscular readiness without accumulating lactic acid'
    },
    {
      stage: 'Set 4: Heavy Potentiation',
      weight: Math.round(((workWeight * 0.9) / 2.5)) * 2.5,
      reps: '1 rep',
      purpose: 'High-threshold motor unit activation right before work sets'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl sm:text-3xl font-black text-white uppercase tracking-wider">
          Gym Power Calculators
        </h2>
        <p className="text-sm text-zinc-400">
          Precision barbell mathematics, maximal strength estimation, and warmup ramps
        </p>
      </div>

      {/* Tabs */}
      <div className="flex gap-2.5 border-b border-[#242637] pb-3 overflow-x-auto no-scrollbar">
        {[
          { id: '1rm', label: '1-Rep Max Calculator', icon: Award },
          { id: 'plate', label: 'Plate Math & Sleeve Loader', icon: Layers },
          { id: 'warmup', label: 'Warm-up Ramp Generator', icon: ShieldCheck }
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTool === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTool(tab.id as '1rm' | 'plate' | 'warmup')}
              className={`flex items-center gap-2.5 px-5 py-2.5 rounded-2xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-zinc-800 text-white border border-zinc-650 shadow-md'
                  : 'bg-[#121319] text-zinc-400 hover:text-white border border-[#232535]'
              }`}
            >
              <Icon size={16} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TOOL 1: 1RM Calculator */}
      {activeTool === '1rm' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="bg-[#121319] border border-[#262837] rounded-3xl p-6 sm:p-7 space-y-5 shadow-xl">
            <h3 className="text-base sm:text-lg font-black text-white uppercase tracking-wider">
              Enter Recent Lift
            </h3>
            <div>
              <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
                Weight ({weightUnit})
              </label>
              <input
                type="number"
                step="2.5"
                value={rmWeight || ''}
                onChange={e => setRmWeight(parseFloat(e.target.value) || 0)}
                className="w-full bg-[#181924] border border-[#2d2f40] rounded-2xl px-4 py-3 text-white font-mono text-xl font-black focus:outline-none focus:border-zinc-400"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
                Repetitions
              </label>
              <input
                type="number"
                min="1"
                max="30"
                value={rmReps || ''}
                onChange={e => setRmReps(parseInt(e.target.value) || 1)}
                className="w-full bg-[#181924] border border-[#2d2f40] rounded-2xl px-4 py-3 text-white font-mono text-xl font-black focus:outline-none focus:border-zinc-400"
              />
            </div>

            <div className="p-5 rounded-2xl bg-gradient-to-br from-zinc-850 to-black border border-zinc-700/80 text-center shadow-lg">
              <span className="text-xs font-bold text-zinc-400 uppercase tracking-widest block mb-1">
                Calculated 1-Rep Max
              </span>
              <div className="text-4xl sm:text-5xl font-black font-mono text-white">
                {rmResult.average} <span className="text-2xl font-light text-zinc-400">{weightUnit}</span>
              </div>
            </div>
          </div>

          <div className="lg:col-span-2 bg-[#121319] border border-[#262837] rounded-3xl p-6 sm:p-7 space-y-4 shadow-xl">
            <h3 className="text-base sm:text-lg font-black text-white uppercase tracking-wider">
              Target Training Percentages & Rep Goals
            </h3>
            <div className="border border-[#262837] rounded-2xl overflow-hidden bg-[#151620]">
              <table className="w-full text-left text-xs sm:text-sm">
                <thead>
                  <tr className="bg-[#1b1c28] text-zinc-400 text-xs uppercase tracking-wider border-b border-[#262837]">
                    <th className="py-3 px-4">Intensity</th>
                    <th className="py-3 px-4">Load ({weightUnit})</th>
                    <th className="py-3 px-4">Rep Target</th>
                    <th className="py-3 px-4 hidden sm:table-cell">Training Goal</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#202230]">
                  {rmResult.percentages.map(p => (
                    <tr key={p.percentage} className="hover:bg-[#1a1c29]">
                      <td className="py-2.5 px-4 font-mono font-bold text-zinc-300">{p.percentage}%</td>
                      <td className="py-2.5 px-4 font-mono font-black text-white text-base">{p.weight} {weightUnit}</td>
                      <td className="py-2.5 px-4 text-zinc-200 font-semibold">{p.repsRange}</td>
                      <td className="py-2.5 px-4 text-zinc-400 text-xs hidden sm:table-cell">{p.focus}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TOOL 2: Plate Calculator */}
      {activeTool === 'plate' && (
        <div className="bg-[#121319] border border-[#262837] rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
            <div>
              <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
                Target Barbell Weight ({weightUnit})
              </label>
              <input
                type="number"
                step="2.5"
                value={targetWeight || ''}
                onChange={e => setTargetWeight(parseFloat(e.target.value) || 0)}
                className="w-full bg-[#181924] border border-[#2d2f40] rounded-2xl px-4 py-3 text-white font-mono text-2xl font-black focus:outline-none focus:border-zinc-400"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
                Barbell Type
              </label>
              <select
                value={barWeight}
                onChange={e => setBarWeight(parseFloat(e.target.value))}
                className="w-full bg-[#181924] border border-[#2d2f40] rounded-2xl px-4 py-3 text-white text-sm font-semibold focus:outline-none"
              >
                {weightUnit === 'kg' ? (
                  <>
                    <option value={20}>Standard Olympic Bar (20 kg)</option>
                    <option value={15}>Women / Technique Bar (15 kg)</option>
                    <option value={10}>EZ Curl Bar (10 kg)</option>
                  </>
                ) : (
                  <>
                    <option value={45}>Standard Olympic Bar (45 lbs)</option>
                    <option value={35}>Women / Technique Bar (35 lbs)</option>
                    <option value={25}>EZ Curl Bar (25 lbs)</option>
                  </>
                )}
              </select>
            </div>
          </div>

          {/* Sleeve visualization */}
          <div className="bg-[#0b0c10] border border-[#242636] rounded-3xl p-6">
            <div className="flex items-center justify-between text-xs sm:text-sm text-zinc-400 mb-4">
              <span className="font-bold uppercase tracking-wider">Per-Side Loading Graphic</span>
              <span className="font-mono text-white font-black text-base">{plateResult.weightPerSide} {weightUnit} each side</span>
            </div>

            <div className="flex items-center min-h-[100px] px-4 py-5 bg-[#14151e] rounded-2xl border border-[#20222f] overflow-x-auto">
              <div className="h-4 w-16 bg-zinc-600 rounded-l flex-shrink-0" />
              <div className="h-16 w-4 bg-zinc-400 rounded-sm flex-shrink-0 border-r border-zinc-700" />

              {plateResult.platesPerSide.length === 0 ? (
                <span className="text-zinc-500 text-sm italic ml-4">Empty barbell shaft</span>
              ) : (
                <div className="flex items-center gap-1.5 ml-1 flex-shrink-0">
                  {plateResult.platesPerSide.flatMap(plate =>
                    Array.from({ length: plate.count }).map((_, idx) => (
                      <div
                        key={`${plate.weight}-${idx}`}
                        className="h-20 w-5 rounded-sm flex items-center justify-center font-mono font-black text-[10px] text-white shadow-md border border-white/20"
                        style={{ backgroundColor: plate.color }}
                        title={`${plate.weight} ${weightUnit}`}
                      >
                        <span className="rotate-90 select-none">{plate.weight}</span>
                      </div>
                    ))
                  )}
                </div>
              )}
              <div className="h-3 w-20 bg-zinc-700 rounded-r flex-shrink-0 ml-1" />
            </div>
          </div>

          {/* Plates per side */}
          <div>
            <span className="text-xs font-bold text-zinc-300 uppercase tracking-wider block mb-2.5">
              Plates to Put on Each Side:
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
              {plateResult.platesPerSide.map(plate => (
                <div
                  key={plate.weight}
                  className="p-3.5 rounded-2xl bg-[#171824] border border-[#262838] flex items-center justify-between"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="w-4 h-4 rounded-full" style={{ backgroundColor: plate.color }} />
                    <span className="text-sm font-black text-white font-mono">{plate.weight} {weightUnit}</span>
                  </div>
                  <span className="text-xs sm:text-sm font-extrabold text-white font-mono bg-zinc-800 px-2.5 py-1 rounded-lg border border-zinc-700">
                    × {plate.count}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TOOL 3: Warmup Ramp Generator */}
      {activeTool === 'warmup' && (
        <div className="bg-[#121319] border border-[#262837] rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
          <div className="max-w-md">
            <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
              Working Set Target Weight ({weightUnit})
            </label>
            <input
              type="number"
              step="2.5"
              value={workWeight || ''}
              onChange={e => setWorkWeight(parseFloat(e.target.value) || 0)}
              className="w-full bg-[#181924] border border-[#2d2f40] rounded-2xl px-4 py-3 text-white font-mono text-2xl font-black focus:outline-none"
            />
            <p className="text-xs text-zinc-400 mt-2">
              Warm-up sets prime your nervous system and joint capsules without inducing metabolic fatigue.
            </p>
          </div>

          <div className="space-y-3.5">
            {warmupStages.map((stage, idx) => (
              <div
                key={idx}
                className="p-4 sm:p-5 rounded-2xl bg-[#161824] border border-[#262838] flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div>
                  <div className="flex items-center gap-2.5">
                    <span className="w-6 h-6 rounded-full bg-zinc-800 border border-zinc-700 font-mono text-xs font-bold text-zinc-300 flex items-center justify-center">
                      {idx + 1}
                    </span>
                    <h4 className="text-sm sm:text-base font-extrabold text-white">{stage.stage}</h4>
                  </div>
                  <p className="text-xs text-zinc-400 mt-1 ml-8">{stage.purpose}</p>
                </div>

                <div className="ml-8 sm:ml-0 flex items-center gap-4">
                  <span className="font-mono text-lg font-black text-white">
                    {stage.weight} {weightUnit}
                  </span>
                  <span className="font-mono text-xs font-bold text-zinc-300 bg-zinc-800 px-3 py-1 rounded-lg border border-zinc-700">
                    {stage.reps}
                  </span>
                </div>
              </div>
            ))}

            <div className="p-5 rounded-2xl bg-emerald-950/20 border border-emerald-500/40 flex items-center justify-between">
              <div>
                <h4 className="text-sm sm:text-base font-black text-emerald-400">🔥 Ready for Working Sets!</h4>
                <p className="text-xs text-zinc-300 mt-0.5">
                  Rest 2 minutes, then perform your programmed working sets with full intensity.
                </p>
              </div>
              <span className="font-mono text-xl font-black text-white">
                {workWeight} {weightUnit}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

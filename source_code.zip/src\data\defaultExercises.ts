import { ExerciseDefinition } from '../types/gym';

export const DEFAULT_EXERCISES: ExerciseDefinition[] = [
  // CHEST
  {
    id: 'ex-bench-press',
    name: 'Barbell Bench Press',
    muscleGroup: 'Chest',
    secondaryMuscles: ['Triceps', 'Front Delts'],
    equipment: 'Barbell',
    defaultRestSeconds: 120,
    instructions: [
      'Lie flat on the bench with eyes directly below the barbell.',
      'Grip the bar slightly wider than shoulder width with thumbs wrapped.',
      'Unrack, tuck shoulder blades down and back, arch lower back slightly.',
      'Lower the bar with control to your mid-chest right above nipples.',
      'Drive feet into the ground and press up until arms lock out.'
    ],
    tips: [
      'Keep wrists straight and elbows tucked at roughly 45 to 70 degrees.',
      'Do not bounce the bar off your chest.'
    ]
  },
  {
    id: 'ex-incline-db-press',
    name: 'Incline Dumbbell Press',
    muscleGroup: 'Chest',
    secondaryMuscles: ['Front Delts', 'Triceps'],
    equipment: 'Dumbbell',
    defaultRestSeconds: 90,
    instructions: [
      'Set bench to a 30-degree incline.',
      'Kick dumbbells up to your shoulders using your knees.',
      'Retract your scapula and press dumbbells up, converging slightly at the top without clanking.',
      'Lower under control until you feel a deep stretch in the upper pecs.'
    ],
    tips: [
      'Do not set bench above 45 degrees to avoid shifting load to front shoulders.',
      'Keep feet flat and core braced.'
    ]
  },
  {
    id: 'ex-chest-dips',
    name: 'Chest Dips',
    muscleGroup: 'Chest',
    secondaryMuscles: ['Triceps', 'Shoulders'],
    equipment: 'Bodyweight',
    defaultRestSeconds: 90,
    instructions: [
      'Grip parallel dip bars and hoist yourself up.',
      'Lean your torso forward 20-30 degrees and tuck chin slightly.',
      'Lower until your upper arms are parallel to the floor.',
      'Push back up forcefully, squeezing pecs at the top.'
    ],
    tips: ['Cross feet and keep elbows slightly flared for chest focus.']
  },
  {
    id: 'ex-cable-crossover',
    name: 'Cable Fly / Crossover',
    muscleGroup: 'Chest',
    secondaryMuscles: ['Front Delts'],
    equipment: 'Cable',
    defaultRestSeconds: 60,
    instructions: [
      'Position cables at chest height or slightly higher.',
      'Step forward with one foot for stability, arms out with slight elbow bend.',
      'Bring hands together in a hugging motion, crossing or touching in front of chest.',
      'Slowly return to starting position with full stretch.'
    ],
    tips: ['Keep constant tension on the chest throughout the movement.']
  },

  // BACK
  {
    id: 'ex-deadlift',
    name: 'Conventional Barbell Deadlift',
    muscleGroup: 'Back',
    secondaryMuscles: ['Glutes', 'Hamstrings', 'Core', 'Traps'],
    equipment: 'Barbell',
    defaultRestSeconds: 180,
    instructions: [
      'Stand with mid-foot directly beneath the barbell, hip-width stance.',
      'Hinge hips back, grip bar right outside knees with straight arms.',
      'Pull slack out of the bar, brace core, flatten back, and pack lats.',
      'Drive through the floor, extending hips and knees simultaneously.',
      'Stand tall without hyperextending lower back at lockout.'
    ],
    tips: [
      'The barbell must travel in a strict vertical line hugging the shins and thighs.',
      'Never round lower back under heavy loads.'
    ]
  },
  {
    id: 'ex-barbell-row',
    name: 'Barbell Bent-Over Row',
    muscleGroup: 'Back',
    secondaryMuscles: ['Biceps', 'Rear Delts', 'Forearms'],
    equipment: 'Barbell',
    defaultRestSeconds: 120,
    instructions: [
      'Hinge forward at roughly a 45-degree angle with knees soft.',
      'Grip bar with overhand or underhand grip.',
      'Pull bar towards lower abdomen / belly button by driving elbows back.',
      'Squeeze shoulder blades together tightly at top for 1 second.',
      'Lower bar slowly until arms are fully extended.'
    ],
    tips: ['Do not use excessive hip momentum to heave the weight.']
  },
  {
    id: 'ex-lat-pulldown',
    name: 'Lat Pulldown',
    muscleGroup: 'Back',
    secondaryMuscles: ['Biceps', 'Rear Delts'],
    equipment: 'Cable',
    defaultRestSeconds: 90,
    instructions: [
      'Adjust thigh pad snug against knees.',
      'Grip wide bar with overhand grip wider than shoulder width.',
      'Lean back slightly (10-15 degrees) and pull bar towards upper chest.',
      'Drive elbows down towards hips, squeezing lats at contraction.',
      'Control the ascent for a full stretch at the top.'
    ],
    tips: ['Avoid rocking back and forth; initiate pull with lats, not arms.']
  },
  {
    id: 'ex-pullup',
    name: 'Pull-Up',
    muscleGroup: 'Back',
    secondaryMuscles: ['Biceps', 'Forearms', 'Core'],
    equipment: 'Bodyweight',
    defaultRestSeconds: 120,
    instructions: [
      'Hang from bar with hands slightly wider than shoulders, overhand grip.',
      'Depress shoulder blades and pull chest up towards the bar.',
      'Clear chin over the bar, hold briefly, then lower slowly to full hang.'
    ],
    tips: ['Full range of motion: dead hang to chin over bar.']
  },
  {
    id: 'ex-seated-cable-row',
    name: 'Seated Cable Row',
    muscleGroup: 'Back',
    secondaryMuscles: ['Biceps', 'Rhomboids', 'Rear Delts'],
    equipment: 'Cable',
    defaultRestSeconds: 90,
    instructions: [
      'Sit upright with knees slightly bent, feet on footrests.',
      'Grip V-bar handle, keep chest proud and back neutral.',
      'Pull handle into lower sternum while pinching shoulder blades together.',
      'Extend arms slowly under resistance.'
    ],
    tips: ['Keep torso steady, do not swing excessively back and forth.']
  },

  // SHOULDERS
  {
    id: 'ex-overhead-press',
    name: 'Barbell Overhead Press (OHP)',
    muscleGroup: 'Shoulders',
    secondaryMuscles: ['Triceps', 'Upper Chest', 'Core'],
    equipment: 'Barbell',
    defaultRestSeconds: 120,
    instructions: [
      'Rack bar at collarbone height. Grip bar just outside shoulders.',
      'Squeeze glutes, brace abs, and unrack bar resting on front delts.',
      'Press straight up, tucking head slightly back to let bar pass chin.',
      'Push head forward through window once bar clears forehead, locking out overhead.'
    ],
    tips: [
      'Keep glutes clenched hard to safeguard the lower back.',
      'Bar path should be strictly vertical.'
    ]
  },
  {
    id: 'ex-db-lateral-raise',
    name: 'Dumbbell Lateral Raise',
    muscleGroup: 'Shoulders',
    secondaryMuscles: ['Traps'],
    equipment: 'Dumbbell',
    defaultRestSeconds: 60,
    instructions: [
      'Stand tall holding dumbbells by sides, slight bend in elbows.',
      'Raise arms out to sides in scapular plane (slightly forward).',
      'Lift until dumbbells are parallel with shoulders (lead with elbows).',
      'Lower slowly over 2-3 seconds.'
    ],
    tips: [
      'Do not swing or shrug shoulders up to ears. Keep traps relaxed.',
      'Progress by adding reps and controlled tempo.'
    ]
  },
  {
    id: 'ex-face-pull',
    name: 'Cable Face Pull',
    muscleGroup: 'Shoulders',
    secondaryMuscles: ['Rear Delts', 'Rotator Cuff', 'Upper Back'],
    equipment: 'Cable',
    defaultRestSeconds: 60,
    instructions: [
      'Attach rope handle at eye height.',
      'Grip rope with thumbs pointed backwards.',
      'Pull rope towards forehead while rotating hands back and flaring elbows high.',
      'Pause for 1 second at full contraction, then control back.'
    ],
    tips: ['Essential exercise for shoulder health and posture.']
  },

  // LEGS - QUADS
  {
    id: 'ex-barbell-squat',
    name: 'Barbell Back Squat',
    muscleGroup: 'Quads',
    secondaryMuscles: ['Glutes', 'Hamstrings', 'Core', 'Lower Back'],
    equipment: 'Barbell',
    defaultRestSeconds: 180,
    instructions: [
      'Rest barbell across upper traps (high bar) or rear delts (low bar).',
      'Unrack, take 2-3 steps back, feet shoulder-width, toes slightly out.',
      'Take deep breath into belly, brace core hard.',
      'Sit hips back and down, keeping knees tracking over toes.',
      'Descend until thighs are at least parallel to the floor.',
      'Drive through whole foot to stand back up powerfully.'
    ],
    tips: [
      'Keep chest elevated and maintain neutral spine throughout.',
      'Never let knees cave inward on ascent.'
    ]
  },
  {
    id: 'ex-leg-press',
    name: 'Leg Press',
    muscleGroup: 'Quads',
    secondaryMuscles: ['Glutes', 'Hamstrings'],
    equipment: 'Machine',
    defaultRestSeconds: 120,
    instructions: [
      'Sit back against machine with lower back pressed firmly into pad.',
      'Place feet shoulder-width in middle of platform.',
      'Release safety handles, lower weight until knees reach 90 degrees.',
      'Press through mid-foot and heels to return, stopping just shy of knee lockout.'
    ],
    tips: ['Never round lower back off the pad at bottom of movement.']
  },
  {
    id: 'ex-leg-extension',
    name: 'Leg Extension',
    muscleGroup: 'Quads',
    secondaryMuscles: [],
    equipment: 'Machine',
    defaultRestSeconds: 60,
    instructions: [
      'Align knee joints with pivot point of machine.',
      'Hook shins under pad with feet dorsiflexed.',
      'Extend legs until knees are straight, squeezing quads at peak.',
      'Lower under steady control.'
    ],
    tips: ['Great for quadriceps isolation and finishing pump.']
  },

  // LEGS - HAMSTRINGS & GLUTES
  {
    id: 'ex-romanian-deadlift',
    name: 'Romanian Deadlift (RDL)',
    muscleGroup: 'Hamstrings',
    secondaryMuscles: ['Glutes', 'Lower Back', 'Lats'],
    equipment: 'Barbell',
    defaultRestSeconds: 120,
    instructions: [
      'Stand holding bar at thighs with shoulder-width grip.',
      'Unlock knees slightly, then push hips straight back as far as possible.',
      'Slide barbell down close to legs until you feel deep hamstring stretch.',
      'Drive hips forward and squeeze glutes to return to standing.'
    ],
    tips: [
      'Movement comes entirely from the hip hinge, not bending the knees.',
      'Keep back flat like a table.'
    ]
  },
  {
    id: 'ex-lying-leg-curl',
    name: 'Lying Leg Curl',
    muscleGroup: 'Hamstrings',
    secondaryMuscles: ['Calves'],
    equipment: 'Machine',
    defaultRestSeconds: 60,
    instructions: [
      'Lie face down on bench with pad positioned behind lower calves.',
      'Grip handles, curl heels toward buttocks smoothly.',
      'Pause for 1 second at top contraction.',
      'Lower weight slowly back down.'
    ],
    tips: ['Keep hips pressed firmly into pad throughout the set.']
  },
  {
    id: 'ex-barbell-hip-thrust',
    name: 'Barbell Hip Thrust',
    muscleGroup: 'Glutes',
    secondaryMuscles: ['Hamstrings', 'Core'],
    equipment: 'Barbell',
    defaultRestSeconds: 120,
    instructions: [
      'Rest upper back against a bench with padded barbell across hips.',
      'Feet flat on floor, shoulder-width apart, knees bent at 90 degrees.',
      'Drive through heels, extending hips upward until thighs and torso align.',
      'Squeeze glutes at peak for 1 second, then lower hips with control.'
    ],
    tips: ['Keep chin tucked and ribs down to avoid arching lumbar spine.']
  },

  // ARMS - BICEPS
  {
    id: 'ex-barbell-curl',
    name: 'Barbell Bicep Curl',
    muscleGroup: 'Biceps',
    secondaryMuscles: ['Forearms'],
    equipment: 'Barbell',
    defaultRestSeconds: 90,
    instructions: [
      'Stand tall gripping barbell shoulder-width with underhand grip.',
      'Keep elbows pinned near ribcage.',
      'Curl bar up toward shoulders by flexing biceps.',
      'Squeeze biceps hard at top, then lower over 2-3 seconds.'
    ],
    tips: ['Do not rock torso or swing weight with hip momentum.']
  },
  {
    id: 'ex-incline-db-curl',
    name: 'Incline Dumbbell Curl',
    muscleGroup: 'Biceps',
    secondaryMuscles: ['Forearms'],
    equipment: 'Dumbbell',
    defaultRestSeconds: 75,
    instructions: [
      'Sit on bench inclined to 45-60 degrees with dumbbells hanging.',
      'Let arms hang straight down behind torso for deep stretch on bicep head.',
      'Curl dumbbells up while supinating wrists (turn palms up).',
      'Lower fully into bottom stretch.'
    ],
    tips: ['Incredible exercise for long head of bicep peak.']
  },
  {
    id: 'ex-hammer-curl',
    name: 'Dumbbell Hammer Curl',
    muscleGroup: 'Biceps',
    secondaryMuscles: ['Brachialis', 'Forearms'],
    equipment: 'Dumbbell',
    defaultRestSeconds: 60,
    instructions: [
      'Hold dumbbells at sides with neutral grip (palms facing each other).',
      'Curl dumbbells up toward shoulders while keeping palms neutral.',
      'Lower slowly to full extension.'
    ],
    tips: ['Builds forearm thickness and the brachialis muscle underneath biceps.']
  },

  // ARMS - TRICEPS
  {
    id: 'ex-rope-pushdown',
    name: 'Tricep Rope Pushdown',
    muscleGroup: 'Triceps',
    secondaryMuscles: [],
    equipment: 'Cable',
    defaultRestSeconds: 60,
    instructions: [
      'Attach rope to high cable pulley.',
      'Grip rope, tuck elbows to ribs, lean forward slightly.',
      'Push rope down by extending elbows, spreading rope apart at the bottom.',
      'Squeeze triceps for a second, then allow rope back to chest level.'
    ],
    tips: ['Keep upper arms stationary; only forearms should move.']
  },
  {
    id: 'ex-skull-crusher',
    name: 'EZ-Bar Skull Crusher',
    muscleGroup: 'Triceps',
    secondaryMuscles: ['Forearms'],
    equipment: 'Barbell',
    defaultRestSeconds: 90,
    instructions: [
      'Lie on flat bench holding EZ-curl bar above chest with arms extended.',
      'Hinge at elbows to lower bar toward forehead or slightly behind head.',
      'Stop just above forehead, then extend elbows back to straight arms.'
    ],
    tips: ['Keep elbows tucked in rather than flaring wide.']
  },
  {
    id: 'ex-overhead-cable-extension',
    name: 'Overhead Cable Tricep Extension',
    muscleGroup: 'Triceps',
    secondaryMuscles: [],
    equipment: 'Cable',
    defaultRestSeconds: 75,
    instructions: [
      'Face away from cable pulley, rope behind head, elbows pointing forward.',
      'Step into split stance for balance.',
      'Extend arms overhead and forward, squeezing triceps.',
      'Return slowly to deep stretch behind neck.'
    ],
    tips: ['Maximizes activation of the tricep long head.']
  },

  // CALVES & CORE
  {
    id: 'ex-standing-calf-raise',
    name: 'Standing Calf Raise',
    muscleGroup: 'Calves',
    secondaryMuscles: [],
    equipment: 'Machine',
    defaultRestSeconds: 60,
    instructions: [
      'Position shoulders under pads with balls of feet on platform ledge.',
      'Lower heels as far as comfortable for a 2-second deep stretch.',
      'Press up onto balls of feet as high as possible, squeezing calves for 1s.'
    ],
    tips: ['Pause at the bottom stretch to prevent Achilles tendon recoil.']
  },
  {
    id: 'ex-hanging-leg-raise',
    name: 'Hanging Leg / Knee Raise',
    muscleGroup: 'Core',
    secondaryMuscles: ['Hip Flexors', 'Grip'],
    equipment: 'Bodyweight',
    defaultRestSeconds: 60,
    instructions: [
      'Hang from pull-up bar with overhand grip.',
      'Brace core and raise legs (or knees bent) up toward chest.',
      'Tilt pelvis upward at top to fully contract the rectus abdominis.',
      'Lower legs slowly without swinging.'
    ],
    tips: ['Do not use body momentum to swing legs up.']
  },
  {
    id: 'ex-cable-woodchopper',
    name: 'Cable Woodchopper',
    muscleGroup: 'Core',
    secondaryMuscles: ['Obliques', 'Shoulders'],
    equipment: 'Cable',
    defaultRestSeconds: 60,
    instructions: [
      'Position cable at high setting. Stand perpendicular to machine.',
      'Grip handle with both hands, rotate torso diagonally down across body.',
      'Pivot rear foot and engage obliques.',
      'Return with controlled motion.'
    ],
    tips: ['Focus on rotating with core rather than pulling with arms.']
  },
  {
    id: 'ex-plank',
    name: 'Weighted / Standard Plank',
    muscleGroup: 'Core',
    secondaryMuscles: ['Shoulders', 'Glutes'],
    equipment: 'Bodyweight',
    defaultRestSeconds: 60,
    instructions: [
      'Set forearms on floor with elbows directly under shoulders.',
      'Form straight line from head to heels.',
      'Squeeze glutes and brace core as if anticipating a punch.'
    ],
    tips: ['Do not allow hips to sag downward or pike upward.']
  }
];

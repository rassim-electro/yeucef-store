import React, { useState } from 'react';
import { X, Layers, ArrowRight } from 'lucide-react';
import { WeightUnit } from '../types/gym';
import { calculatePlates } from '../utils/calculators';

interface PlateCalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  weightUnit: WeightUnit;
  initialWeight?: number;
}

export const PlateCalculatorModal: React.FC<PlateCalculatorModalProps> = ({
  isOpen,
  onClose,
  weightUnit,
  initialWeight = 100
}) => {
  const [targetWeight, setTargetWeight] = useState<number>(initialWeight);
  const [barWeight, setBarWeight] = useState<number>(weightUnit === 'kg' ? 20 : 45);

  if (!isOpen) return null;

  const result = calculatePlates(targetWeight, weightUnit, barWeight);

  const presets = weightUnit === 'kg' 
    ? [60, 80, 100, 120, 140, 160] 
    : [135, 185, 225, 275, 315, 405];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-[#111216] border border-[#2b2d39] rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-[#222430]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-zinc-850 border border-zinc-750 flex items-center justify-center text-zinc-300">
              <Layers size={18} />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Barbell Plate Calculator</h3>
              <p className="text-xs text-zinc-400">Calculate exact plates to load per side</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-5">
          {/* Inputs */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-1.5">
                Target Weight ({weightUnit})
              </label>
              <input
                type="number"
                step="2.5"
                min="0"
                value={targetWeight || ''}
                onChange={e => setTargetWeight(parseFloat(e.target.value) || 0)}
                className="w-full bg-[#181920] border border-[#2d2f3d] rounded-xl px-3.5 py-2.5 text-white font-mono text-lg font-bold focus:outline-none focus:border-zinc-400 transition-colors"
                placeholder="e.g. 100"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-1.5">
                Barbell Weight ({weightUnit})
              </label>
              <select
                value={barWeight}
                onChange={e => setBarWeight(parseFloat(e.target.value))}
                className="w-full bg-[#181920] border border-[#2d2f3d] rounded-xl px-3.5 py-2.5 text-white font-mono text-sm focus:outline-none focus:border-zinc-400 transition-colors"
              >
                {weightUnit === 'kg' ? (
                  <>
                    <option value={20}>Standard Olympic Bar (20 kg)</option>
                    <option value={15}>Women / Technique Bar (15 kg)</option>
                    <option value={10}>EZ Curl Bar (10 kg)</option>
                    <option value={25}>Safety Squat Bar (25 kg)</option>
                  </>
                ) : (
                  <>
                    <option value={45}>Standard Olympic Bar (45 lbs)</option>
                    <option value={35}>Women / Technique Bar (35 lbs)</option>
                    <option value={25}>EZ Curl Bar (25 lbs)</option>
                    <option value={55}>Safety Squat Bar (55 lbs)</option>
                  </>
                )}
              </select>
            </div>
          </div>

          {/* Quick Presets */}
          <div>
            <span className="text-[11px] font-medium text-zinc-400 uppercase tracking-wider block mb-1.5">
              Quick Presets
            </span>
            <div className="flex flex-wrap gap-1.5">
              {presets.map(p => (
                <button
                  key={p}
                  onClick={() => setTargetWeight(p)}
                  className={`px-3 py-1 text-xs font-semibold rounded-lg border transition-all ${
                    targetWeight === p
                      ? 'bg-zinc-200 border-white text-black'
                      : 'bg-[#181920] border-[#2b2d39] text-zinc-300 hover:border-zinc-500'
                  }`}
                >
                  {p} {weightUnit}
                </button>
              ))}
            </div>
          </div>

          {/* Visual Barbell Loading Diagram */}
          <div className="bg-[#0b0c10] border border-[#262835] rounded-xl p-4 overflow-x-auto">
            <div className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider mb-2 flex items-center justify-between">
              <span>Sleeve Visualization (One Side)</span>
              <span className="text-white font-bold font-mono">
                {result.weightPerSide} {weightUnit} per side
              </span>
            </div>

            <div className="flex items-center min-h-[90px] px-2 py-3 bg-[#13151b] rounded-lg border border-[#20222b]">
              {/* Bar shaft / Collar */}
              <div className="h-4 w-12 bg-zinc-600 rounded-l flex-shrink-0" />
              <div className="h-14 w-3.5 bg-zinc-400 rounded-sm flex-shrink-0 border-r border-zinc-700" title="Barbell Collar" />

              {/* Stacked Plates */}
              {result.platesPerSide.length === 0 ? (
                <div className="text-zinc-500 text-xs italic ml-4">
                  {targetWeight <= barWeight ? 'Empty bar — no plates needed' : 'Load barbell to see plates'}
                </div>
              ) : (
                <div className="flex items-center gap-1 ml-1 flex-shrink-0">
                  {result.platesPerSide.flatMap(plate =>
                    Array.from({ length: plate.count }).map((_, idx) => {
                      // Heights based on plate size
                      const heightClass =
                        plate.weight >= 20 ? 'h-20 w-4' :
                        plate.weight >= 15 ? 'h-16 w-3.5' :
                        plate.weight >= 10 ? 'h-13 w-3.5' :
                        plate.weight >= 5 ? 'h-10 w-3' : 'h-7 w-2.5';

                      return (
                        <div
                          key={`${plate.weight}-${idx}`}
                          className={`${heightClass} rounded-sm flex flex-col items-center justify-center font-mono font-black text-[9px] text-white shadow-md border border-white/20 hover:scale-105 transition-transform`}
                          style={{ backgroundColor: plate.color }}
                          title={`${plate.weight} ${weightUnit}`}
                        >
                          <span className="rotate-90 select-none whitespace-nowrap">{plate.weight}</span>
                        </div>
                      );
                    })
                  )}
                </div>
              )}

              {/* Bar Sleeve Extension */}
              <div className="h-3 w-16 bg-zinc-700 rounded-r flex-shrink-0 ml-1" />
            </div>
          </div>

          {/* Plate Inventory Breakdown */}
          <div className="space-y-2">
            <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider block">
              Required Plates (Each Side)
            </span>
            {result.platesPerSide.length === 0 ? (
              <p className="text-xs text-zinc-500">No plates required for this weight.</p>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {result.platesPerSide.map(plate => (
                  <div
                    key={plate.weight}
                    className="flex items-center justify-between p-2 rounded-lg bg-[#161820] border border-[#262835]"
                  >
                    <div className="flex items-center gap-2">
                      <div
                        className="w-3.5 h-3.5 rounded-full"
                        style={{ backgroundColor: plate.color }}
                      />
                      <span className="text-xs font-bold text-white font-mono">
                        {plate.weight} {weightUnit}
                      </span>
                    </div>
                    <span className="text-xs font-extrabold text-zinc-200 font-mono bg-zinc-800 px-2 py-0.5 rounded border border-zinc-700">
                      × {plate.count}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Achieved vs Target Summary */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-zinc-900 border border-zinc-800 text-xs">
            <div className="text-zinc-400">
              Total Weight: <span className="text-white font-mono font-bold">{result.achievedTotal} {weightUnit}</span>
            </div>
            {result.remainder !== 0 && (
              <div className="text-amber-400 font-medium">
                Remainder: {result.remainder > 0 ? `+${result.remainder}` : result.remainder} {weightUnit}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#0d0e12] border-t border-[#222430] flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-semibold transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { Routine, ExerciseDefinition } from '../../types/gym';
import {
  Play,
  Plus,
  Trash2,
  Clock,
  Dumbbell,
  Layers,
  X,
  Check,
  Flame,
  Target
} from 'lucide-react';

interface RoutinesViewProps {
  routines: Routine[];
  exercises: ExerciseDefinition[];
  onStartRoutine: (routine: Routine) => void;
  onSaveRoutine: (routine: Routine) => void;
  onDeleteRoutine: (id: string) => void;
}

export const RoutinesView: React.FC<RoutinesViewProps> = ({
  routines,
  exercises,
  onStartRoutine,
  onSaveRoutine,
  onDeleteRoutine
}) => {
  const [filterSplit, setFilterSplit] = useState<string>('All');
  const [showCreateModal, setShowCreateModal] = useState(false);

  // New Routine Form State
  const [newRoutineName, setNewRoutineName] = useState('');
  const [newRoutineDesc, setNewRoutineDesc] = useState('');
  const [newRoutineSplit, setNewRoutineSplit] = useState('Push / Pull / Legs');
  const [newRoutineEstMinutes, setNewRoutineEstMinutes] = useState(60);
  const [selectedExerciseIds, setSelectedExerciseIds] = useState<string[]>([]);

  const splitOptions = ['All', 'Push / Pull / Legs', 'Upper / Lower', 'Full Body'];

  const filtered = routines.filter(r => {
    if (filterSplit === 'All') return true;
    return r.targetSplit.toLowerCase().includes(filterSplit.toLowerCase());
  });

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRoutineName.trim()) return;

    const newRoutine: Routine = {
      id: `routine-custom-${Date.now()}`,
      name: newRoutineName,
      description: newRoutineDesc || 'Custom routine designed in Infinity Gym.',
      targetSplit: newRoutineSplit,
      estimatedMinutes: newRoutineEstMinutes || 60,
      exercises: selectedExerciseIds.map(id => ({
        exerciseId: id,
        targetSets: 3,
        targetReps: '8-12',
        defaultRestSeconds: 90
      }))
    };

    onSaveRoutine(newRoutine);
    setShowCreateModal(false);
    setNewRoutineName('');
    setNewRoutineDesc('');
    setSelectedExerciseIds([]);
  };

  const toggleSelectExercise = (id: string) => {
    setSelectedExerciseIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-black text-white uppercase tracking-wider">
            Workout Routines & Training Splits
          </h2>
          <p className="text-sm text-zinc-400">
            Pre-programmed training splits and custom bodybuilding routines
          </p>
        </div>

        <button
          onClick={() => setShowCreateModal(true)}
          className="px-6 py-3 rounded-2xl bg-white text-black font-black text-sm hover:bg-zinc-200 transition-all flex items-center gap-2 self-start sm:self-auto shadow-lg active:scale-95"
        >
          <Plus size={16} />
          <span>Create Custom Routine</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2.5 overflow-x-auto no-scrollbar pb-1">
        {splitOptions.map(split => (
          <button
            key={split}
            onClick={() => setFilterSplit(split)}
            className={`px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all ${
              filterSplit === split
                ? 'bg-zinc-800 text-white border border-zinc-650 shadow-sm'
                : 'bg-[#121319] text-zinc-400 hover:text-white border border-[#232535]'
            }`}
          >
            {split}
          </button>
        ))}
      </div>

      {/* Routine Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map(routine => (
          <div
            key={routine.id}
            className="bg-[#121319] border border-[#262837] rounded-3xl p-6 sm:p-7 hover:border-zinc-500 transition-all flex flex-col justify-between shadow-xl"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-mono uppercase tracking-wider px-2.5 py-1 rounded-lg bg-zinc-850 text-zinc-200 border border-zinc-700">
                  {routine.targetSplit}
                </span>
                <span className="text-xs sm:text-sm text-zinc-400 flex items-center gap-1.5 font-medium">
                  <Clock size={14} /> {routine.estimatedMinutes}m
                </span>
              </div>

              <h3 className="text-lg sm:text-xl font-black text-white mb-2">{routine.name}</h3>
              <p className="text-xs sm:text-sm text-zinc-400 mb-5 leading-relaxed">
                {routine.description}
              </p>

              {/* Exercises in routine preview */}
              <div className="space-y-2 pt-4 border-t border-[#1f212f]">
                <span className="text-xs font-bold text-zinc-500 uppercase tracking-wider block">
                  Programmed Exercises ({routine.exercises.length})
                </span>
                <div className="space-y-1.5 max-h-44 overflow-y-auto no-scrollbar pr-1">
                  {routine.exercises.map((re, i) => {
                    const def = exercises.find(e => e.id === re.exerciseId);
                    return (
                      <div
                        key={i}
                        className="flex items-center justify-between text-xs sm:text-sm py-1.5 px-3 rounded-xl bg-[#171824] text-zinc-200"
                      >
                        <span className="truncate max-w-[180px] font-medium">{def?.name || re.exerciseId}</span>
                        <span className="font-mono text-zinc-400 text-xs font-semibold">
                          {re.targetSets} sets × {re.targetReps}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="mt-6 pt-4 border-t border-[#1f212f] flex items-center justify-between">
              {routine.id.startsWith('routine-custom') ? (
                <button
                  onClick={() => {
                    if (confirm(`Delete routine "${routine.name}"?`)) {
                      onDeleteRoutine(routine.id);
                    }
                  }}
                  className="p-2.5 text-zinc-500 hover:text-red-400 rounded-xl hover:bg-zinc-850 transition-colors"
                  title="Delete Routine"
                >
                  <Trash2 size={16} />
                </button>
              ) : <div />}

              <button
                onClick={() => onStartRoutine(routine)}
                className="px-6 py-3 rounded-2xl bg-white hover:bg-zinc-200 text-black font-black text-xs sm:text-sm transition-all flex items-center gap-2 shadow-lg active:scale-95"
              >
                <Play size={14} fill="currentColor" />
                <span>Start Workout</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Create Custom Routine Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
          <div className="bg-[#111218] border border-[#2b2d3d] rounded-3xl w-full max-w-xl max-h-[90vh] flex flex-col overflow-hidden shadow-2xl">
            <div className="p-5 sm:p-6 border-b border-[#222432] flex items-center justify-between">
              <h3 className="text-lg font-black text-white">Create Custom Routine</h3>
              <button
                onClick={() => setShowCreateModal(false)}
                className="p-1.5 rounded-xl text-zinc-400 hover:text-white"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
                  Routine Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Heavy Upper Body Blast"
                  value={newRoutineName}
                  onChange={e => setNewRoutineName(e.target.value)}
                  className="w-full bg-[#181923] border border-[#2d2f40] rounded-2xl px-4 py-3 text-white text-sm font-semibold focus:outline-none focus:border-zinc-400"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
                  Description / Focus
                </label>
                <textarea
                  rows={2}
                  placeholder="e.g. Chest thickness, heavy rowing, arm superset"
                  value={newRoutineDesc}
                  onChange={e => setNewRoutineDesc(e.target.value)}
                  className="w-full bg-[#181923] border border-[#2d2f40] rounded-2xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-zinc-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
                    Split Category
                  </label>
                  <select
                    value={newRoutineSplit}
                    onChange={e => setNewRoutineSplit(e.target.value)}
                    className="w-full bg-[#181923] border border-[#2d2f40] rounded-2xl px-4 py-2.5 text-white text-sm focus:outline-none"
                  >
                    <option value="Push / Pull / Legs">Push / Pull / Legs</option>
                    <option value="Upper / Lower">Upper / Lower</option>
                    <option value="Full Body">Full Body</option>
                    <option value="Custom Split">Custom Split</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
                    Est. Duration (Mins)
                  </label>
                  <input
                    type="number"
                    min="15"
                    max="180"
                    value={newRoutineEstMinutes}
                    onChange={e => setNewRoutineEstMinutes(parseInt(e.target.value) || 60)}
                    className="w-full bg-[#181923] border border-[#2d2f40] rounded-2xl px-4 py-2.5 text-white text-sm font-mono font-bold focus:outline-none"
                  />
                </div>
              </div>

              {/* Select Exercises */}
              <div>
                <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-2">
                  Select Exercises ({selectedExerciseIds.length} chosen)
                </label>
                <div className="border border-[#262837] rounded-2xl max-h-56 overflow-y-auto p-2.5 bg-[#14151e] divide-y divide-[#1e202d]">
                  {exercises.map(ex => {
                    const isSelected = selectedExerciseIds.includes(ex.id);
                    return (
                      <div
                        key={ex.id}
                        onClick={() => toggleSelectExercise(ex.id)}
                        className={`p-2.5 rounded-xl flex items-center justify-between cursor-pointer transition-colors ${
                          isSelected ? 'bg-zinc-800 text-white' : 'hover:bg-[#1a1c28] text-zinc-300'
                        }`}
                      >
                        <div>
                          <div className="text-sm font-bold">{ex.name}</div>
                          <div className="text-xs text-zinc-400">{ex.muscleGroup} • {ex.equipment}</div>
                        </div>
                        <div
                          className={`w-5 h-5 rounded-md flex items-center justify-center border transition-colors ${
                            isSelected
                              ? 'bg-white border-white text-black'
                              : 'border-zinc-700 bg-transparent'
                          }`}
                        >
                          {isSelected && <Check size={13} strokeWidth={3} />}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="pt-4 border-t border-[#222432] flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-5 py-2.5 rounded-2xl bg-zinc-850 hover:bg-zinc-800 text-zinc-300 text-sm font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={selectedExerciseIds.length === 0}
                  className="px-6 py-2.5 rounded-2xl bg-white text-black font-black text-sm hover:bg-zinc-200 disabled:opacity-50 transition-all shadow"
                >
                  Save Routine
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

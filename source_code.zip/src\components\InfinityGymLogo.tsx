import React from 'react';

interface InfinityGymLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  className?: string;
}

export const InfinityGymLogo: React.FC<InfinityGymLogoProps> = ({
  size = 'md',
  showText = true,
  className = ''
}) => {
  // Dimensions based on size
  const iconHeight = size === 'sm' ? 24 : size === 'md' ? 32 : size === 'lg' ? 44 : 56;
  const iconWidth = Math.round(iconHeight * 2.2);

  return (
    <div className={`flex flex-col items-center justify-center select-none ${className}`}>
      {/* Bold 3D Block Text matching photo */}
      {showText && (
        <div className="flex items-center tracking-[0.2em] font-black text-white uppercase drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
          <span
            className={
              size === 'sm'
                ? 'text-sm font-black'
                : size === 'md'
                ? 'text-lg font-black'
                : size === 'lg'
                ? 'text-2xl font-black'
                : 'text-3xl font-black'
            }
            style={{
              fontFamily: "'Arial Black', 'Impact', -apple-system, sans-serif",
              letterSpacing: '0.15em'
            }}
          >
            INFINITY<span className="text-zinc-300 ml-1.5">GYM</span>
          </span>
        </div>
      )}

      {/* Barbell + Infinity Symbol SVG - exact replica from the gym wall */}
      <svg
        width={iconWidth}
        height={iconHeight}
        viewBox="0 0 160 60"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="filter drop-shadow-[0_3px_5px_rgba(0,0,0,0.6)]"
      >
        <defs>
          <linearGradient id="metalGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="40%" stopColor="#d1d5db" />
            <stop offset="70%" stopColor="#9ca3af" />
            <stop offset="100%" stopColor="#4b5563" />
          </linearGradient>
          <linearGradient id="barGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#9ca3af" />
            <stop offset="50%" stopColor="#ffffff" />
            <stop offset="100%" stopColor="#374151" />
          </linearGradient>
        </defs>

        {/* Center Connecting Bar */}
        <rect x="25" y="27" width="110" height="6" rx="2" fill="url(#barGrad)" opacity="0.9" />

        {/* LEFT BARBELL PLATES */}
        {/* Outermost small plate */}
        <rect x="10" y="20" width="4" height="20" rx="1.5" fill="url(#metalGrad)" stroke="#111827" strokeWidth="0.8" />
        {/* Middle plate */}
        <rect x="16" y="14" width="4.5" height="32" rx="1.5" fill="url(#metalGrad)" stroke="#111827" strokeWidth="0.8" />
        {/* Big inner plate */}
        <rect x="22.5" y="9" width="5.5" height="42" rx="2" fill="url(#metalGrad)" stroke="#111827" strokeWidth="0.8" />
        {/* Left Collar ring */}
        <rect x="29.5" y="23" width="3.5" height="14" rx="1" fill="#f3f4f6" />

        {/* RIGHT BARBELL PLATES */}
        {/* Right Collar ring */}
        <rect x="127" y="23" width="3.5" height="14" rx="1" fill="#f3f4f6" />
        {/* Big inner plate */}
        <rect x="132" y="9" width="5.5" height="42" rx="2" fill="url(#metalGrad)" stroke="#111827" strokeWidth="0.8" />
        {/* Middle plate */}
        <rect x="139.5" y="14" width="4.5" height="32" rx="1.5" fill="url(#metalGrad)" stroke="#111827" strokeWidth="0.8" />
        {/* Outermost small plate */}
        <rect x="146" y="20" width="4" height="20" rx="1.5" fill="url(#metalGrad)" stroke="#111827" strokeWidth="0.8" />

        {/* CENTER INFINITY SYMBOL */}
        {/* Shadow path */}
        <path
          d="M 60 30 C 50 16, 36 16, 36 30 C 36 44, 50 44, 60 30 C 70 16, 84 16, 84 30 C 84 44, 70 44, 60 30 Z"
          transform="translate(20, 0)"
          stroke="#000000"
          strokeWidth="11"
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="none"
        />
        {/* Main Infinity Stroke */}
        <path
          d="M 60 30 C 50 16, 36 16, 36 30 C 36 44, 50 44, 60 30 C 70 16, 84 16, 84 30 C 84 44, 70 44, 60 30 Z"
          transform="translate(20, 0)"
          stroke="url(#metalGrad)"
          strokeWidth="8"
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="none"
        />
        {/* Inner Highlight Loop */}
        <path
          d="M 60 30 C 50 18, 38 18, 38 30 C 38 42, 50 42, 60 30 C 70 18, 82 18, 82 30 C 82 42, 70 42, 60 30 Z"
          transform="translate(20, 0)"
          stroke="#ffffff"
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="none"
          opacity="0.75"
        />
      </svg>
    </div>
  );
};

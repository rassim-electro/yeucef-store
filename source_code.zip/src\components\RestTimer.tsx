import React, { useEffect, useState } from 'react';
import { Timer, X, Plus, Minus, Volume2, VolumeX, Minimize2, Maximize2 } from 'lucide-react';
import { playCountdownBeep, playTimerCompleteChime } from '../utils/sound';

interface RestTimerProps {
  initialSeconds?: number;
  isOpen: boolean;
  onClose: () => void;
}

export const RestTimer: React.FC<RestTimerProps> = ({
  initialSeconds = 90,
  isOpen,
  onClose
}) => {
  const [totalSeconds, setTotalSeconds] = useState(initialSeconds);
  const [remainingSeconds, setRemainingSeconds] = useState(initialSeconds);
  const [isRunning, setIsRunning] = useState(true);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [isMinimized, setIsMinimized] = useState(false);

  useEffect(() => {
    setTotalSeconds(initialSeconds);
    setRemainingSeconds(initialSeconds);
    setIsRunning(true);
  }, [initialSeconds]);

  useEffect(() => {
    let interval: ReturnType<typeof setInterval> | null = null;
    if (isRunning && remainingSeconds > 0) {
      interval = setInterval(() => {
        setRemainingSeconds(prev => {
          const next = prev - 1;
          if (soundEnabled) {
            if (next <= 3 && next > 0) {
              playCountdownBeep(false);
            } else if (next === 0) {
              playTimerCompleteChime();
            }
          }
          if (next <= 0) {
            setIsRunning(false);
            return 0;
          }
          return next;
        });
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isRunning, remainingSeconds, soundEnabled]);

  if (!isOpen) return null;

  const progressPercent = totalSeconds > 0 ? ((totalSeconds - remainingSeconds) / totalSeconds) * 100 : 0;
  const minutes = Math.floor(remainingSeconds / 60);
  const seconds = remainingSeconds % 60;
  const timeFormatted = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;

  const addTime = (secs: number) => {
    setRemainingSeconds(prev => {
      const next = Math.max(0, prev + secs);
      if (next > totalSeconds) setTotalSeconds(next);
      return next;
    });
    if (!isRunning) setIsRunning(true);
  };

  const setPreset = (secs: number) => {
    setTotalSeconds(secs);
    setRemainingSeconds(secs);
    setIsRunning(true);
  };

  if (isMinimized) {
    return (
      <div className="fixed bottom-6 right-6 z-50 flex items-center gap-3 bg-zinc-900/95 border border-zinc-700/80 px-4 py-2.5 rounded-2xl shadow-2xl backdrop-blur-md">
        <div className="flex items-center gap-2">
          <Timer size={16} className={remainingSeconds === 0 ? 'text-emerald-400' : 'text-zinc-400 animate-pulse'} />
          <span className="font-mono font-bold text-white text-base">
            {remainingSeconds === 0 ? 'Rest Done!' : timeFormatted}
          </span>
        </div>
        <button
          onClick={() => setIsMinimized(false)}
          className="text-zinc-400 hover:text-white p-1"
          title="Expand Rest Timer"
        >
          <Maximize2 size={14} />
        </button>
        <button
          onClick={onClose}
          className="text-zinc-500 hover:text-red-400 p-1"
          title="Dismiss"
        >
          <X size={14} />
        </button>
      </div>
    );
  }

  return (
    <div className="fixed bottom-6 right-6 z-50 w-80 bg-zinc-950/95 border border-zinc-800 rounded-2xl shadow-2xl backdrop-blur-xl p-4 transition-all">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-zinc-850">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg bg-zinc-800 flex items-center justify-center">
            <Timer size={14} className="text-zinc-300" />
          </div>
          <span className="text-xs font-bold uppercase tracking-wider text-zinc-300">
            Rest Interval
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="text-zinc-400 hover:text-white p-1 rounded hover:bg-zinc-800 transition-colors"
            title={soundEnabled ? 'Mute Chime' : 'Enable Chime'}
          >
            {soundEnabled ? <Volume2 size={15} /> : <VolumeX size={15} className="text-zinc-600" />}
          </button>
          <button
            onClick={() => setIsMinimized(true)}
            className="text-zinc-400 hover:text-white p-1 rounded hover:bg-zinc-800 transition-colors"
            title="Minimize"
          >
            <Minimize2 size={14} />
          </button>
          <button
            onClick={onClose}
            className="text-zinc-500 hover:text-red-400 p-1 rounded hover:bg-zinc-800 transition-colors"
            title="Close"
          >
            <X size={15} />
          </button>
        </div>
      </div>

      {/* Timer Display */}
      <div className="my-4 text-center">
        <div className="font-mono text-4xl font-black tracking-tight text-white">
          {remainingSeconds === 0 ? (
            <span className="text-emerald-400 text-3xl">GO LIFT! 🔥</span>
          ) : (
            timeFormatted
          )}
        </div>
        <div className="w-full bg-zinc-900 h-1.5 rounded-full mt-3 overflow-hidden border border-zinc-800">
          <div
            className={`h-full transition-all duration-1000 ${
              remainingSeconds === 0 ? 'bg-emerald-500' : 'bg-gradient-to-r from-zinc-500 to-white'
            }`}
            style={{ width: `${Math.min(100, progressPercent)}%` }}
          />
        </div>
      </div>

      {/* Adjust Buttons */}
      <div className="flex items-center justify-center gap-2 mb-3">
        <button
          onClick={() => addTime(-15)}
          className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-300 hover:bg-zinc-800 transition-colors flex items-center gap-0.5"
        >
          <Minus size={12} /> 15s
        </button>
        <button
          onClick={() => setIsRunning(!isRunning)}
          className={`px-4 py-1 text-xs font-bold rounded-lg border transition-all ${
            isRunning
              ? 'bg-zinc-800 border-zinc-700 text-zinc-200 hover:bg-zinc-700'
              : 'bg-white border-white text-black hover:bg-zinc-200'
          }`}
        >
          {isRunning ? 'Pause' : 'Resume'}
        </button>
        <button
          onClick={() => addTime(30)}
          className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-300 hover:bg-zinc-800 transition-colors flex items-center gap-0.5"
        >
          <Plus size={12} /> 30s
        </button>
      </div>

      {/* Presets */}
      <div className="grid grid-cols-4 gap-1.5 pt-2 border-t border-zinc-850">
        {[45, 60, 90, 120].map(sec => (
          <button
            key={sec}
            onClick={() => setPreset(sec)}
            className="py-1 text-[11px] font-medium rounded bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white hover:bg-zinc-800 hover:border-zinc-700 transition-all"
          >
            {sec}s
          </button>
        ))}
      </div>
    </div>
  );
};

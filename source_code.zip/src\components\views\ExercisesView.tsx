import React, { useState } from 'react';
import { ExerciseDefinition, MuscleGroup, EquipmentType } from '../../types/gym';
import {
  Search,
  BookOpen,
  Plus,
  X,
  CheckCircle2,
  AlertCircle,
  Clock,
  Dumbbell
} from 'lucide-react';

interface ExercisesViewProps {
  exercises: ExerciseDefinition[];
  onAddCustomExercise: (def: ExerciseDefinition) => void;
}

export const ExercisesView: React.FC<ExercisesViewProps> = ({
  exercises,
  onAddCustomExercise
}) => {
  const [search, setSearch] = useState('');
  const [selectedMuscle, setSelectedMuscle] = useState<string>('All');
  const [selectedEquipment, setSelectedEquipment] = useState<string>('All');
  const [activeExerciseModal, setActiveExerciseModal] = useState<ExerciseDefinition | null>(null);
  const [showAddCustom, setShowAddCustom] = useState(false);

  // New Exercise Form
  const [customName, setCustomName] = useState('');
  const [customMuscle, setCustomMuscle] = useState<MuscleGroup>('Chest');
  const [customEquipment, setCustomEquipment] = useState<EquipmentType>('Dumbbell');
  const [customInstructions, setCustomInstructions] = useState('');
  const [customTips, setCustomTips] = useState('');

  const muscles: string[] = [
    'All',
    'Chest',
    'Back',
    'Shoulders',
    'Quads',
    'Hamstrings',
    'Biceps',
    'Triceps',
    'Glutes',
    'Calves',
    'Core'
  ];

  const equipments: string[] = ['All', 'Barbell', 'Dumbbell', 'Cable', 'Machine', 'Bodyweight'];

  const filtered = exercises.filter(ex => {
    const matchesSearch =
      ex.name.toLowerCase().includes(search.toLowerCase()) ||
      ex.muscleGroup.toLowerCase().includes(search.toLowerCase());
    const matchesMuscle = selectedMuscle === 'All' || ex.muscleGroup === selectedMuscle;
    const matchesEq = selectedEquipment === 'All' || ex.equipment === selectedEquipment;
    return matchesSearch && matchesMuscle && matchesEq;
  });

  const handleCreateCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customName.trim()) return;

    const newEx: ExerciseDefinition = {
      id: `ex-custom-${Date.now()}`,
      name: customName.trim(),
      muscleGroup: customMuscle,
      equipment: customEquipment,
      instructions: customInstructions
        .split('\n')
        .map(s => s.trim())
        .filter(Boolean),
      tips: customTips
        .split('\n')
        .map(s => s.trim())
        .filter(Boolean),
      defaultRestSeconds: 90
    };

    onAddCustomExercise(newEx);
    setShowAddCustom(false);
    setCustomName('');
    setCustomInstructions('');
    setCustomTips('');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-black text-white uppercase tracking-wider">
            Exercise Technique & Movement Library
          </h2>
          <p className="text-sm text-zinc-400">
            Biomechanical cues, execution standards, and anatomical muscle targets
          </p>
        </div>

        <button
          onClick={() => setShowAddCustom(true)}
          className="px-6 py-3 rounded-2xl bg-white text-black font-black text-sm hover:bg-zinc-200 transition-all flex items-center gap-2 self-start sm:self-auto shadow-lg active:scale-95"
        >
          <Plus size={16} />
          <span>Add Custom Movement</span>
        </button>
      </div>

      {/* Search & Muscle Filters */}
      <div className="space-y-3.5 bg-[#121319] p-5 sm:p-6 rounded-3xl border border-[#262837] shadow-xl">
        <div className="relative">
          <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400" />
          <input
            type="text"
            placeholder="Search exercises by name or muscle group..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full bg-[#181a24] border border-[#2b2d3f] rounded-2xl pl-12 pr-4 py-3 text-sm sm:text-base text-white placeholder-zinc-500 focus:outline-none focus:border-zinc-400 shadow-inner"
          />
        </div>

        {/* Muscle group tabs */}
        <div className="flex gap-2 overflow-x-auto no-scrollbar py-1">
          {muscles.map(m => (
            <button
              key={m}
              onClick={() => setSelectedMuscle(m)}
              className={`px-3.5 py-1.5 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all ${
                selectedMuscle === m
                  ? 'bg-zinc-200 text-black font-black shadow-md'
                  : 'bg-[#181a24] text-zinc-400 hover:text-white border border-[#282a3c]'
              }`}
            >
              {m}
            </button>
          ))}
        </div>

        {/* Equipment filter */}
        <div className="flex items-center gap-2.5 pt-2 border-t border-[#1e202d] text-xs sm:text-sm text-zinc-400">
          <span className="font-bold uppercase tracking-wider text-zinc-500">Equipment:</span>
          <div className="flex gap-1.5 overflow-x-auto no-scrollbar">
            {equipments.map(eq => (
              <button
                key={eq}
                onClick={() => setSelectedEquipment(eq)}
                className={`px-2.5 py-1 rounded-lg transition-colors font-medium ${
                  selectedEquipment === eq
                    ? 'text-white font-extrabold bg-zinc-800'
                    : 'text-zinc-500 hover:text-zinc-300'
                }`}
              >
                {eq}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Grid of Exercises */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filtered.map(ex => (
          <div
            key={ex.id}
            onClick={() => setActiveExerciseModal(ex)}
            className="bg-[#121319] border border-[#262837] hover:border-zinc-500 rounded-3xl p-5 sm:p-6 cursor-pointer transition-all flex flex-col justify-between group shadow-xl"
          >
            <div>
              <div className="flex items-center justify-between mb-2.5">
                <span className="text-xs font-mono uppercase tracking-wider px-2.5 py-1 rounded-lg bg-zinc-850 text-zinc-200 border border-zinc-700">
                  {ex.muscleGroup}
                </span>
                <span className="text-xs text-zinc-400 font-semibold">
                  {ex.equipment}
                </span>
              </div>

              <h3 className="text-base sm:text-lg font-black text-white group-hover:text-zinc-200 transition-colors">
                {ex.name}
              </h3>

              {ex.secondaryMuscles && ex.secondaryMuscles.length > 0 && (
                <div className="text-xs text-zinc-400 mt-1">
                  Secondary: {ex.secondaryMuscles.join(', ')}
                </div>
              )}

              {ex.tips && ex.tips[0] && (
                <p className="text-xs sm:text-sm text-zinc-300 mt-3 line-clamp-2 italic bg-[#171824] p-3 rounded-2xl border border-[#252737]">
                  "{ex.tips[0]}"
                </p>
              )}
            </div>

            <div className="mt-5 pt-3 border-t border-[#1f212f] flex items-center justify-between text-xs sm:text-sm text-zinc-400">
              <span className="flex items-center gap-1.5 font-mono">
                <Clock size={13} /> {ex.defaultRestSeconds}s rest
              </span>
              <span className="text-zinc-200 group-hover:text-white font-bold flex items-center gap-1.5">
                View Form <BookOpen size={14} />
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Detailed Exercise Modal */}
      {activeExerciseModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
          <div className="bg-[#111218] border border-[#2b2d3d] rounded-3xl w-full max-w-xl max-h-[85vh] flex flex-col overflow-hidden shadow-2xl">
            <div className="p-5 sm:p-6 border-b border-[#222432] flex items-center justify-between">
              <div>
                <span className="text-xs font-mono uppercase tracking-wider px-2.5 py-1 rounded-lg bg-zinc-850 text-zinc-200 border border-zinc-700 inline-block mb-1.5">
                  {activeExerciseModal.muscleGroup} • {activeExerciseModal.equipment}
                </span>
                <h3 className="text-lg sm:text-xl font-black text-white">{activeExerciseModal.name}</h3>
              </div>
              <button
                onClick={() => setActiveExerciseModal(null)}
                className="p-2 rounded-xl text-zinc-400 hover:text-white"
              >
                <X size={20} />
              </button>
            </div>

            <div className="p-5 sm:p-6 overflow-y-auto space-y-6 text-sm sm:text-base">
              {/* Instructions */}
              <div>
                <h4 className="font-extrabold text-white uppercase tracking-wider text-xs sm:text-sm mb-2.5 flex items-center gap-2">
                  <CheckCircle2 size={16} className="text-zinc-200" /> Proper Execution Steps
                </h4>
                <div className="space-y-2 bg-[#171824] p-4 rounded-2xl border border-[#262838]">
                  {activeExerciseModal.instructions.map((step, idx) => (
                    <div key={idx} className="flex items-start gap-2.5 text-zinc-200 leading-relaxed">
                      <span className="font-mono text-zinc-400 font-extrabold">{idx + 1}.</span>
                      <span>{step}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Tips & Form cues */}
              {activeExerciseModal.tips && activeExerciseModal.tips.length > 0 && (
                <div>
                  <h4 className="font-extrabold text-white uppercase tracking-wider text-xs sm:text-sm mb-2.5 flex items-center gap-2">
                    <AlertCircle size={16} className="text-zinc-200" /> Form Cues & Progression Notes
                  </h4>
                  <div className="space-y-2 bg-[#171824] p-4 rounded-2xl border border-[#262838]">
                    {activeExerciseModal.tips.map((tip, idx) => (
                      <div key={idx} className="flex items-start gap-2.5 text-zinc-200 leading-relaxed">
                        <span className="text-zinc-400">•</span>
                        <span>{tip}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="p-5 bg-[#0c0d12] border-t border-[#222432] flex justify-end">
              <button
                onClick={() => setActiveExerciseModal(null)}
                className="px-6 py-2.5 rounded-2xl bg-zinc-800 hover:bg-zinc-700 text-white text-sm font-bold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Custom Exercise Modal */}
      {showAddCustom && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
          <div className="bg-[#111218] border border-[#2b2d3d] rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl">
            <div className="p-5 border-b border-[#222432] flex items-center justify-between">
              <h3 className="text-base font-black text-white">Add Custom Movement</h3>
              <button
                onClick={() => setShowAddCustom(false)}
                className="p-1.5 rounded-xl text-zinc-400 hover:text-white"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleCreateCustom} className="p-5 space-y-4 text-sm">
              <div>
                <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
                  Movement Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Bulgarian Split Squat"
                  value={customName}
                  onChange={e => setCustomName(e.target.value)}
                  className="w-full bg-[#181923] border border-[#2d2f40] rounded-2xl px-4 py-2.5 text-white focus:outline-none focus:border-zinc-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
                    Primary Muscle
                  </label>
                  <select
                    value={customMuscle}
                    onChange={e => setCustomMuscle(e.target.value as MuscleGroup)}
                    className="w-full bg-[#181923] border border-[#2d2f40] rounded-2xl px-4 py-2.5 text-white focus:outline-none"
                  >
                    {muscles.filter(m => m !== 'All').map(m => (
                      <option key={m} value={m}>{m}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
                    Equipment
                  </label>
                  <select
                    value={customEquipment}
                    onChange={e => setCustomEquipment(e.target.value as EquipmentType)}
                    className="w-full bg-[#181923] border border-[#2d2f40] rounded-2xl px-4 py-2.5 text-white focus:outline-none"
                  >
                    {equipments.filter(e => e !== 'All').map(eq => (
                      <option key={eq} value={eq}>{eq}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
                  Execution Steps (one per line)
                </label>
                <textarea
                  rows={3}
                  placeholder="1. Position rear foot on bench...&#10;2. Lower knee towards floor..."
                  value={customInstructions}
                  onChange={e => setCustomInstructions(e.target.value)}
                  className="w-full bg-[#181923] border border-[#2d2f40] rounded-2xl px-4 py-2.5 text-white focus:outline-none focus:border-zinc-400"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
                  Technique Tips
                </label>
                <textarea
                  rows={2}
                  placeholder="Keep torso upright for quad focus; lean forward for glutes."
                  value={customTips}
                  onChange={e => setCustomTips(e.target.value)}
                  className="w-full bg-[#181923] border border-[#2d2f40] rounded-2xl px-4 py-2.5 text-white focus:outline-none focus:border-zinc-400"
                />
              </div>

              <div className="pt-3 border-t border-[#222432] flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowAddCustom(false)}
                  className="px-5 py-2.5 rounded-2xl bg-zinc-800 text-zinc-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-2xl bg-white text-black font-black hover:bg-zinc-200"
                >
                  Save Exercise
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

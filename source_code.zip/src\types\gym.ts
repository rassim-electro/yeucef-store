export type MuscleGroup =
  | 'Chest'
  | 'Back'
  | 'Shoulders'
  | 'Biceps'
  | 'Triceps'
  | 'Quads'
  | 'Hamstrings'
  | 'Glutes'
  | 'Calves'
  | 'Core'
  | 'Full Body';

export type EquipmentType =
  | 'Barbell'
  | 'Dumbbell'
  | 'Cable'
  | 'Machine'
  | 'Bodyweight'
  | 'Smith Machine'
  | 'Other';

export type SetType = 'Normal' | 'Warmup' | 'Drop' | 'Failure';

export interface ExerciseDefinition {
  id: string;
  name: string;
  muscleGroup: MuscleGroup;
  secondaryMuscles?: string[];
  equipment: EquipmentType;
  instructions: string[];
  tips: string[];
  defaultRestSeconds: number;
}

export interface WorkoutSet {
  id: string;
  setNumber: number;
  type: SetType;
  weight: number; // in current unit (kg or lbs)
  reps: number;
  rpe?: number; // 6 to 10
  completed: boolean;
  previousWeight?: number;
  previousReps?: number;
}

export interface WorkoutExercise {
  exerciseId: string;
  exerciseName: string;
  muscleGroup: MuscleGroup;
  notes?: string;
  sets: WorkoutSet[];
}

export interface CompletedWorkout {
  id: string;
  name: string;
  routineId?: string;
  startTime: string; // ISO
  endTime: string;   // ISO
  durationMinutes: number;
  exercises: WorkoutExercise[];
  notes?: string;
  totalVolume: number; // sum of (weight * reps) for completed sets
  prsAchieved: number;
}

export interface RoutineExercise {
  exerciseId: string;
  targetSets: number;
  targetReps: string; // e.g., "8-12"
  defaultRestSeconds: number;
}

export interface Routine {
  id: string;
  name: string;
  description: string;
  targetSplit: string; // e.g. "Push / Pull / Legs"
  estimatedMinutes: number;
  exercises: RoutineExercise[];
}

export interface BodyMeasurement {
  id: string;
  date: string; // YYYY-MM-DD
  weight: number;
  bodyFatPercent?: number;
  chestCm?: number;
  waistCm?: number;
  armsCm?: number;
  thighsCm?: number;
  notes?: string;
}

export interface PersonalRecord {
  exerciseId: string;
  exerciseName: string;
  maxWeight: number;
  maxReps: number;
  estimated1RM: number;
  date: string;
}

export type WeightUnit = 'kg' | 'lbs';

import React, { useState, useEffect, useRef } from 'react';
import { Navbar } from './components/Navbar';
import { RestTimer } from './components/RestTimer';
import { PlateCalculatorModal } from './components/PlateCalculatorModal';
import { OneRepMaxModal } from './components/OneRepMaxModal';
import { OverloadGuideModal } from './components/OverloadGuideModal';
import { LiveWorkoutModal } from './components/LiveWorkoutModal';
import { MotivationModal } from './components/MotivationModal';

// Views
import { DashboardView } from './components/views/DashboardView';
import { WorkoutView } from './components/views/WorkoutView';
import { RoutinesView } from './components/views/RoutinesView';
import { ExercisesView } from './components/views/ExercisesView';
import { AnalyticsView } from './components/views/AnalyticsView';
import { BodyTrackerView } from './components/views/BodyTrackerView';
import { ToolsView } from './components/views/ToolsView';

// Types & Storage
import {
  CompletedWorkout,
  Routine,
  ExerciseDefinition,
  BodyMeasurement,
  WeightUnit
} from './types/gym';
import {
  loadWorkouts,
  saveWorkouts,
  loadRoutines,
  saveRoutines,
  loadExercises,
  saveExercises,
  loadMeasurements,
  saveMeasurements,
  loadWeightUnit,
  saveWeightUnit,
  loadActiveWorkout,
  saveActiveWorkout,
  computePersonalRecords,
  exportAllData,
  importAllData,
  resetAllDataToDefault,
  ActiveWorkoutState
} from './utils/storage';
import {
  Language,
  TRANSLATIONS,
  loadLanguage,
  saveLanguage,
  loadHideMotivation
} from './utils/i18n';

export function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  // Language state: 'en' or 'ar'
  const [lang, setLang] = useState<Language>('en');

  // Core Gym Data
  const [workouts, setWorkouts] = useState<CompletedWorkout[]>([]);
  const [routines, setRoutines] = useState<Routine[]>([]);
  const [exercises, setExercises] = useState<ExerciseDefinition[]>([]);
  const [measurements, setMeasurements] = useState<BodyMeasurement[]>([]);
  const [weightUnit, setWeightUnit] = useState<WeightUnit>('kg');

  // Active workout
  const [activeWorkout, setActiveWorkout] = useState<ActiveWorkoutState | null>(null);
  const [isLiveWorkoutModalOpen, setIsLiveWorkoutModalOpen] = useState(false);

  // Motivation Letter Modal
  const [isMotivationModalOpen, setIsMotivationModalOpen] = useState(false);

  // Floating Rest Timer Modal
  const [restTimer, setRestTimer] = useState<{ isOpen: boolean; seconds: number }>({
    isOpen: false,
    seconds: 90
  });

  // Utility modals
  const [plateCalcModal, setPlateCalcModal] = useState<{ isOpen: boolean; initialWeight: number }>({
    isOpen: false,
    initialWeight: 100
  });
  const [oneRepMaxModal, setOneRepMaxModal] = useState<{ isOpen: boolean; initialWeight: number }>({
    isOpen: false,
    initialWeight: 80
  });
  const [overloadModalOpen, setOverloadModalOpen] = useState(false);

  // Hidden file input for JSON import
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Initial load
  useEffect(() => {
    const savedLang = loadLanguage();
    setLang(savedLang);
    document.documentElement.dir = savedLang === 'ar' ? 'rtl' : 'ltr';

    setWorkouts(loadWorkouts());
    setRoutines(loadRoutines());
    setExercises(loadExercises());
    setMeasurements(loadMeasurements());
    setWeightUnit(loadWeightUnit());

    const savedActive = loadActiveWorkout();
    if (savedActive) {
      setActiveWorkout(savedActive);
    }

    // Check if user has seen or opted out of motivation letter
    const hideMotivation = loadHideMotivation();
    if (!hideMotivation) {
      setIsMotivationModalOpen(true);
    }
  }, []);

  // Compute Personal Records
  const prs = computePersonalRecords(workouts);
  const prMap = new Map<string, number>();
  for (const pr of prs) {
    prMap.set(pr.exerciseId, pr.maxWeight);
  }

  // Toggle unit
  const handleToggleUnit = () => {
    const nextUnit: WeightUnit = weightUnit === 'kg' ? 'lbs' : 'kg';
    setWeightUnit(nextUnit);
    saveWeightUnit(nextUnit);
  };

  // Toggle language (EN / AR)
  const handleToggleLanguage = () => {
    const nextLang: Language = lang === 'en' ? 'ar' : 'en';
    setLang(nextLang);
    saveLanguage(nextLang);
    document.documentElement.dir = nextLang === 'ar' ? 'rtl' : 'ltr';
  };

  // Start Empty Workout
  const handleStartEmptyWorkout = () => {
    const newSession: ActiveWorkoutState = {
      id: `session-${Date.now()}`,
      name: lang === 'ar' ? 'جلسة تدريب حرة' : 'Freestyle Gym Session',
      startTime: new Date().toISOString(),
      elapsedSeconds: 0,
      exercises: []
    };
    setActiveWorkout(newSession);
    saveActiveWorkout(newSession);
    setIsLiveWorkoutModalOpen(true);
  };

  // Start Routine Workout
  const handleStartRoutine = (routine: Routine) => {
    const routineExercises = routine.exercises.map(re => {
      const def = exercises.find(e => e.id === re.exerciseId);
      const parsedReps = parseInt(re.targetReps.split('-')[0]) || 8;

      return {
        exerciseId: re.exerciseId,
        exerciseName: def ? def.name : re.exerciseId,
        muscleGroup: def ? def.muscleGroup : ('Full Body' as const),
        sets: Array.from({ length: re.targetSets }).map((_, idx) => ({
          id: `set-${Date.now()}-${idx + 1}`,
          setNumber: idx + 1,
          type: 'Normal' as const,
          weight: weightUnit === 'kg' ? 60 : 135,
          reps: parsedReps,
          completed: false
        }))
      };
    });

    const newSession: ActiveWorkoutState = {
      id: `session-${Date.now()}`,
      name: routine.name,
      routineId: routine.id,
      startTime: new Date().toISOString(),
      elapsedSeconds: 0,
      exercises: routineExercises
    };

    setActiveWorkout(newSession);
    saveActiveWorkout(newSession);
    setIsLiveWorkoutModalOpen(true);
  };

  // Update active workout
  const handleUpdateActiveWorkout = (workout: ActiveWorkoutState | null) => {
    setActiveWorkout(workout);
    saveActiveWorkout(workout);
  };

  // Finish Workout
  const handleFinishWorkout = (completed: CompletedWorkout) => {
    const updated = [completed, ...workouts];
    setWorkouts(updated);
    saveWorkouts(updated);
    setActiveWorkout(null);
    saveActiveWorkout(null);
    setIsLiveWorkoutModalOpen(false);
    setActiveTab('history');
  };

  // Delete workout
  const handleDeleteWorkout = (id: string) => {
    const updated = workouts.filter(w => w.id !== id);
    setWorkouts(updated);
    saveWorkouts(updated);
  };

  // Save routine
  const handleSaveRoutine = (newRoutine: Routine) => {
    const updated = [newRoutine, ...routines];
    setRoutines(updated);
    saveRoutines(updated);
  };

  // Delete routine
  const handleDeleteRoutine = (id: string) => {
    const updated = routines.filter(r => r.id !== id);
    setRoutines(updated);
    saveRoutines(updated);
  };

  // Add custom exercise
  const handleAddCustomExercise = (newEx: ExerciseDefinition) => {
    const updated = [newEx, ...exercises];
    setExercises(updated);
    saveExercises(updated);
  };

  // Add body measurement
  const handleAddMeasurement = (newM: BodyMeasurement) => {
    const updated = [newM, ...measurements];
    setMeasurements(updated);
    saveMeasurements(updated);
  };

  // Delete body measurement
  const handleDeleteMeasurement = (id: string) => {
    const updated = measurements.filter(m => m.id !== id);
    setMeasurements(updated);
    saveMeasurements(updated);
  };

  // Data Export & Import
  const handleExport = () => {
    exportAllData();
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = ev => {
      const content = ev.target?.result as string;
      if (content) {
        const ok = importAllData(content);
        if (ok) {
          alert(lang === 'ar' ? 'تم استيراد البيانات بنجاح في إنفينيتي جيم!' : 'Data successfully imported into Infinity Gym!');
          setWorkouts(loadWorkouts());
          setRoutines(loadRoutines());
          setExercises(loadExercises());
          setMeasurements(loadMeasurements());
          setWeightUnit(loadWeightUnit());
        } else {
          alert('Failed to parse backup file. Please check file format.');
        }
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleResetData = () => {
    const msg = lang === 'ar'
      ? 'هل أنت متأكد من إعادة ضبط التطبيق للبيانات الافتراضية؟'
      : 'Reset Infinity Gym to default sample routines and workouts?';
    if (confirm(msg)) {
      resetAllDataToDefault();
      setWorkouts(loadWorkouts());
      setRoutines(loadRoutines());
      setExercises(loadExercises());
      setMeasurements(loadMeasurements());
      setWeightUnit('kg');
      setActiveWorkout(null);
    }
  };

  // Rest Timer opener
  const handleStartRestTimer = (seconds = 90) => {
    setRestTimer({ isOpen: true, seconds });
  };

  const formatSessionDuration = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const s = secs % 60;
    return `${mins < 10 ? '0' : ''}${mins}:${s < 10 ? '0' : ''}${s}`;
  };

  const t = TRANSLATIONS[lang];

  return (
    <div
      className="min-h-screen bg-[#08080a] text-zinc-100 flex flex-col selection:bg-zinc-700 selection:text-white"
      dir={lang === 'ar' ? 'rtl' : 'ltr'}
    >
      {/* Hidden file input for JSON import */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept=".json"
        className="hidden"
      />

      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        weightUnit={weightUnit}
        onToggleUnit={handleToggleUnit}
        lang={lang}
        onToggleLanguage={handleToggleLanguage}
        hasActiveWorkout={Boolean(activeWorkout)}
        activeWorkoutDuration={formatSessionDuration(activeWorkout?.elapsedSeconds || 0)}
        onOpenActiveWorkout={() => setIsLiveWorkoutModalOpen(true)}
        onStartNewWorkout={handleStartEmptyWorkout}
        onOpenMotivation={() => setIsMotivationModalOpen(true)}
        onExport={handleExport}
        onImport={handleImportClick}
        onReset={handleResetData}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {activeTab === 'dashboard' && (
          <DashboardView
            workouts={workouts}
            personalRecords={prs}
            routines={routines}
            weightUnit={weightUnit}
            lang={lang}
            onStartRoutine={handleStartRoutine}
            onStartEmptyWorkout={handleStartEmptyWorkout}
            onOpenPlateCalc={() => setPlateCalcModal({ isOpen: true, initialWeight: 100 })}
            onOpen1RMCalc={() => setOneRepMaxModal({ isOpen: true, initialWeight: 80 })}
            onOpenOverloadGuide={() => setOverloadModalOpen(true)}
            onOpenMotivation={() => setIsMotivationModalOpen(true)}
            onViewAllWorkouts={() => setActiveTab('history')}
            onViewAllRoutines={() => setActiveTab('routines')}
          />
        )}

        {activeTab === 'routines' && (
          <RoutinesView
            routines={routines}
            exercises={exercises}
            onStartRoutine={handleStartRoutine}
            onSaveRoutine={handleSaveRoutine}
            onDeleteRoutine={handleDeleteRoutine}
          />
        )}

        {activeTab === 'history' && (
          <WorkoutView
            workouts={workouts}
            weightUnit={weightUnit}
            onDeleteWorkout={handleDeleteWorkout}
            onStartNewWorkout={handleStartEmptyWorkout}
          />
        )}

        {activeTab === 'exercises' && (
          <ExercisesView
            exercises={exercises}
            onAddCustomExercise={handleAddCustomExercise}
          />
        )}

        {activeTab === 'analytics' && (
          <AnalyticsView
            workouts={workouts}
            weightUnit={weightUnit}
          />
        )}

        {activeTab === 'body' && (
          <BodyTrackerView
            measurements={measurements}
            weightUnit={weightUnit}
            onAddMeasurement={handleAddMeasurement}
            onDeleteMeasurement={handleDeleteMeasurement}
          />
        )}

        {activeTab === 'tools' && (
          <ToolsView weightUnit={weightUnit} />
        )}
      </main>

      {/* Client Motivation Letter Modal */}
      <MotivationModal
        isOpen={isMotivationModalOpen}
        onClose={() => setIsMotivationModalOpen(false)}
        lang={lang}
      />

      {/* Live Active Workout Modal */}
      <LiveWorkoutModal
        isOpen={isLiveWorkoutModalOpen}
        onClose={() => setIsLiveWorkoutModalOpen(false)}
        activeWorkout={activeWorkout}
        onUpdateActiveWorkout={handleUpdateActiveWorkout}
        onFinishWorkout={handleFinishWorkout}
        exerciseCatalog={exercises}
        weightUnit={weightUnit}
        onStartRestTimer={handleStartRestTimer}
        onOpenPlateCalc={weight => setPlateCalcModal({ isOpen: true, initialWeight: weight || 100 })}
        personalRecordsMap={prMap}
      />

      {/* Floating Rest Timer */}
      <RestTimer
        isOpen={restTimer.isOpen}
        initialSeconds={restTimer.seconds}
        onClose={() => setRestTimer({ isOpen: false, seconds: 90 })}
      />

      {/* Plate Calculator Modal */}
      <PlateCalculatorModal
        isOpen={plateCalcModal.isOpen}
        onClose={() => setPlateCalcModal({ isOpen: false, initialWeight: 100 })}
        weightUnit={weightUnit}
        initialWeight={plateCalcModal.initialWeight}
      />

      {/* 1RM Calculator Modal */}
      <OneRepMaxModal
        isOpen={oneRepMaxModal.isOpen}
        onClose={() => setOneRepMaxModal({ isOpen: false, initialWeight: 80 })}
        weightUnit={weightUnit}
        initialWeight={oneRepMaxModal.initialWeight}
      />

      {/* Progressive Overload Guide Modal */}
      <OverloadGuideModal
        isOpen={overloadModalOpen}
        onClose={() => setOverloadModalOpen(false)}
        weightUnit={weightUnit}
      />

      {/* Footer */}
      <footer className="border-t border-[#1a1b26] py-8 text-center text-xs sm:text-sm text-zinc-400 bg-[#07080a]">
        <div className="flex items-center justify-center gap-2 mb-2 font-mono font-black text-sm sm:text-base text-zinc-200">
          <span>∞ INFINITY GYM • إنفينيتي جيم</span>
        </div>
        <p className="text-xs text-zinc-500 max-w-md mx-auto">
          {lang === 'ar'
            ? 'صُمم بمظهر أسود ورمادي أنيق لعشاق القوة والتطور التدريجي.'
            : 'Crafted in dark black & grey aesthetic for lifters dedicated to relentless progressive overload.'}
        </p>
      </footer>
    </div>
  );
}

export default App;

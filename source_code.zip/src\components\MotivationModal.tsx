import React, { useState } from 'react';
import { X, Flame, Shield, Award, Sparkles, Dumbbell } from 'lucide-react';
import { InfinityGymLogo } from './InfinityGymLogo';
import { Language, TRANSLATIONS, saveHideMotivation } from '../utils/i18n';
import { playPRChime } from '../utils/sound';

interface MotivationModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const MotivationModal: React.FC<MotivationModalProps> = ({
  isOpen,
  onClose,
  lang
}) => {
  const [dontShowAgain, setDontShowAgain] = useState(false);
  const t = TRANSLATIONS[lang];
  const isArabic = lang === 'ar';

  if (!isOpen) return null;

  const handleConfirm = () => {
    if (dontShowAgain) {
      saveHideMotivation(true);
    }
    playPRChime();
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/90 backdrop-blur-md overflow-y-auto"
      dir={isArabic ? 'rtl' : 'ltr'}
    >
      <div className="bg-gradient-to-b from-[#14161f] via-[#101217] to-[#0a0b0e] border border-zinc-700/80 rounded-3xl w-full max-w-2xl max-h-[92vh] flex flex-col overflow-hidden shadow-[0_0_50px_rgba(0,0,0,0.9)] relative my-auto">
        {/* Ambient Top Glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-28 bg-zinc-600/10 rounded-full blur-3xl pointer-events-none" />

        {/* Top Header */}
        <div className="p-5 sm:p-6 pb-2 text-center relative border-b border-zinc-800/80">
          <button
            onClick={onClose}
            className={`absolute top-5 ${isArabic ? 'left-5' : 'right-5'} p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors`}
            title={t.minimize}
          >
            <X size={20} />
          </button>

          {/* Logo */}
          <div className="mb-2">
            <InfinityGymLogo size="lg" showText={true} />
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-zinc-850 border border-zinc-700 text-zinc-300 text-xs font-bold uppercase tracking-widest mt-1">
            <Flame size={14} className="text-zinc-200" />
            <span>{t.motivationTitle}</span>
          </div>

          <h2 className="text-base sm:text-lg font-bold text-zinc-400 mt-2">
            {t.motivationSubtitle}
          </h2>
        </div>

        {/* Scrollable Letter Body */}
        <div className="p-5 sm:p-8 overflow-y-auto space-y-6 text-sm sm:text-base leading-relaxed text-zinc-200">
          {/* Greeting */}
          <div className={`${isArabic ? 'border-r-4 sm:border-r-[5px] pr-4' : 'border-l-4 sm:border-l-[5px] pl-4'} border-zinc-400 py-1 font-extrabold text-white text-base sm:text-xl`}>
            {t.motivationGreeting}
          </div>

          <p className="text-zinc-300 leading-relaxed font-normal">
            {t.motivationBodyP1}
          </p>

          <p className="text-zinc-300 leading-relaxed font-normal">
            {t.motivationBodyP2}
          </p>

          {/* 3 Core Rules Card Box */}
          <div className="space-y-4 bg-[#171923] p-4 sm:p-5 rounded-2xl border border-zinc-750/90 shadow-inner">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-xl bg-zinc-850 flex items-center justify-center text-zinc-200 flex-shrink-0 mt-0.5 border border-zinc-700">
                <Shield size={16} />
              </div>
              <div>
                <h4 className="font-extrabold text-white text-sm sm:text-base mb-1">
                  {t.motivationRule1Title}
                </h4>
                <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">
                  {t.motivationRule1Desc}
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 pt-3 border-t border-zinc-800">
              <div className="w-8 h-8 rounded-xl bg-zinc-850 flex items-center justify-center text-zinc-200 flex-shrink-0 mt-0.5 border border-zinc-700">
                <Dumbbell size={16} />
              </div>
              <div>
                <h4 className="font-extrabold text-white text-sm sm:text-base mb-1">
                  {t.motivationRule2Title}
                </h4>
                <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">
                  {t.motivationRule2Desc}
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 pt-3 border-t border-zinc-800">
              <div className="w-8 h-8 rounded-xl bg-zinc-850 flex items-center justify-center text-zinc-200 flex-shrink-0 mt-0.5 border border-zinc-700">
                <Award size={16} />
              </div>
              <div>
                <h4 className="font-extrabold text-white text-sm sm:text-base mb-1">
                  {t.motivationRule3Title}
                </h4>
                <p className="text-xs sm:text-sm text-zinc-400 leading-relaxed">
                  {t.motivationRule3Desc}
                </p>
              </div>
            </div>
          </div>

          {/* Closing Manifesto */}
          <div className="bg-gradient-to-r from-zinc-900 to-black p-4 rounded-xl border border-zinc-800 text-center font-bold text-white text-sm sm:text-base italic">
            "{t.motivationClosing}"
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 sm:p-6 bg-[#0c0d12] border-t border-zinc-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <label className="flex items-center gap-2 text-xs sm:text-sm text-zinc-400 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={dontShowAgain}
              onChange={e => setDontShowAgain(e.target.checked)}
              className="w-4 h-4 rounded border-zinc-700 bg-zinc-900 text-white focus:ring-0 cursor-pointer"
            />
            <span>{t.doNotShowAgain}</span>
          </label>

          <button
            onClick={handleConfirm}
            className="w-full sm:w-auto px-7 py-3.5 rounded-2xl bg-gradient-to-r from-zinc-100 via-white to-zinc-300 text-black font-black text-sm sm:text-base uppercase tracking-wider hover:from-white hover:to-zinc-200 transition-all shadow-xl hover:shadow-white/20 active:scale-95 flex items-center justify-center gap-2"
          >
            <Sparkles size={18} fill="currentColor" />
            <span>{t.enterGymBtn}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

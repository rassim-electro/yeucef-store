import React, { useState } from 'react';
import { X, TrendingUp, Zap, HelpCircle, CheckCircle2, ShieldAlert } from 'lucide-react';
import { WeightUnit } from '../types/gym';
import { generateOverloadAdvice } from '../utils/calculators';

interface OverloadGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  weightUnit: WeightUnit;
}

export const OverloadGuideModal: React.FC<OverloadGuideModalProps> = ({
  isOpen,
  onClose,
  weightUnit
}) => {
  const [activeTab, setActiveTab] = useState<'simulator' | 'principles'>('simulator');
  const [testWeight, setTestWeight] = useState<number>(80);
  const [set1, setSet1] = useState<number>(10);
  const [set2, setSet2] = useState<number>(10);
  const [set3, setSet3] = useState<number>(10);
  const [minRep, setMinRep] = useState<number>(8);
  const [maxRep, setMaxRep] = useState<number>(10);

  if (!isOpen) return null;

  const advice = generateOverloadAdvice(
    testWeight,
    [set1, set2, set3],
    minRep,
    maxRep,
    weightUnit
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
      <div className="bg-[#101116] border border-[#2b2d39] rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-[#222430]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-zinc-700 to-zinc-900 border border-zinc-650 flex items-center justify-center text-white">
              <TrendingUp size={18} />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Progressive Overload Advisor</h3>
              <p className="text-xs text-zinc-400">The #1 scientific key to building muscle and breaking plateaus</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-[#222430] px-5 pt-3 gap-3 bg-[#13141a]">
          <button
            onClick={() => setActiveTab('simulator')}
            className={`pb-2.5 text-xs font-bold uppercase tracking-wider border-b-2 transition-all ${
              activeTab === 'simulator'
                ? 'border-white text-white'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Interactive Next-Session Advisor
          </button>
          <button
            onClick={() => setActiveTab('principles')}
            className={`pb-2.5 text-xs font-bold uppercase tracking-wider border-b-2 transition-all ${
              activeTab === 'principles'
                ? 'border-white text-white'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            The 4 Overload Rules
          </button>
        </div>

        <div className="p-5">
          {activeTab === 'simulator' ? (
            <div className="space-y-6">
              <p className="text-xs text-zinc-400 leading-relaxed">
                Enter your last workout's performance for any exercise to generate your exact prescription for next time.
              </p>

              {/* Input Form */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-[#15171f] p-4 rounded-xl border border-[#262835]">
                <div>
                  <label className="block text-[11px] font-semibold text-zinc-400 uppercase tracking-wider mb-1">
                    Current Weight ({weightUnit})
                  </label>
                  <input
                    type="number"
                    step="2.5"
                    value={testWeight || ''}
                    onChange={e => setTestWeight(parseFloat(e.target.value) || 0)}
                    className="w-full bg-[#1b1c24] border border-[#2f3140] rounded-lg px-3 py-2 text-white font-mono font-bold text-sm focus:outline-none focus:border-zinc-400"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-zinc-400 uppercase tracking-wider mb-1">
                    Target Rep Range
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      value={minRep}
                      onChange={e => setMinRep(parseInt(e.target.value) || 6)}
                      className="w-16 bg-[#1b1c24] border border-[#2f3140] rounded-lg px-2 py-2 text-white font-mono text-center text-sm font-bold"
                    />
                    <span className="text-zinc-500 font-bold">to</span>
                    <input
                      type="number"
                      value={maxRep}
                      onChange={e => setMaxRep(parseInt(e.target.value) || 12)}
                      className="w-16 bg-[#1b1c24] border border-[#2f3140] rounded-lg px-2 py-2 text-white font-mono text-center text-sm font-bold"
                    />
                    <span className="text-xs text-zinc-400">reps</span>
                  </div>
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-semibold text-zinc-400 uppercase tracking-wider mb-1">
                    Reps Logged in Last 3 Sets
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <span className="text-[10px] text-zinc-500 block mb-0.5">Set 1</span>
                      <input
                        type="number"
                        value={set1}
                        onChange={e => setSet1(parseInt(e.target.value) || 0)}
                        className="w-full bg-[#1b1c24] border border-[#2f3140] rounded-lg px-3 py-1.5 text-white font-mono text-center font-bold"
                      />
                    </div>
                    <div>
                      <span className="text-[10px] text-zinc-500 block mb-0.5">Set 2</span>
                      <input
                        type="number"
                        value={set2}
                        onChange={e => setSet2(parseInt(e.target.value) || 0)}
                        className="w-full bg-[#1b1c24] border border-[#2f3140] rounded-lg px-3 py-1.5 text-white font-mono text-center font-bold"
                      />
                    </div>
                    <div>
                      <span className="text-[10px] text-zinc-500 block mb-0.5">Set 3</span>
                      <input
                        type="number"
                        value={set3}
                        onChange={e => setSet3(parseInt(e.target.value) || 0)}
                        className="w-full bg-[#1b1c24] border border-[#2f3140] rounded-lg px-3 py-1.5 text-white font-mono text-center font-bold"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Recommendation Output Card */}
              <div
                className={`rounded-2xl p-5 border shadow-xl ${
                  advice.status === 'INCREASE_WEIGHT'
                    ? 'bg-emerald-950/20 border-emerald-500/40'
                    : advice.status === 'ADD_REPS'
                    ? 'bg-zinc-900 border-zinc-700'
                    : advice.status === 'DELOAD'
                    ? 'bg-red-950/20 border-red-500/40'
                    : 'bg-zinc-900/60 border-zinc-800'
                }`}
              >
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-base font-extrabold text-white">
                    {advice.headline}
                  </span>
                </div>
                <div className="text-sm font-semibold text-zinc-200 mb-3 bg-black/40 p-3 rounded-xl border border-white/5 font-mono">
                  👉 {advice.recommendedAction}
                </div>
                <p className="text-xs text-zinc-300 leading-relaxed mb-4">
                  {advice.reasoning}
                </p>

                <div className="space-y-1.5 pt-3 border-t border-zinc-800/80">
                  <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider block">
                    Execution Checklist:
                  </span>
                  {advice.tips.map((tip, i) => (
                    <div key={i} className="flex items-start gap-2 text-xs text-zinc-300">
                      <CheckCircle2 size={13} className="text-zinc-400 mt-0.5 flex-shrink-0" />
                      <span>{tip}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-4 text-xs">
              <div className="p-4 rounded-xl bg-[#15171f] border border-[#262835]">
                <h4 className="font-bold text-white text-sm mb-1 flex items-center gap-1.5">
                  <Zap size={14} className="text-zinc-300" /> 1. The Double Progression Method
                </h4>
                <p className="text-zinc-300 leading-relaxed">
                  Instead of forcing weight increases every single week, choose a rep range (e.g. 8 to 12 reps).
                  Start at a weight where you get 8 reps. In subsequent workouts, keep the weight the same and aim for 9, 10, 11, then 12 reps.
                  Once you hit 12 reps on all sets with immaculate form, bump the weight by 2.5 kg (or 5 lbs) and drop back down to 8 reps.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#15171f] border border-[#262835]">
                <h4 className="font-bold text-white text-sm mb-1 flex items-center gap-1.5">
                  <TrendingUp size={14} className="text-zinc-300" /> 2. Track Every Single Set
                </h4>
                <p className="text-zinc-300 leading-relaxed">
                  If you don't track your numbers, you cannot know if you are progressing.
                  Infinity Gym logs your previous weights and reps right inside the workout screen so you always know the exact number to beat.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#15171f] border border-[#262835]">
                <h4 className="font-bold text-white text-sm mb-1 flex items-center gap-1.5">
                  <CheckCircle2 size={14} className="text-zinc-300" /> 3. Form Before Load
                </h4>
                <p className="text-zinc-300 leading-relaxed">
                  Adding weight while sacrificing range of motion is fake progression. Control the 2-second eccentric (lowering phase), pause slightly, and lift under control. A rep performed with clean tempo builds 2x more muscle than a swinging rep.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#15171f] border border-[#262835]">
                <h4 className="font-bold text-white text-sm mb-1 flex items-center gap-1.5">
                  <ShieldAlert size={14} className="text-zinc-300" /> 4. Deload When Stalled
                </h4>
                <p className="text-zinc-300 leading-relaxed">
                  If you fail to progress on a lift for 3 consecutive workouts, your body is carrying fatigue. Deload the weight by 10% for one week, focus on explosive speed and form, then ramp back up. You will routinely smash through your old plateau.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#0d0e12] border-t border-[#222430] flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-semibold transition-colors"
          >
            Got It
          </button>
        </div>
      </div>
    </div>
  );
};

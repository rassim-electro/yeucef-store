import React, { useState, useEffect } from 'react';
import {
  X,
  Plus,
  Trash2,
  Check,
  Timer,
  Dumbbell,
  Layers,
  ChevronDown,
  Sparkles,
  Flame,
  Award,
  AlertTriangle
} from 'lucide-react';
import confetti from 'canvas-confetti';
import {
  WorkoutExercise,
  WorkoutSet,
  WeightUnit,
  CompletedWorkout,
  ExerciseDefinition,
  SetType
} from '../types/gym';
import { ActiveWorkoutState } from '../utils/storage';
import { playPRChime } from '../utils/sound';

interface LiveWorkoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeWorkout: ActiveWorkoutState | null;
  onUpdateActiveWorkout: (workout: ActiveWorkoutState | null) => void;
  onFinishWorkout: (completed: CompletedWorkout) => void;
  exerciseCatalog: ExerciseDefinition[];
  weightUnit: WeightUnit;
  onStartRestTimer: (seconds?: number) => void;
  onOpenPlateCalc: (weight: number) => void;
  personalRecordsMap: Map<string, number>; // exerciseId -> maxWeight
}

export const LiveWorkoutModal: React.FC<LiveWorkoutModalProps> = ({
  isOpen,
  onClose,
  activeWorkout,
  onUpdateActiveWorkout,
  onFinishWorkout,
  exerciseCatalog,
  weightUnit,
  onStartRestTimer,
  onOpenPlateCalc,
  personalRecordsMap
}) => {
  const [showExercisePicker, setShowExercisePicker] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMuscleFilter, setSelectedMuscleFilter] = useState<string>('All');
  const [elapsed, setElapsed] = useState(0);
  const [showDiscardConfirm, setShowDiscardConfirm] = useState(false);
  const [newPrNotice, setNewPrNotice] = useState<string | null>(null);

  // Timer
  useEffect(() => {
    if (!isOpen || !activeWorkout) return;
    setElapsed(activeWorkout.elapsedSeconds || 0);

    const interval = setInterval(() => {
      setElapsed(prev => {
        const next = prev + 1;
        // Periodic sync
        if (next % 5 === 0 && activeWorkout) {
          onUpdateActiveWorkout({ ...activeWorkout, elapsedSeconds: next });
        }
        return next;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isOpen, activeWorkout?.id]);

  if (!isOpen || !activeWorkout) return null;

  const formatDuration = (secs: number) => {
    const hrs = Math.floor(secs / 3600);
    const mins = Math.floor((secs % 3600) / 60);
    const s = secs % 60;
    if (hrs > 0) {
      return `${hrs}h ${mins}m ${s < 10 ? '0' : ''}${s}s`;
    }
    return `${mins < 10 ? '0' : ''}${mins}:${s < 10 ? '0' : ''}${s}`;
  };

  // Stats
  let totalVolume = 0;
  let totalSetsDone = 0;
  for (const ex of activeWorkout.exercises) {
    for (const set of ex.sets) {
      if (set.completed && set.type !== 'Warmup') {
        totalVolume += (set.weight || 0) * (set.reps || 0);
        totalSetsDone++;
      }
    }
  }

  // Update workout title
  const handleTitleChange = (newTitle: string) => {
    onUpdateActiveWorkout({
      ...activeWorkout,
      name: newTitle,
      elapsedSeconds: elapsed
    });
  };

  // Add exercise to active session
  const handleAddExercise = (def: ExerciseDefinition) => {
    const newEx: WorkoutExercise = {
      exerciseId: def.id,
      exerciseName: def.name,
      muscleGroup: def.muscleGroup,
      sets: [
        {
          id: `set-${Date.now()}-1`,
          setNumber: 1,
          type: 'Normal',
          weight: weightUnit === 'kg' ? 60 : 135,
          reps: 8,
          completed: false
        }
      ]
    };

    onUpdateActiveWorkout({
      ...activeWorkout,
      exercises: [...activeWorkout.exercises, newEx],
      elapsedSeconds: elapsed
    });
    setShowExercisePicker(false);
  };

  // Remove exercise
  const handleRemoveExercise = (exerciseIndex: number) => {
    const updated = activeWorkout.exercises.filter((_, idx) => idx !== exerciseIndex);
    onUpdateActiveWorkout({
      ...activeWorkout,
      exercises: updated,
      elapsedSeconds: elapsed
    });
  };

  // Add Set to exercise
  const handleAddSet = (exerciseIndex: number) => {
    const ex = activeWorkout.exercises[exerciseIndex];
    const lastSet = ex.sets[ex.sets.length - 1];

    const newSet: WorkoutSet = {
      id: `set-${Date.now()}-${ex.sets.length + 1}`,
      setNumber: ex.sets.length + 1,
      type: lastSet ? lastSet.type : 'Normal',
      weight: lastSet ? lastSet.weight : 50,
      reps: lastSet ? lastSet.reps : 8,
      completed: false
    };

    const updated = [...activeWorkout.exercises];
    updated[exerciseIndex] = {
      ...ex,
      sets: [...ex.sets, newSet]
    };

    onUpdateActiveWorkout({
      ...activeWorkout,
      exercises: updated,
      elapsedSeconds: elapsed
    });
  };

  // Remove set
  const handleRemoveSet = (exerciseIndex: number, setIndex: number) => {
    const ex = activeWorkout.exercises[exerciseIndex];
    const filteredSets = ex.sets.filter((_, idx) => idx !== setIndex).map((s, idx) => ({
      ...s,
      setNumber: idx + 1
    }));

    const updated = [...activeWorkout.exercises];
    updated[exerciseIndex] = {
      ...ex,
      sets: filteredSets
    };

    onUpdateActiveWorkout({
      ...activeWorkout,
      exercises: updated,
      elapsedSeconds: elapsed
    });
  };

  // Update set field
  const handleUpdateSet = (
    exerciseIndex: number,
    setIndex: number,
    field: keyof WorkoutSet,
    val: unknown
  ) => {
    const ex = activeWorkout.exercises[exerciseIndex];
    const set = ex.sets[setIndex];
    const updatedSet = { ...set, [field]: val };

    // If marked completed, trigger rest timer & check PR!
    if (field === 'completed' && val === true) {
      const def = exerciseCatalog.find(e => e.id === ex.exerciseId);
      const restTime = def?.defaultRestSeconds || 90;
      onStartRestTimer(restTime);

      // PR Check
      const previousMax = personalRecordsMap.get(ex.exerciseId) || 0;
      if (set.type !== 'Warmup' && updatedSet.weight > previousMax && previousMax > 0) {
        // New PR!
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 }
        });
        playPRChime();
        setNewPrNotice(`🏆 New PR on ${ex.exerciseName}: ${updatedSet.weight} ${weightUnit}!`);
        setTimeout(() => setNewPrNotice(null), 4500);
      }
    }

    const updatedSets = [...ex.sets];
    updatedSets[setIndex] = updatedSet;

    const updatedEx = [...activeWorkout.exercises];
    updatedEx[exerciseIndex] = {
      ...ex,
      sets: updatedSets
    };

    onUpdateActiveWorkout({
      ...activeWorkout,
      exercises: updatedEx,
      elapsedSeconds: elapsed
    });
  };

  // Finish Workout
  const handleFinish = () => {
    let prsAchieved = 0;
    for (const ex of activeWorkout.exercises) {
      const previousMax = personalRecordsMap.get(ex.exerciseId) || 0;
      for (const s of ex.sets) {
        if (s.completed && s.type !== 'Warmup' && s.weight > previousMax && previousMax > 0) {
          prsAchieved++;
          break;
        }
      }
    }

    const completed: CompletedWorkout = {
      id: `wk-${Date.now()}`,
      name: activeWorkout.name || 'Workout Session',
      routineId: activeWorkout.routineId,
      startTime: activeWorkout.startTime,
      endTime: new Date().toISOString(),
      durationMinutes: Math.max(1, Math.round(elapsed / 60)),
      totalVolume,
      prsAchieved,
      exercises: activeWorkout.exercises,
      notes: activeWorkout.notes
    };

    confetti({
      particleCount: 120,
      spread: 90,
      origin: { y: 0.5 }
    });

    onFinishWorkout(completed);
  };

  // Discard
  const handleDiscard = () => {
    onUpdateActiveWorkout(null);
    setShowDiscardConfirm(false);
    onClose();
  };

  // Filter exercises
  const filteredExercises = exerciseCatalog.filter(e => {
    const matchesSearch = e.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.muscleGroup.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesMuscle = selectedMuscleFilter === 'All' || e.muscleGroup === selectedMuscleFilter;
    return matchesSearch && matchesMuscle;
  });

  const muscleGroups = ['All', 'Chest', 'Back', 'Shoulders', 'Quads', 'Hamstrings', 'Biceps', 'Triceps', 'Glutes', 'Calves', 'Core'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md">
      <div className="bg-[#0e0f14] border border-[#2b2d39] rounded-2xl w-full max-w-4xl h-[94vh] flex flex-col overflow-hidden shadow-2xl relative">
        {/* PR Toast Banner */}
        {newPrNotice && (
          <div className="absolute top-16 left-1/2 -translate-x-1/2 z-50 bg-gradient-to-r from-zinc-800 via-zinc-900 to-black border border-emerald-500/80 text-emerald-400 font-bold px-5 py-2.5 rounded-full shadow-2xl text-xs flex items-center gap-2 animate-bounce">
            <Sparkles size={16} />
            <span>{newPrNotice}</span>
          </div>
        )}

        {/* Top Header Bar */}
        <div className="p-4 sm:px-6 bg-[#13141a] border-b border-[#242633] flex items-center justify-between">
          <div className="flex-1 mr-4">
            <input
              type="text"
              value={activeWorkout.name}
              onChange={e => handleTitleChange(e.target.value)}
              className="bg-transparent text-lg sm:text-xl font-black text-white focus:outline-none focus:border-b border-zinc-600 w-full"
              placeholder="Workout Name..."
            />
            <div className="flex items-center gap-3 text-xs text-zinc-400 mt-1">
              <span className="flex items-center gap-1 font-mono text-zinc-300">
                <Timer size={13} className="text-zinc-400" /> {formatDuration(elapsed)}
              </span>
              <span>•</span>
              <span>Volume: <strong className="text-white font-mono">{totalVolume} {weightUnit}</strong></span>
              <span>•</span>
              <span>Completed Sets: <strong className="text-white font-mono">{totalSetsDone}</strong></span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onStartRestTimer(90)}
              title="Quick Rest Timer"
              className="px-2.5 py-1.5 rounded-xl bg-zinc-900 border border-zinc-700 hover:border-zinc-500 text-zinc-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <Timer size={14} />
              <span className="hidden sm:inline">Rest Timer</span>
            </button>
            <button
              onClick={() => setShowDiscardConfirm(true)}
              title="Discard Workout"
              className="p-2 rounded-xl text-zinc-500 hover:text-red-400 hover:bg-zinc-900 transition-colors"
            >
              <Trash2 size={16} />
            </button>
            <button
              onClick={onClose}
              title="Minimize"
              className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-900 transition-colors"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Exercises Scroll Container */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">
          {activeWorkout.exercises.length === 0 ? (
            <div className="text-center py-16 px-4 border border-dashed border-[#272936] rounded-2xl bg-[#111218]">
              <Dumbbell size={48} className="mx-auto text-zinc-600 mb-3" />
              <h4 className="text-base font-bold text-white mb-1">Your Workout is Empty</h4>
              <p className="text-xs text-zinc-400 max-w-sm mx-auto mb-5">
                Add your first exercise below to begin logging sets, tracking progressive overload, and breaking records.
              </p>
              <button
                onClick={() => setShowExercisePicker(true)}
                className="px-5 py-2.5 rounded-xl bg-white text-black font-bold text-xs hover:bg-zinc-200 transition-all shadow-lg"
              >
                + Add First Exercise
              </button>
            </div>
          ) : (
            activeWorkout.exercises.map((ex, exerciseIndex) => {
              const prevPr = personalRecordsMap.get(ex.exerciseId);

              return (
                <div
                  key={`${ex.exerciseId}-${exerciseIndex}`}
                  className="bg-[#121319] border border-[#262835] rounded-2xl overflow-hidden shadow-lg transition-all"
                >
                  {/* Exercise Header */}
                  <div className="p-4 bg-[#171821] border-b border-[#242633] flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-bold text-white">{ex.exerciseName}</h4>
                        <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-zinc-800 text-zinc-300 border border-zinc-700">
                          {ex.muscleGroup}
                        </span>
                        {prevPr && (
                          <span className="text-[10px] font-mono text-zinc-400 flex items-center gap-1 hidden sm:flex">
                            <Award size={11} className="text-zinc-400" /> PR: {prevPr} {weightUnit}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleRemoveExercise(exerciseIndex)}
                        className="text-zinc-500 hover:text-red-400 p-1.5 rounded-lg hover:bg-zinc-850 transition-colors"
                        title="Remove Exercise"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>

                  {/* Sets Table */}
                  <div className="p-4 sm:p-5 overflow-x-auto">
                    <table className="w-full text-start text-sm">
                      <thead>
                        <tr className="text-zinc-400 text-xs uppercase tracking-wider border-b border-[#21232e]">
                          <th className="pb-3 ps-2 w-12">Set</th>
                          <th className="pb-3 w-28">Type</th>
                          <th className="pb-3 w-36">Weight ({weightUnit})</th>
                          <th className="pb-3 w-28">Reps</th>
                          <th className="pb-3 w-20 hidden sm:table-cell">RPE</th>
                          <th className="pb-3 pe-2 text-end w-20">Done</th>
                          <th className="pb-3 w-10"></th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-[#1e202a]">
                        {ex.sets.map((set, setIndex) => (
                          <tr
                            key={set.id}
                            className={`group transition-colors ${
                              set.completed ? 'bg-emerald-950/15' : 'hover:bg-[#161822]'
                            }`}
                          >
                            <td className="py-2.5 pl-2 font-mono font-bold text-zinc-300 text-base">
                              {set.setNumber}
                            </td>

                            <td className="py-2.5">
                              <select
                                value={set.type}
                                onChange={e =>
                                  handleUpdateSet(
                                    exerciseIndex,
                                    setIndex,
                                    'type',
                                    e.target.value as SetType
                                  )
                                }
                                className="bg-[#1b1c24] border border-[#2c2e3c] rounded-lg px-2 py-1.5 text-xs sm:text-sm text-zinc-200 font-semibold focus:outline-none"
                              >
                                <option value="Normal">Normal</option>
                                <option value="Warmup">Warmup</option>
                                <option value="Drop">Drop</option>
                                <option value="Failure">Failure</option>
                              </select>
                            </td>

                            <td className="py-2.5">
                              <div className="flex items-center gap-1.5">
                                <input
                                  type="number"
                                  step="0.5"
                                  value={set.weight || ''}
                                  onChange={e =>
                                    handleUpdateSet(
                                      exerciseIndex,
                                      setIndex,
                                      'weight',
                                      parseFloat(e.target.value) || 0
                                    )
                                  }
                                  className="w-20 sm:w-24 bg-[#1a1b24] border border-[#2d2f3d] rounded-xl px-2.5 py-1.5 text-white font-mono font-black text-sm sm:text-base focus:outline-none focus:border-zinc-400"
                                />
                                <button
                                  onClick={() => onOpenPlateCalc(set.weight)}
                                  title="Calculate Barbell Plates"
                                  className="p-1.5 rounded-lg bg-zinc-800 text-zinc-300 hover:text-white hover:bg-zinc-700 transition-colors"
                                >
                                  <Layers size={14} />
                                </button>
                              </div>
                            </td>

                            <td className="py-2.5">
                              <input
                                type="number"
                                min="0"
                                value={set.reps || ''}
                                onChange={e =>
                                  handleUpdateSet(
                                    exerciseIndex,
                                    setIndex,
                                    'reps',
                                    parseInt(e.target.value) || 0
                                  )
                                }
                                className="w-16 sm:w-20 bg-[#1a1b24] border border-[#2d2f3d] rounded-xl px-2.5 py-1.5 text-white font-mono font-black text-sm sm:text-base focus:outline-none focus:border-zinc-400"
                              />
                            </td>

                            <td className="py-2.5 hidden sm:table-cell">
                              <input
                                type="number"
                                step="0.5"
                                min="6"
                                max="10"
                                placeholder="RPE"
                                value={set.rpe || ''}
                                onChange={e =>
                                  handleUpdateSet(
                                    exerciseIndex,
                                    setIndex,
                                    'rpe',
                                    parseFloat(e.target.value) || undefined
                                  )
                                }
                                className="w-14 bg-[#1a1b24] border border-[#2d2f3d] rounded-xl px-2 py-1.5 text-zinc-300 font-mono text-xs sm:text-sm focus:outline-none"
                              />
                            </td>

                            <td className="py-2.5 pr-2 text-right">
                              <button
                                onClick={() =>
                                  handleUpdateSet(
                                    exerciseIndex,
                                    setIndex,
                                    'completed',
                                    !set.completed
                                  )
                                }
                                className={`w-8 h-8 rounded-xl inline-flex items-center justify-center transition-all ${
                                  set.completed
                                    ? 'bg-emerald-500 text-black shadow-lg scale-105'
                                    : 'bg-zinc-800 border border-zinc-750 text-transparent hover:border-zinc-400'
                                }`}
                              >
                                <Check size={16} strokeWidth={3} />
                              </button>
                            </td>

                            <td className="py-2.5">
                              <button
                                onClick={() => handleRemoveSet(exerciseIndex, setIndex)}
                                className="text-zinc-500 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity p-1.5"
                                title="Delete Set"
                              >
                                <X size={14} />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>

                    <div className="mt-4 flex items-center justify-between">
                      <button
                        onClick={() => handleAddSet(exerciseIndex)}
                        className="px-4 py-2 rounded-xl bg-zinc-850 hover:bg-zinc-800 text-zinc-200 hover:text-white text-xs sm:text-sm font-bold flex items-center gap-2 transition-colors border border-zinc-700 shadow"
                      >
                        <Plus size={15} />
                        <span>Add Set</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}

          {/* Add Exercise trigger button */}
          {activeWorkout.exercises.length > 0 && (
            <div className="flex justify-center pt-2">
              <button
                onClick={() => setShowExercisePicker(true)}
                className="px-6 py-2.5 rounded-xl bg-[#171822] border border-[#2b2d3c] hover:border-zinc-500 text-zinc-200 hover:text-white text-xs font-bold flex items-center gap-2 transition-all shadow-md"
              >
                <Plus size={15} />
                <span>Add Exercise</span>
              </button>
            </div>
          )}
        </div>

        {/* Bottom Bar: Finish Workout */}
        <div className="p-4 bg-[#111218] border-t border-[#242633] flex items-center justify-between">
          <div className="text-xs text-zinc-400 hidden sm:block">
            Auto-saves continuously. Click <strong className="text-zinc-200">Finish Workout</strong> when complete.
          </div>
          <div className="flex items-center gap-3 ml-auto">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-zinc-850 hover:bg-zinc-800 text-zinc-300 text-xs font-semibold transition-colors"
            >
              Minimize
            </button>
            <button
              onClick={handleFinish}
              className="px-6 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-400 hover:from-emerald-400 hover:to-emerald-300 text-black font-extrabold text-xs transition-all shadow-lg shadow-emerald-500/20 active:scale-95"
            >
              Finish Workout 🔥
            </button>
          </div>
        </div>

        {/* Exercise Picker Submodal */}
        {showExercisePicker && (
          <div className="absolute inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-[#121319] border border-[#2d2f3d] rounded-2xl w-full max-w-xl max-h-[85vh] flex flex-col overflow-hidden shadow-2xl">
              <div className="p-4 border-b border-[#252735] flex items-center justify-between">
                <h4 className="text-sm font-bold text-white">Select Exercise</h4>
                <button
                  onClick={() => setShowExercisePicker(false)}
                  className="p-1 rounded-lg text-zinc-400 hover:text-white"
                >
                  <X size={16} />
                </button>
              </div>

              {/* Search & Filters */}
              <div className="p-3 border-b border-[#252735] space-y-2">
                <input
                  type="text"
                  placeholder="Search exercises by name or muscle..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="w-full bg-[#191a22] border border-[#2c2e3c] rounded-xl px-3 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-zinc-400"
                />

                <div className="flex gap-1 overflow-x-auto no-scrollbar py-1">
                  {muscleGroups.map(m => (
                    <button
                      key={m}
                      onClick={() => setSelectedMuscleFilter(m)}
                      className={`px-2.5 py-1 text-[11px] font-semibold rounded-lg whitespace-nowrap transition-colors ${
                        selectedMuscleFilter === m
                          ? 'bg-zinc-200 text-black font-bold'
                          : 'bg-[#191a22] text-zinc-400 hover:text-white'
                      }`}
                    >
                      {m}
                    </button>
                  ))}
                </div>
              </div>

              {/* Exercise List */}
              <div className="flex-1 overflow-y-auto p-3 divide-y divide-[#1e202b]">
                {filteredExercises.length === 0 ? (
                  <p className="text-center py-8 text-xs text-zinc-500">No exercises found.</p>
                ) : (
                  filteredExercises.map(def => (
                    <div
                      key={def.id}
                      onClick={() => handleAddExercise(def)}
                      className="py-2.5 px-3 hover:bg-[#181a24] rounded-xl cursor-pointer flex items-center justify-between transition-colors group"
                    >
                      <div>
                        <div className="text-xs font-bold text-zinc-200 group-hover:text-white">
                          {def.name}
                        </div>
                        <div className="flex items-center gap-2 text-[10px] text-zinc-400 mt-0.5">
                          <span>{def.muscleGroup}</span>
                          <span>•</span>
                          <span>{def.equipment}</span>
                        </div>
                      </div>
                      <Plus size={15} className="text-zinc-500 group-hover:text-white" />
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

        {/* Discard Confirmation Dialog */}
        {showDiscardConfirm && (
          <div className="absolute inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-[#14151c] border border-red-500/40 rounded-2xl p-5 max-w-sm text-center shadow-2xl">
              <AlertTriangle size={36} className="mx-auto text-red-400 mb-2" />
              <h4 className="text-sm font-bold text-white mb-1">Discard Current Workout?</h4>
              <p className="text-xs text-zinc-400 mb-5">
                All logged sets and elapsed time will be permanently lost.
              </p>
              <div className="flex items-center justify-center gap-3">
                <button
                  onClick={() => setShowDiscardConfirm(false)}
                  className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold"
                >
                  Keep Logging
                </button>
                <button
                  onClick={handleDiscard}
                  className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold"
                >
                  Discard
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { X, Award, Flame, Dumbbell } from 'lucide-react';
import { WeightUnit } from '../types/gym';
import { calculate1RM } from '../utils/calculators';

interface OneRepMaxModalProps {
  isOpen: boolean;
  onClose: () => void;
  weightUnit: WeightUnit;
  initialWeight?: number;
  initialReps?: number;
}

export const OneRepMaxModal: React.FC<OneRepMaxModalProps> = ({
  isOpen,
  onClose,
  weightUnit,
  initialWeight = 80,
  initialReps = 8
}) => {
  const [weight, setWeight] = useState<number>(initialWeight);
  const [reps, setReps] = useState<number>(initialReps);

  if (!isOpen) return null;

  const result = calculate1RM(weight, reps);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-[#111216] border border-[#2b2d39] rounded-2xl w-full max-w-xl max-h-[90vh] overflow-y-auto shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-[#222430]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-zinc-850 border border-zinc-750 flex items-center justify-center text-zinc-300">
              <Award size={18} />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">One Rep Max (1RM) Calculator</h3>
              <p className="text-xs text-zinc-400">Calculate maximum strength & optimal training loads</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-6">
          {/* Inputs */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-1.5">
                Weight Lifted ({weightUnit})
              </label>
              <input
                type="number"
                step="2.5"
                min="0"
                value={weight || ''}
                onChange={e => setWeight(parseFloat(e.target.value) || 0)}
                className="w-full bg-[#181920] border border-[#2d2f3d] rounded-xl px-3.5 py-2.5 text-white font-mono text-lg font-bold focus:outline-none focus:border-zinc-400"
                placeholder="80"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-zinc-300 uppercase tracking-wider mb-1.5">
                Reps Performed
              </label>
              <input
                type="number"
                min="1"
                max="30"
                value={reps || ''}
                onChange={e => setReps(parseInt(e.target.value) || 1)}
                className="w-full bg-[#181920] border border-[#2d2f3d] rounded-xl px-3.5 py-2.5 text-white font-mono text-lg font-bold focus:outline-none focus:border-zinc-400"
                placeholder="8"
              />
            </div>
          </div>

          {/* Big Result Card */}
          <div className="bg-gradient-to-br from-zinc-850 to-zinc-950 border border-zinc-700/60 rounded-2xl p-5 text-center shadow-lg relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-10">
              <Flame size={80} />
            </div>
            <span className="text-xs font-bold text-zinc-400 uppercase tracking-widest block mb-1">
              Estimated 1-Rep Max
            </span>
            <div className="text-5xl font-black text-white font-mono tracking-tight my-2">
              {result.average} <span className="text-2xl font-light text-zinc-400">{weightUnit}</span>
            </div>
            <div className="flex items-center justify-center gap-4 text-[11px] text-zinc-400 mt-2">
              <span>Epley: <strong className="text-zinc-200">{result.epley}</strong></span>
              <span>•</span>
              <span>Brzycki: <strong className="text-zinc-200">{result.brzycki}</strong></span>
              <span>•</span>
              <span>Lombardi: <strong className="text-zinc-200">{result.lombardi}</strong></span>
            </div>
          </div>

          {/* Training Percentage Table */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-zinc-300 uppercase tracking-wider">
                Target Training Zones & Percentages
              </span>
              <span className="text-[11px] text-zinc-500">Based on 1RM</span>
            </div>

            <div className="border border-[#262835] rounded-xl overflow-hidden bg-[#14151b]">
              <table className="w-full text-start text-xs">
                <thead>
                  <tr className="border-b border-[#262835] bg-[#1a1c24] text-zinc-400 text-[11px] uppercase tracking-wider">
                    <th className="py-2.5 px-3">Intensity</th>
                    <th className="py-2.5 px-3">Target Weight</th>
                    <th className="py-2.5 px-3">Rep Range</th>
                    <th className="py-2.5 px-3 hidden sm:table-cell">Training Focus</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#21232d]">
                  {result.percentages.map((p, idx) => (
                    <tr
                      key={p.percentage}
                      className={idx % 2 === 0 ? 'bg-transparent' : 'bg-[#161820]'}
                    >
                      <td className="py-2 px-3 font-mono font-bold text-zinc-300">
                        {p.percentage}%
                      </td>
                      <td className="py-2 px-3 font-mono font-extrabold text-white text-sm">
                        {p.weight} {weightUnit}
                      </td>
                      <td className="py-2 px-3 text-zinc-300 font-medium">
                        {p.repsRange}
                      </td>
                      <td className="py-2 px-3 text-zinc-400 text-[11px] hidden sm:table-cell">
                        {p.focus}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#0d0e12] border-t border-[#222430] flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-semibold transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

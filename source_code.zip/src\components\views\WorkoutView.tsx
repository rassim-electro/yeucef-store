import React, { useState } from 'react';
import { CompletedWorkout, WeightUnit } from '../../types/gym';
import {
  Calendar,
  Clock,
  Dumbbell,
  Award,
  Trash2,
  ChevronDown,
  ChevronUp,
  Search,
  Play,
  Layers,
  Sparkles
} from 'lucide-react';

interface WorkoutViewProps {
  workouts: CompletedWorkout[];
  weightUnit: WeightUnit;
  onDeleteWorkout: (id: string) => void;
  onStartNewWorkout: () => void;
}

export const WorkoutView: React.FC<WorkoutViewProps> = ({
  workouts,
  weightUnit,
  onDeleteWorkout,
  onStartNewWorkout
}) => {
  const [expandedId, setExpandedId] = useState<string | null>(workouts[0]?.id || null);
  const [search, setSearch] = useState('');

  const toggleExpand = (id: string) => {
    setExpandedId(prev => (prev === id ? null : id));
  };

  const filtered = workouts.filter(w =>
    w.name.toLowerCase().includes(search.toLowerCase()) ||
    w.exercises.some(e => e.exerciseName.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-black text-white uppercase tracking-wider">
            Workout History & Logs
          </h2>
          <p className="text-sm text-zinc-400">
            Review your past training sessions, total volume, and set progression
          </p>
        </div>

        <button
          onClick={onStartNewWorkout}
          className="px-6 py-3 rounded-2xl bg-white text-black font-black text-sm hover:bg-zinc-200 transition-all flex items-center gap-2 self-start sm:self-auto shadow-lg active:scale-95"
        >
          <Play size={16} fill="currentColor" />
          <span>Start Live Workout</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400" />
        <input
          type="text"
          placeholder="Search workouts or exercises by name..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="w-full bg-[#121319] border border-[#282a39] rounded-2xl pl-12 pr-4 py-3 text-sm sm:text-base text-white placeholder-zinc-500 focus:outline-none focus:border-zinc-400 shadow-md"
        />
      </div>

      {/* Workout List */}
      {filtered.length === 0 ? (
        <div className="text-center py-16 bg-[#111218] rounded-3xl border border-[#232532] p-6 shadow-xl">
          <Dumbbell size={52} className="mx-auto text-zinc-600 mb-3" />
          <h4 className="text-base font-bold text-white mb-1">No Workouts Found</h4>
          <p className="text-sm text-zinc-400 mb-5 max-w-sm mx-auto">
            {search ? 'No sessions matched your search criteria.' : 'You haven’t completed any workouts yet. Start your first session now!'}
          </p>
          <button
            onClick={onStartNewWorkout}
            className="px-6 py-3 rounded-2xl bg-zinc-800 text-zinc-100 text-sm font-bold hover:bg-zinc-700 transition-colors"
          >
            Start Your First Workout
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {filtered.map(w => {
            const isExpanded = expandedId === w.id;
            const workoutDate = new Date(w.startTime).toLocaleDateString(undefined, {
              weekday: 'short',
              month: 'short',
              day: 'numeric',
              year: 'numeric'
            });

            return (
              <div
                key={w.id}
                className="bg-[#121319] border border-[#262837] rounded-3xl overflow-hidden shadow-xl transition-all"
              >
                {/* Summary Header */}
                <div
                  onClick={() => toggleExpand(w.id)}
                  className="p-5 sm:p-6 flex items-center justify-between cursor-pointer hover:bg-[#161824] transition-colors"
                >
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-2.5">
                      <h3 className="text-base sm:text-xl font-black text-white">{w.name}</h3>
                      {w.prsAchieved > 0 && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-xs font-bold">
                          <Award size={13} /> {w.prsAchieved} PR{w.prsAchieved > 1 ? 's' : ''}
                        </span>
                      )}
                    </div>
                    <div className="flex flex-wrap items-center gap-4 text-xs sm:text-sm text-zinc-300">
                      <span className="flex items-center gap-1.5">
                        <Calendar size={14} className="text-zinc-500" /> {workoutDate}
                      </span>
                      <span>•</span>
                      <span className="flex items-center gap-1.5">
                        <Clock size={14} className="text-zinc-500" /> {w.durationMinutes} min
                      </span>
                      <span>•</span>
                      <span className="flex items-center gap-1.5">
                        <Dumbbell size={14} className="text-zinc-500" /> <strong className="text-white font-mono">{w.totalVolume.toLocaleString()} {weightUnit}</strong>
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={e => {
                        e.stopPropagation();
                        if (confirm(`Delete "${w.name}" from history?`)) {
                          onDeleteWorkout(w.id);
                        }
                      }}
                      className="p-2.5 rounded-xl text-zinc-500 hover:text-red-400 hover:bg-zinc-800 transition-colors"
                      title="Delete Log"
                    >
                      <Trash2 size={18} />
                    </button>
                    <div className="text-zinc-400 p-1">
                      {isExpanded ? <ChevronUp size={22} /> : <ChevronDown size={22} />}
                    </div>
                  </div>
                </div>

                {/* Expanded Details */}
                {isExpanded && (
                  <div className="p-5 sm:p-6 border-t border-[#20222f] bg-[#0d0e14] space-y-5">
                    {w.notes && (
                      <div className="p-4 rounded-2xl bg-zinc-900 border border-zinc-800 text-sm text-zinc-300 italic">
                        "{w.notes}"
                      </div>
                    )}

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {w.exercises.map((ex, idx) => (
                        <div
                          key={`${ex.exerciseId}-${idx}`}
                          className="bg-[#141620] border border-[#262837] rounded-2xl p-4 sm:p-5 space-y-3 shadow-md"
                        >
                          <div className="flex items-center justify-between">
                            <h4 className="text-sm sm:text-base font-extrabold text-white">{ex.exerciseName}</h4>
                            <span className="text-xs font-mono text-zinc-300 px-2.5 py-0.5 rounded-lg bg-zinc-850 border border-zinc-700">
                              {ex.muscleGroup}
                            </span>
                          </div>

                          <div className="space-y-1.5">
                            {ex.sets.map(s => (
                              <div
                                key={s.id}
                                className="flex items-center justify-between text-xs sm:text-sm py-1.5 border-b border-[#1c1e2a] last:border-0"
                              >
                                <span className="font-mono text-zinc-400 font-semibold">
                                  Set {s.setNumber} {s.type !== 'Normal' && `(${s.type})`}
                                </span>
                                <span className="font-mono text-white font-extrabold text-sm sm:text-base">
                                  {s.weight} {weightUnit} × {s.reps} reps
                                  {s.rpe && <span className="text-zinc-400 text-xs ml-2 font-normal">@RPE {s.rpe}</span>}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

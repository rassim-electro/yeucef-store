import { WeightUnit } from '../types/gym';

export interface OneRepMaxResult {
  epley: number;
  brzycki: number;
  lombardi: number;
  average: number;
  percentages: {
    percentage: number;
    weight: number;
    repsRange: string;
    focus: string;
  }[];
}

export function calculate1RM(weight: number, reps: number): OneRepMaxResult {
  if (weight <= 0 || reps <= 0) {
    return {
      epley: 0,
      brzycki: 0,
      lombardi: 0,
      average: 0,
      percentages: []
    };
  }

  if (reps === 1) {
    const percentages = buildPercentages(weight);
    return {
      epley: weight,
      brzycki: weight,
      lombardi: weight,
      average: weight,
      percentages
    };
  }

  // Epley formula: w * (1 + r / 30)
  const epley = Math.round((weight * (1 + reps / 30)) * 10) / 10;
  // Brzycki formula: w * (36 / (37 - r))
  const brzycki = reps < 37 ? Math.round((weight * (36 / (37 - reps))) * 10) / 10 : epley;
  // Lombardi formula: w * (r ^ 0.10)
  const lombardi = Math.round((weight * Math.pow(reps, 0.10)) * 10) / 10;

  const average = Math.round(((epley + brzycki + lombardi) / 3) * 10) / 10;

  const percentages = buildPercentages(average);

  return {
    epley,
    brzycki,
    lombardi,
    average,
    percentages
  };
}

function buildPercentages(oneRepMax: number) {
  const steps = [
    { percentage: 100, repsRange: '1 rep', focus: '1RM Peak Power' },
    { percentage: 95, repsRange: '2 reps', focus: 'Maximal Strength' },
    { percentage: 90, repsRange: '3-4 reps', focus: 'Heavy Strength' },
    { percentage: 85, repsRange: '5-6 reps', focus: 'Strength & Density' },
    { percentage: 80, repsRange: '7-8 reps', focus: 'Strength-Hypertrophy' },
    { percentage: 75, repsRange: '8-10 reps', focus: 'Pure Hypertrophy' },
    { percentage: 70, repsRange: '10-12 reps', focus: 'Hypertrophy & Pump' },
    { percentage: 65, repsRange: '12-15 reps', focus: 'Endurance & Volume' },
    { percentage: 50, repsRange: '15+ reps', focus: 'Warmup & Mobility' }
  ];

  return steps.map(s => ({
    percentage: s.percentage,
    weight: Math.round(((oneRepMax * s.percentage) / 100) * 2) / 2, // round to nearest 0.5
    repsRange: s.repsRange,
    focus: s.focus
  }));
}

export interface PlateItem {
  weight: number;
  count: number;
  color: string;
}

export interface PlateResult {
  targetWeight: number;
  barWeight: number;
  weightPerSide: number;
  achievedTotal: number;
  remainder: number;
  platesPerSide: PlateItem[];
}

export function calculatePlates(
  targetWeight: number,
  unit: WeightUnit = 'kg',
  customBarWeight?: number
): PlateResult {
  const defaultBar = unit === 'kg' ? 20 : 45;
  const barWeight = customBarWeight !== undefined ? customBarWeight : defaultBar;

  if (targetWeight <= barWeight) {
    return {
      targetWeight,
      barWeight,
      weightPerSide: 0,
      achievedTotal: barWeight,
      remainder: 0,
      platesPerSide: []
    };
  }

  const platesKg = [
    { weight: 25, color: '#ef4444' }, // Red
    { weight: 20, color: '#3b82f6' }, // Blue
    { weight: 15, color: '#eab308' }, // Yellow
    { weight: 10, color: '#22c55e' }, // Green
    { weight: 5, color: '#f97316' },  // White/Orange
    { weight: 2.5, color: '#64748b' },// Black/Slate
    { weight: 1.25, color: '#a855f7' } // Micro
  ];

  const platesLbs = [
    { weight: 45, color: '#3b82f6' }, // Blue
    { weight: 35, color: '#eab308' }, // Yellow
    { weight: 25, color: '#22c55e' }, // Green
    { weight: 10, color: '#f97316' }, // Orange
    { weight: 5, color: '#64748b' },  // Slate
    { weight: 2.5, color: '#ef4444' } // Red
  ];

  const plateInventory = unit === 'kg' ? platesKg : platesLbs;
  const weightPerSideNeeded = (targetWeight - barWeight) / 2;
  let remainingSide = weightPerSideNeeded;

  const platesPerSide: PlateItem[] = [];

  for (const plate of plateInventory) {
    if (remainingSide >= plate.weight) {
      const count = Math.floor(remainingSide / plate.weight);
      platesPerSide.push({
        weight: plate.weight,
        count,
        color: plate.color
      });
      remainingSide = Math.round((remainingSide - count * plate.weight) * 100) / 100;
    }
  }

  const sidePlateSum = platesPerSide.reduce((sum, p) => sum + p.weight * p.count, 0);
  const achievedTotal = barWeight + sidePlateSum * 2;
  const remainder = Math.round((targetWeight - achievedTotal) * 10) / 10;

  return {
    targetWeight,
    barWeight,
    weightPerSide: weightPerSideNeeded,
    achievedTotal,
    remainder,
    platesPerSide
  };
}

export interface OverloadRecommendation {
  status: 'INCREASE_WEIGHT' | 'ADD_REPS' | 'MAINTAIN' | 'DELOAD';
  headline: string;
  recommendedAction: string;
  nextTargetWeight: number;
  nextTargetReps: string;
  reasoning: string;
  tips: string[];
}

export function generateOverloadAdvice(
  lastWeight: number,
  lastSetsReps: number[],
  targetMinReps: number = 8,
  targetMaxReps: number = 12,
  unit: WeightUnit = 'kg'
): OverloadRecommendation {
  const weightIncrement = unit === 'kg' ? 2.5 : 5;

  if (!lastSetsReps || lastSetsReps.length === 0 || lastWeight <= 0) {
    return {
      status: 'MAINTAIN',
      headline: 'Establish Baseline',
      recommendedAction: `Log 3 sets at your starting weight with target ${targetMinReps}-${targetMaxReps} reps.`,
      nextTargetWeight: lastWeight || 20,
      nextTargetReps: `${targetMinReps}-${targetMaxReps}`,
      reasoning: 'Perform your sets with strict form and stop 1-2 reps before muscular failure.',
      tips: [
        'Record exact reps and weights in the logger.',
        'Warm up properly before heavy working sets.'
      ]
    };
  }

  const allHitCeiling = lastSetsReps.every(r => r >= targetMaxReps);
  const allHitFloor = lastSetsReps.every(r => r >= targetMinReps);
  const failedSets = lastSetsReps.filter(r => r < targetMinReps).length;

  if (allHitCeiling) {
    const nextWeight = lastWeight + weightIncrement;
    return {
      status: 'INCREASE_WEIGHT',
      headline: '🔥 Ready for Weight Progression!',
      recommendedAction: `Increase weight to ${nextWeight} ${unit} and target ${targetMinReps} reps per set.`,
      nextTargetWeight: nextWeight,
      nextTargetReps: `${targetMinReps} reps`,
      reasoning: `You completed all ${lastSetsReps.length} sets at or above your ceiling (${targetMaxReps} reps) at ${lastWeight} ${unit}. According to the Double Progression rule, your body is fully adapted to this load.`,
      tips: [
        `Jump up by +${weightIncrement} ${unit} next session.`,
        `Focus on reaching at least ${targetMinReps} strict reps on your first set.`,
        'Rest 90-120 seconds between sets to maximize force output.'
      ]
    };
  }

  if (allHitFloor && !allHitCeiling) {
    return {
      status: 'ADD_REPS',
      headline: '⚡ Build Reps at Current Weight',
      recommendedAction: `Keep ${lastWeight} ${unit} and push for +1 to +2 total reps across your sets.`,
      nextTargetWeight: lastWeight,
      nextTargetReps: `Aim for ${targetMaxReps} reps on early sets`,
      reasoning: `You hit the minimum target (${targetMinReps} reps) on all sets [${lastSetsReps.join(', ')}]. Do not add weight yet. Build stamina until all sets reach ${targetMaxReps} reps.`,
      tips: [
        'Fight for 1 extra rep on your lagging sets.',
        'Control the negative (eccentric) phase for 2-3 seconds.',
        'Keep rest intervals strictly timed.'
      ]
    };
  }

  if (failedSets >= Math.ceil(lastSetsReps.length / 2)) {
    const deloadWeight = Math.round((lastWeight * 0.9) * 2) / 2;
    return {
      status: 'DELOAD',
      headline: '🛡️ Form & Volume Reset Recommended',
      recommendedAction: `Reset weight to ${deloadWeight} ${unit} (-10%) to reset fatigue and refine technique.`,
      nextTargetWeight: deloadWeight,
      nextTargetReps: `${targetMinReps}-${targetMaxReps} crisp reps`,
      reasoning: `You missed the minimum target reps (${targetMinReps}) on ${failedSets} out of ${lastSetsReps.length} sets [${lastSetsReps.join(', ')}]. Forcing higher weights now invites injury and plateau.`,
      tips: [
        'A 10% deload allows connective tissue recovery and neuromuscular groove reset.',
        'Explode upward, pause at the contraction, control the descent.',
        'You will rebuild stronger in 1-2 sessions.'
      ]
    };
  }

  return {
    status: 'MAINTAIN',
    headline: '⚖️ Consolidate Current Weight',
    recommendedAction: `Maintain ${lastWeight} ${unit} and focus on lifting with zero momentum.`,
    nextTargetWeight: lastWeight,
    nextTargetReps: `${targetMinReps}-${targetMaxReps}`,
    reasoning: `Your reps were [${lastSetsReps.join(', ')}]. Almost at your target range. Keep hammering this load with pristine technique.`,
    tips: [
      'Ensure proper sleep (7-8 hours) and protein intake.',
      'Use the built-in rest timer to ensure complete phosphagen system recovery.'
    ]
  };
}

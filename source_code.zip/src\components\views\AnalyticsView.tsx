import React, { useState } from 'react';
import { CompletedWorkout, WeightUnit } from '../../types/gym';
import { calculate1RM } from '../../utils/calculators';
import {
  TrendingUp,
  BarChart2,
  PieChart,
  Calendar,
  Dumbbell,
  Award
} from 'lucide-react';

interface AnalyticsViewProps {
  workouts: CompletedWorkout[];
  weightUnit: WeightUnit;
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({
  workouts,
  weightUnit
}) => {
  const allExerciseNames = Array.from(
    new Set(
      workouts.flatMap(w => w.exercises.map(e => e.exerciseName))
    )
  ).sort();

  const [selectedExercise, setSelectedExercise] = useState<string>(
    allExerciseNames[0] || 'Barbell Bench Press'
  );

  const strengthData: { date: string; maxWeight: number; est1RM: number }[] = [];

  const chronWorkouts = [...workouts].sort(
    (a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime()
  );

  for (const w of chronWorkouts) {
    const ex = w.exercises.find(e => e.exerciseName === selectedExercise);
    if (ex) {
      let maxW = 0;
      let best1RM = 0;
      for (const s of ex.sets) {
        if (s.completed && s.type !== 'Warmup' && s.weight > 0 && s.reps > 0) {
          if (s.weight > maxW) maxW = s.weight;
          const e1rm = calculate1RM(s.weight, s.reps).average;
          if (e1rm > best1RM) best1RM = e1rm;
        }
      }
      if (maxW > 0) {
        strengthData.push({
          date: new Date(w.startTime).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
          maxWeight: maxW,
          est1RM: best1RM
        });
      }
    }
  }

  const muscleSetCounts: Record<string, number> = {};
  for (const w of workouts) {
    for (const ex of w.exercises) {
      const muscle = ex.muscleGroup || 'Other';
      const completedSets = ex.sets.filter(s => s.completed && s.type !== 'Warmup').length;
      muscleSetCounts[muscle] = (muscleSetCounts[muscle] || 0) + completedSets;
    }
  }

  const muscleList = Object.entries(muscleSetCounts).sort((a, b) => b[1] - a[1]);
  const totalSetsOverall = muscleList.reduce((sum, item) => sum + item[1], 0) || 1;

  const recentWorkouts = chronWorkouts.slice(-8);
  const maxVolume = Math.max(...recentWorkouts.map(w => w.totalVolume), 100);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl sm:text-3xl font-black text-white uppercase tracking-wider">
          Progress Analytics & Overload Trends
        </h2>
        <p className="text-sm text-zinc-400">
          Visualize your strength gains, volume progression, and muscle training balance
        </p>
      </div>

      {/* 1. Exercise Strength Progression Chart */}
      <div className="bg-[#121319] border border-[#262837] rounded-3xl p-6 sm:p-7 shadow-xl space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-zinc-850 flex items-center justify-center text-zinc-200">
              <TrendingUp size={18} />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black text-white uppercase tracking-wider">
                Strength Progression Curve
              </h3>
              <p className="text-xs sm:text-sm text-zinc-400">Estimated 1RM & top set load over time</p>
            </div>
          </div>

          {/* Exercise selector dropdown */}
          <select
            value={selectedExercise}
            onChange={e => setSelectedExercise(e.target.value)}
            className="bg-[#181924] border border-[#2d2f40] text-white text-xs sm:text-sm font-bold rounded-2xl px-4 py-2.5 focus:outline-none focus:border-zinc-400"
          >
            {allExerciseNames.map(name => (
              <option key={name} value={name}>{name}</option>
            ))}
          </select>
        </div>

        {strengthData.length === 0 ? (
          <p className="text-sm text-zinc-500 py-12 text-center italic">
            No completed sets logged for {selectedExercise} yet. Log this exercise in a workout to see your strength curve!
          </p>
        ) : (
          <div className="pt-2">
            <div className="bg-[#0b0c10] border border-[#222434] rounded-2xl p-5 sm:p-7">
              <div className="flex items-center justify-end gap-5 text-xs sm:text-sm mb-5">
                <span className="flex items-center gap-2 text-white font-bold">
                  <span className="w-3.5 h-3.5 rounded-full bg-white inline-block shadow-sm" /> Est. 1-Rep Max
                </span>
                <span className="flex items-center gap-2 text-zinc-400 font-semibold">
                  <span className="w-3.5 h-3.5 rounded-full bg-zinc-600 inline-block" /> Top Set Weight
                </span>
              </div>

              {/* Data points visual bars */}
              <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-3.5 items-end min-h-[200px] pt-4 border-b border-[#222434]">
                {strengthData.map((pt, idx) => {
                  const maxChartVal = Math.max(...strengthData.map(d => d.est1RM), 1);
                  const heightPercent = Math.max(15, (pt.est1RM / maxChartVal) * 100);

                  return (
                    <div key={idx} className="flex flex-col items-center justify-end gap-2 h-full group">
                      <div className="text-xs sm:text-sm font-mono font-black text-white group-hover:scale-110 transition-transform">
                        {pt.est1RM}
                      </div>
                      <div className="w-full max-w-[46px] bg-zinc-850 rounded-t-xl relative flex flex-col justify-end overflow-hidden border border-zinc-750" style={{ height: `${heightPercent}%` }}>
                        <div
                          className="w-full bg-gradient-to-t from-zinc-700 to-zinc-300 rounded-t-xl"
                          style={{ height: `${(pt.maxWeight / pt.est1RM) * 100}%` }}
                          title={`Top Weight: ${pt.maxWeight} ${weightUnit}`}
                        />
                      </div>
                      <span className="text-xs text-zinc-400 font-mono whitespace-nowrap mt-1 font-semibold">
                        {pt.date}
                      </span>
                    </div>
                  );
                })}
              </div>

              <div className="flex items-center justify-between text-xs sm:text-sm text-zinc-400 pt-4">
                <span>Earliest recorded</span>
                <span className="font-mono text-white font-bold text-sm sm:text-base">
                  Total Gain: +{Math.max(0, (strengthData[strengthData.length - 1]?.est1RM || 0) - (strengthData[0]?.est1RM || 0)).toFixed(1)} {weightUnit}
                </span>
                <span>Latest session</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Two Column: Volume by Workout & Muscle Balance Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Volume History */}
        <div className="bg-[#121319] border border-[#262837] rounded-3xl p-6 sm:p-7 shadow-xl space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-zinc-850 flex items-center justify-center text-zinc-200">
              <BarChart2 size={18} />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black text-white uppercase tracking-wider">
                Workout Volume (Recent Sessions)
              </h3>
              <p className="text-xs sm:text-sm text-zinc-400">Total tonnage lifted per session ({weightUnit})</p>
            </div>
          </div>

          <div className="space-y-4 pt-3">
            {recentWorkouts.map(w => {
              const widthPct = Math.min(100, (w.totalVolume / maxVolume) * 100);
              const dateStr = new Date(w.startTime).toLocaleDateString(undefined, {
                month: 'short',
                day: 'numeric'
              });

              return (
                <div key={w.id} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs sm:text-sm">
                    <span className="font-bold text-zinc-200 truncate max-w-[220px]">
                      {w.name}
                    </span>
                    <span className="font-mono font-black text-white text-sm sm:text-base">
                      {w.totalVolume.toLocaleString()} {weightUnit}
                    </span>
                  </div>
                  <div className="w-full bg-[#181924] h-3 rounded-full overflow-hidden border border-[#262838]">
                    <div
                      className="h-full bg-gradient-to-r from-zinc-600 via-zinc-400 to-zinc-100 rounded-full transition-all duration-700"
                      style={{ width: `${Math.max(8, widthPct)}%` }}
                    />
                  </div>
                  <div className="text-xs text-zinc-500 font-mono text-right font-medium">{dateStr}</div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Muscle Group Volume Distribution */}
        <div className="bg-[#121319] border border-[#262837] rounded-3xl p-6 sm:p-7 shadow-xl space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-zinc-850 flex items-center justify-center text-zinc-200">
              <PieChart size={18} />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black text-white uppercase tracking-wider">
                Muscle Group Distribution
              </h3>
              <p className="text-xs sm:text-sm text-zinc-400">Completed sets per muscle target</p>
            </div>
          </div>

          <div className="space-y-3.5 pt-3">
            {muscleList.length === 0 ? (
              <p className="text-sm text-zinc-500 text-center py-8 italic">No muscle sets logged yet.</p>
            ) : (
              muscleList.map(([muscle, count]) => {
                const pct = Math.round((count / totalSetsOverall) * 100);
                return (
                  <div key={muscle} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs sm:text-sm">
                      <span className="font-bold text-zinc-200">{muscle}</span>
                      <span className="font-mono text-zinc-400 font-semibold text-xs sm:text-sm">
                        <strong className="text-white font-black">{count} sets</strong> ({pct}%)
                      </span>
                    </div>
                    <div className="w-full bg-[#181924] h-2.5 rounded-full overflow-hidden border border-[#262838]">
                      <div
                        className="h-full bg-gradient-to-r from-zinc-500 to-zinc-200 rounded-full"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

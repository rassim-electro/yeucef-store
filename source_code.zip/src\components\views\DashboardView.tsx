import React from 'react';
import {
  CompletedWorkout,
  PersonalRecord,
  Routine,
  WeightUnit
} from '../../types/gym';
import { Language, TRANSLATIONS } from '../../utils/i18n';
import { InfinityGymLogo } from '../InfinityGymLogo';
import {
  Flame,
  Trophy,
  Dumbbell,
  Timer,
  TrendingUp,
  ArrowRight,
  Layers,
  Award,
  Calendar,
  Zap,
  Play,
  Sparkles,
  BookOpen
} from 'lucide-react';

interface DashboardViewProps {
  workouts: CompletedWorkout[];
  personalRecords: PersonalRecord[];
  routines: Routine[];
  weightUnit: WeightUnit;
  lang: Language;
  onStartRoutine: (routine: Routine) => void;
  onStartEmptyWorkout: () => void;
  onOpenPlateCalc: () => void;
  onOpen1RMCalc: () => void;
  onOpenOverloadGuide: () => void;
  onOpenMotivation: () => void;
  onViewAllWorkouts: () => void;
  onViewAllRoutines: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  workouts,
  personalRecords,
  routines,
  weightUnit,
  lang,
  onStartRoutine,
  onStartEmptyWorkout,
  onOpenPlateCalc,
  onOpen1RMCalc,
  onOpenOverloadGuide,
  onOpenMotivation,
  onViewAllWorkouts,
  onViewAllRoutines
}) => {
  const t = TRANSLATIONS[lang];
  const isArabic = lang === 'ar';

  // Aggregate stats
  const totalVolumeLifted = workouts.reduce((sum, w) => sum + (w.totalVolume || 0), 0);
  const totalWorkouts = workouts.length;

  // Streak: calculate workouts in last 7 days
  const now = Date.now();
  const past7Days = workouts.filter(w => {
    const time = new Date(w.startTime).getTime();
    return now - time <= 7 * 24 * 60 * 60 * 1000;
  }).length;

  const latestWorkout = workouts.length > 0 ? workouts[0] : null;

  return (
    <div className="space-y-8 animate-fadeIn" dir={isArabic ? 'rtl' : 'ltr'}>
      {/* Top Banner / Hero with Exact Barbell Logo */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#121319] via-[#161822] to-[#101117] border border-[#2d3042] p-6 sm:p-9 shadow-2xl">
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-8">
          <div className="space-y-3.5 max-w-2xl">
            {/* Logo from the gym sign */}
            <div className="flex items-center gap-3">
              <InfinityGymLogo size="md" showText={true} />
            </div>

            <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight uppercase leading-snug">
              {t.heroHeadline}
            </h1>
            <p className="text-sm sm:text-base text-zinc-300 leading-relaxed font-medium">
              {t.heroSubheadline}
            </p>

            {/* Quick action buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={onStartEmptyWorkout}
                className="px-6 sm:px-7 py-3.5 rounded-2xl bg-white text-black font-black text-sm sm:text-base hover:bg-zinc-200 transition-all shadow-xl hover:shadow-white/20 active:scale-95 flex items-center gap-2.5"
              >
                <Play size={18} fill="currentColor" />
                <span>{t.startEmptyWorkout}</span>
              </button>
              <button
                onClick={onOpenMotivation}
                className="px-5 py-3.5 rounded-2xl bg-[#1d1f2b] border border-[#33374b] hover:border-zinc-400 text-zinc-200 hover:text-white text-sm sm:text-base font-extrabold transition-all flex items-center gap-2"
              >
                <Flame size={18} className="text-amber-400" />
                <span>{t.motivationLetter}</span>
              </button>
              <button
                onClick={onOpenOverloadGuide}
                className="px-5 py-3.5 rounded-2xl bg-[#161720] border border-[#2b2d3d] hover:border-zinc-500 text-zinc-300 hover:text-white text-sm sm:text-base font-bold transition-all flex items-center gap-2"
              >
                <TrendingUp size={18} />
                <span>{t.overloadAdvisor}</span>
              </button>
            </div>
          </div>

          {/* Right Hero Graphic: Large Wall Logo */}
          <div className="hidden lg:flex flex-col items-center justify-center p-6 rounded-3xl bg-[#090a0d]/80 border border-[#232634] shadow-2xl">
            <InfinityGymLogo size="xl" showText={true} />
            <div className="mt-3 flex items-center gap-2 text-xs text-zinc-400 font-mono">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>STRENGTH & HYPERTROPHY ENGINE</span>
            </div>
          </div>
        </div>

        {/* Ambient mesh */}
        <div className="absolute -right-10 -bottom-10 w-72 h-72 bg-zinc-600/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* 4 Core Stat Cards with Larger Typography */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
        {/* Total Volume */}
        <div className="bg-[#12131a] border border-[#262837] rounded-3xl p-5 sm:p-6 shadow-xl relative overflow-hidden group hover:border-zinc-600 transition-all">
          <div className="flex items-center justify-between text-zinc-400 mb-3">
            <span className="text-xs sm:text-sm font-bold uppercase tracking-wider">{t.totalVolume}</span>
            <div className="w-9 h-9 rounded-xl bg-zinc-850 flex items-center justify-center text-zinc-300">
              <Dumbbell size={18} />
            </div>
          </div>
          <div className="text-2xl sm:text-4xl font-black text-white font-mono tracking-tight">
            {totalVolumeLifted.toLocaleString()} <span className="text-sm sm:text-base font-light text-zinc-400">{weightUnit}</span>
          </div>
          <p className="text-xs text-zinc-500 mt-1.5 font-medium">{t.cumulativeWeight}</p>
        </div>

        {/* Workouts Logged */}
        <div className="bg-[#12131a] border border-[#262837] rounded-3xl p-5 sm:p-6 shadow-xl relative overflow-hidden group hover:border-zinc-600 transition-all">
          <div className="flex items-center justify-between text-zinc-400 mb-3">
            <span className="text-xs sm:text-sm font-bold uppercase tracking-wider">{t.workoutsLogged}</span>
            <div className="w-9 h-9 rounded-xl bg-zinc-850 flex items-center justify-center text-zinc-300">
              <Calendar size={18} />
            </div>
          </div>
          <div className="text-2xl sm:text-4xl font-black text-white font-mono tracking-tight">
            {totalWorkouts}
          </div>
          <p className="text-xs text-zinc-500 mt-1.5 font-medium">{t.fullSessions}</p>
        </div>

        {/* Weekly Streak */}
        <div className="bg-[#12131a] border border-[#262837] rounded-3xl p-5 sm:p-6 shadow-xl relative overflow-hidden group hover:border-zinc-600 transition-all">
          <div className="flex items-center justify-between text-zinc-400 mb-3">
            <span className="text-xs sm:text-sm font-bold uppercase tracking-wider">{t.weeklyStreak}</span>
            <div className="w-9 h-9 rounded-xl bg-zinc-850 flex items-center justify-center text-zinc-300">
              <Flame size={18} className="text-amber-400" />
            </div>
          </div>
          <div className="text-2xl sm:text-4xl font-black text-white font-mono tracking-tight">
            {past7Days} <span className="text-sm sm:text-base font-light text-zinc-400">{isArabic ? 'أيام' : 'days'}</span>
          </div>
          <p className="text-xs text-zinc-500 mt-1.5 font-medium">{t.inPast7Days}</p>
        </div>

        {/* PRs Achieved */}
        <div className="bg-[#12131a] border border-[#262837] rounded-3xl p-5 sm:p-6 shadow-xl relative overflow-hidden group hover:border-zinc-600 transition-all">
          <div className="flex items-center justify-between text-zinc-400 mb-3">
            <span className="text-xs sm:text-sm font-bold uppercase tracking-wider">{t.prsAchieved}</span>
            <div className="w-9 h-9 rounded-xl bg-zinc-850 flex items-center justify-center text-zinc-300">
              <Trophy size={18} className="text-zinc-200" />
            </div>
          </div>
          <div className="text-2xl sm:text-4xl font-black text-white font-mono tracking-tight">
            {personalRecords.length}
          </div>
          <p className="text-xs text-zinc-500 mt-1.5 font-medium">{t.recordedPrs}</p>
        </div>
      </div>

      {/* Quick Launch Routine Splits */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg sm:text-xl font-black text-white uppercase tracking-wider">
              {t.quickLaunch}
            </h3>
            <p className="text-xs sm:text-sm text-zinc-400">{t.quickLaunchSub}</p>
          </div>
          <button
            onClick={onViewAllRoutines}
            className="text-xs sm:text-sm font-bold text-zinc-300 hover:text-white flex items-center gap-1.5 transition-colors"
          >
            <span>{isArabic ? 'عرض الكل' : 'View All'}</span>
            <ArrowRight size={15} className={isArabic ? 'rotate-180' : ''} />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {routines.slice(0, 3).map(routine => (
            <div
              key={routine.id}
              className="bg-[#13141c] border border-[#282a39] rounded-3xl p-5 sm:p-6 hover:border-zinc-500 transition-all flex flex-col justify-between group shadow-xl"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-mono uppercase tracking-wider px-2.5 py-1 rounded-lg bg-zinc-850 text-zinc-200 border border-zinc-700">
                    {routine.targetSplit}
                  </span>
                  <span className="text-xs sm:text-sm text-zinc-400 flex items-center gap-1 font-mono font-medium">
                    <Timer size={14} /> {routine.estimatedMinutes}m
                  </span>
                </div>
                <h4 className="text-base sm:text-lg font-black text-white group-hover:text-zinc-200 transition-colors">
                  {routine.name}
                </h4>
                <p className="text-xs sm:text-sm text-zinc-400 line-clamp-2 mt-2 leading-relaxed">
                  {routine.description}
                </p>
                <div className="mt-3.5 text-xs text-zinc-500 font-medium">
                  {routine.exercises.length} {isArabic ? 'تمارين مبرمجة' : 'exercises programmed'}
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-[#20222f] flex justify-end">
                <button
                  onClick={() => onStartRoutine(routine)}
                  className="px-5 py-2.5 rounded-2xl bg-zinc-850 hover:bg-white text-zinc-200 hover:text-black text-xs sm:text-sm font-extrabold transition-all flex items-center gap-2 shadow"
                >
                  <Play size={14} fill="currentColor" />
                  <span>{t.startRoutine}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Two Columns: PR Wall & Quick Power Tools */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: PR Wall of Fame (2 Cols) */}
        <div className="lg:col-span-2 bg-[#121319] border border-[#262837] rounded-3xl p-6 sm:p-7 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-zinc-850 flex items-center justify-center text-zinc-200">
                <Award size={18} />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-black text-white uppercase tracking-wider">
                  {t.strengthWall}
                </h3>
                <p className="text-xs sm:text-sm text-zinc-400">{t.strengthWallSub}</p>
              </div>
            </div>
            <button
              onClick={onOpen1RMCalc}
              className="text-xs sm:text-sm text-zinc-300 hover:text-white font-bold flex items-center gap-1"
            >
              <span>{t.oneRmCalc}</span>
              <ArrowRight size={14} className={isArabic ? 'rotate-180' : ''} />
            </button>
          </div>

          {personalRecords.length === 0 ? (
            <p className="text-sm text-zinc-500 py-8 text-center italic">
              {isArabic
                ? 'لا توجد أرقام قياسية مسجلة بعد. أكمل تمرينك الأول لبدء التسجيل!'
                : 'No personal records logged yet. Finish your first workout to establish your baseline!'}
            </p>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-2">
              {personalRecords.slice(0, 6).map(pr => (
                <div
                  key={pr.exerciseId}
                  className="p-4 rounded-2xl bg-[#171822] border border-[#272a3a] flex items-center justify-between hover:border-zinc-500 transition-colors shadow-sm"
                >
                  <div>
                    <h5 className="text-sm sm:text-base font-bold text-white truncate max-w-[190px]">
                      {pr.exerciseName}
                    </h5>
                    <div className="text-xs text-zinc-400 mt-1">
                      {isArabic ? 'أفضل رفعة:' : 'Best Lift:'} <span className="font-mono text-zinc-100 font-bold">{pr.maxWeight} {weightUnit}</span> × {pr.maxReps}
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-zinc-500 uppercase tracking-wider block font-semibold">1RM</span>
                    <span className="text-base sm:text-lg font-black font-mono text-white">
                      {pr.estimated1RM} <span className="text-xs font-normal text-zinc-400">{weightUnit}</span>
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right: Gym Utility Shortcuts */}
        <div className="bg-[#121319] border border-[#262837] rounded-3xl p-6 sm:p-7 shadow-xl flex flex-col justify-between space-y-5">
          <div>
            <h3 className="text-base sm:text-lg font-black text-white uppercase tracking-wider mb-1">
              {t.gymUtilityTools}
            </h3>
            <p className="text-xs sm:text-sm text-zinc-400 mb-4">
              {t.gymUtilityToolsSub}
            </p>

            <div className="space-y-3">
              <button
                onClick={onOpenOverloadGuide}
                className="w-full p-3.5 rounded-2xl bg-[#171824] border border-[#292c3d] hover:border-zinc-400 transition-all text-start flex items-center justify-between group"
              >
                <div className="flex items-center gap-3">
                  <TrendingUp size={18} className="text-zinc-200" />
                  <div>
                    <div className="text-sm font-bold text-white">{t.overloadAdvisor}</div>
                    <div className="text-xs text-zinc-400">{isArabic ? 'تحديد الوزن والتكرارات القادمة' : 'Determine next target load'}</div>
                  </div>
                </div>
                <ArrowRight size={15} className={`text-zinc-500 group-hover:text-white transition-colors ${isArabic ? 'rotate-180' : ''}`} />
              </button>

              <button
                onClick={onOpenPlateCalc}
                className="w-full p-3.5 rounded-2xl bg-[#171824] border border-[#292c3d] hover:border-zinc-400 transition-all text-start flex items-center justify-between group"
              >
                <div className="flex items-center gap-3">
                  <Layers size={18} className="text-zinc-200" />
                  <div>
                    <div className="text-sm font-bold text-white">{t.plateCalc}</div>
                    <div className="text-xs text-zinc-400">{isArabic ? 'حساب الأوزان على البار بدقة' : 'Barbell plate loading math'}</div>
                  </div>
                </div>
                <ArrowRight size={15} className={`text-zinc-500 group-hover:text-white transition-colors ${isArabic ? 'rotate-180' : ''}`} />
              </button>

              <button
                onClick={onOpen1RMCalc}
                className="w-full p-3.5 rounded-2xl bg-[#171824] border border-[#292c3d] hover:border-zinc-400 transition-all text-start flex items-center justify-between group"
              >
                <div className="flex items-center gap-3">
                  <Award size={18} className="text-zinc-200" />
                  <div>
                    <div className="text-sm font-bold text-white">{t.oneRmCalc}</div>
                    <div className="text-xs text-zinc-400">{isArabic ? 'حساب نسب الشدة التدريبية' : 'Intensity percentage generator'}</div>
                  </div>
                </div>
                <ArrowRight size={15} className={`text-zinc-500 group-hover:text-white transition-colors ${isArabic ? 'rotate-180' : ''}`} />
              </button>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-gradient-to-br from-zinc-900 to-black border border-zinc-800 text-xs sm:text-sm text-zinc-300 leading-relaxed">
            <span className="font-extrabold text-white block mb-1">{t.coachTip}</span>
            {t.coachTipText}
          </div>
        </div>
      </div>

      {/* Recent Workout Activity Card */}
      {latestWorkout && (
        <div className="bg-[#121319] border border-[#262837] rounded-3xl p-6 sm:p-7 shadow-xl space-y-3.5">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-mono uppercase tracking-wider text-zinc-400">{t.recentActivity}</span>
              <h4 className="text-base sm:text-lg font-black text-white">{latestWorkout.name}</h4>
            </div>
            <button
              onClick={onViewAllWorkouts}
              className="text-xs sm:text-sm text-zinc-300 hover:text-white font-bold flex items-center gap-1.5"
            >
              <span>{isArabic ? 'سجل التمارين' : 'Workout Log'}</span>
              <ArrowRight size={15} className={isArabic ? 'rotate-180' : ''} />
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-5 text-xs sm:text-sm text-zinc-300 pt-3 border-t border-[#20222f]">
            <span>{isArabic ? 'التاريخ:' : 'Date:'} <strong className="text-white font-mono">{new Date(latestWorkout.startTime).toLocaleDateString()}</strong></span>
            <span>•</span>
            <span>{isArabic ? 'المدة:' : 'Duration:'} <strong className="text-white font-mono">{latestWorkout.durationMinutes} min</strong></span>
            <span>•</span>
            <span>{isArabic ? 'الحجم:' : 'Volume:'} <strong className="text-white font-mono">{latestWorkout.totalVolume} {weightUnit}</strong></span>
            <span>•</span>
            <span>{isArabic ? 'عدد التمارين:' : 'Exercises:'} <strong className="text-white font-mono">{latestWorkout.exercises.length}</strong></span>
          </div>
        </div>
      )}
    </div>
  );
};

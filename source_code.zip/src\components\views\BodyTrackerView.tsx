import React, { useState } from 'react';
import { BodyMeasurement, WeightUnit } from '../../types/gym';
import {
  Scale,
  Plus,
  Trash2,
  TrendingDown,
  TrendingUp,
  X,
  Calendar,
  Activity,
  Award
} from 'lucide-react';

interface BodyTrackerViewProps {
  measurements: BodyMeasurement[];
  weightUnit: WeightUnit;
  onAddMeasurement: (item: BodyMeasurement) => void;
  onDeleteMeasurement: (id: string) => void;
}

export const BodyTrackerView: React.FC<BodyTrackerViewProps> = ({
  measurements,
  weightUnit,
  onAddMeasurement,
  onDeleteMeasurement
}) => {
  const [showLogModal, setShowLogModal] = useState(false);

  // New Measurement Form
  const [logDate, setLogDate] = useState(new Date().toISOString().split('T')[0]);
  const [logWeight, setLogWeight] = useState<number>(78);
  const [logBf, setLogBf] = useState<number | undefined>(undefined);
  const [logWaist, setLogWaist] = useState<number | undefined>(undefined);
  const [logArms, setLogArms] = useState<number | undefined>(undefined);
  const [logChest, setLogChest] = useState<number | undefined>(undefined);
  const [logNotes, setLogNotes] = useState('');

  // Sort measurements newest first
  const sorted = [...measurements].sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  const latest = sorted[0];
  const oldest = sorted[sorted.length - 1];

  const totalDiff = latest && oldest ? Math.round((latest.weight - oldest.weight) * 10) / 10 : 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!logWeight || logWeight <= 0) return;

    const newM: BodyMeasurement = {
      id: `bm-${Date.now()}`,
      date: logDate,
      weight: logWeight,
      bodyFatPercent: logBf,
      waistCm: logWaist,
      armsCm: logArms,
      chestCm: logChest,
      notes: logNotes.trim() || undefined
    };

    onAddMeasurement(newM);
    setShowLogModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-black text-white uppercase tracking-wider">
            Body Composition & Weight Tracker
          </h2>
          <p className="text-sm text-zinc-400">
            Track scale weight, body fat %, and tape measurements
          </p>
        </div>

        <button
          onClick={() => setShowLogModal(true)}
          className="px-6 py-3 rounded-2xl bg-white text-black font-black text-sm hover:bg-zinc-200 transition-all flex items-center gap-2 self-start sm:self-auto shadow-lg active:scale-95"
        >
          <Plus size={16} />
          <span>Log Measurement</span>
        </button>
      </div>

      {/* 3 Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div className="bg-[#121319] border border-[#262837] rounded-3xl p-6 shadow-xl">
          <span className="text-xs sm:text-sm font-bold text-zinc-400 uppercase tracking-wider block mb-1.5">
            Current Scale Weight
          </span>
          <div className="text-3xl sm:text-4xl font-black text-white font-mono">
            {latest ? `${latest.weight} ${weightUnit}` : '--'}
          </div>
          <p className="text-xs text-zinc-500 mt-2 font-medium">
            Last logged {latest ? latest.date : 'never'}
          </p>
        </div>

        <div className="bg-[#121319] border border-[#262837] rounded-3xl p-6 shadow-xl">
          <span className="text-xs sm:text-sm font-bold text-zinc-400 uppercase tracking-wider block mb-1.5">
            Net Weight Delta
          </span>
          <div className="text-3xl sm:text-4xl font-black font-mono flex items-center gap-1.5 text-white">
            {totalDiff > 0 ? (
              <span className="text-zinc-100 font-black">+{totalDiff} {weightUnit}</span>
            ) : totalDiff < 0 ? (
              <span className="text-zinc-100 font-black">{totalDiff} {weightUnit}</span>
            ) : (
              <span>0.0 {weightUnit}</span>
            )}
          </div>
          <p className="text-xs text-zinc-500 mt-2 font-medium">
            From earliest logged check-in
          </p>
        </div>

        <div className="bg-[#121319] border border-[#262837] rounded-3xl p-6 shadow-xl">
          <span className="text-xs sm:text-sm font-bold text-zinc-400 uppercase tracking-wider block mb-1.5">
            Body Fat Estimate
          </span>
          <div className="text-3xl sm:text-4xl font-black text-white font-mono">
            {latest?.bodyFatPercent ? `${latest.bodyFatPercent}%` : '--'}
          </div>
          <p className="text-xs text-zinc-500 mt-2 font-medium">
            {latest?.bodyFatPercent ? 'Calculated via calipers / DEXA' : 'Not recorded'}
          </p>
        </div>
      </div>

      {/* Measurement History Table */}
      <div className="bg-[#121319] border border-[#262837] rounded-3xl overflow-hidden shadow-xl">
        <div className="p-5 sm:p-6 border-b border-[#232534] flex items-center justify-between">
          <h3 className="text-base sm:text-lg font-black text-white uppercase tracking-wider">
            Check-In History
          </h3>
          <span className="text-xs sm:text-sm text-zinc-400 font-mono font-bold">
            {sorted.length} Entries
          </span>
        </div>

        {sorted.length === 0 ? (
          <p className="p-10 text-center text-sm text-zinc-500 italic">No body measurements recorded yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead>
                <tr className="bg-[#171824] text-zinc-400 text-xs uppercase tracking-wider border-b border-[#232534]">
                  <th className="py-3.5 px-5">Date</th>
                  <th className="py-3.5 px-5">Weight ({weightUnit})</th>
                  <th className="py-3.5 px-5">Body Fat %</th>
                  <th className="py-3.5 px-5 hidden sm:table-cell">Waist</th>
                  <th className="py-3.5 px-5 hidden sm:table-cell">Arms</th>
                  <th className="py-3.5 px-5 hidden sm:table-cell">Chest</th>
                  <th className="py-3.5 px-5 hidden md:table-cell">Notes</th>
                  <th className="py-3.5 px-5 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1e202d]">
                {sorted.map(m => (
                  <tr key={m.id} className="hover:bg-[#161824] transition-colors">
                    <td className="py-3 px-5 font-mono text-zinc-200 font-semibold">
                      {m.date}
                    </td>
                    <td className="py-3 px-5 font-mono font-black text-white text-base">
                      {m.weight} {weightUnit}
                    </td>
                    <td className="py-3 px-5 font-mono text-zinc-300">
                      {m.bodyFatPercent ? `${m.bodyFatPercent}%` : '-'}
                    </td>
                    <td className="py-3 px-5 font-mono text-zinc-400 hidden sm:table-cell">
                      {m.waistCm ? `${m.waistCm} cm` : '-'}
                    </td>
                    <td className="py-3 px-5 font-mono text-zinc-400 hidden sm:table-cell">
                      {m.armsCm ? `${m.armsCm} cm` : '-'}
                    </td>
                    <td className="py-3 px-5 font-mono text-zinc-400 hidden sm:table-cell">
                      {m.chestCm ? `${m.chestCm} cm` : '-'}
                    </td>
                    <td className="py-3 px-5 text-zinc-400 text-xs truncate max-w-xs hidden md:table-cell italic">
                      {m.notes || '-'}
                    </td>
                    <td className="py-3 px-5 text-right">
                      <button
                        onClick={() => {
                          if (confirm(`Delete measurement for ${m.date}?`)) {
                            onDeleteMeasurement(m.id);
                          }
                        }}
                        className="p-1.5 rounded-lg text-zinc-500 hover:text-red-400 transition-colors"
                        title="Delete Entry"
                      >
                        <Trash2 size={16} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Log Measurement Modal */}
      {showLogModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm">
          <div className="bg-[#111218] border border-[#2b2d3d] rounded-3xl w-full max-w-md overflow-hidden shadow-2xl">
            <div className="p-5 border-b border-[#222432] flex items-center justify-between">
              <h3 className="text-base font-black text-white">Log Body Check-In</h3>
              <button
                onClick={() => setShowLogModal(false)}
                className="p-1.5 rounded-xl text-zinc-400 hover:text-white"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-5 space-y-4 text-sm">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
                    Date
                  </label>
                  <input
                    type="date"
                    required
                    value={logDate}
                    onChange={e => setLogDate(e.target.value)}
                    className="w-full bg-[#181923] border border-[#2d2f40] rounded-2xl px-3.5 py-2.5 text-white font-mono focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
                    Weight ({weightUnit}) *
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    value={logWeight || ''}
                    onChange={e => setLogWeight(parseFloat(e.target.value) || 0)}
                    className="w-full bg-[#181923] border border-[#2d2f40] rounded-2xl px-3.5 py-2.5 text-white font-mono font-black focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
                    Body Fat %
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    placeholder="e.g. 15.5"
                    value={logBf || ''}
                    onChange={e => setLogBf(parseFloat(e.target.value) || undefined)}
                    className="w-full bg-[#181923] border border-[#2d2f40] rounded-2xl px-3.5 py-2.5 text-white font-mono focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
                    Waist (cm)
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    placeholder="e.g. 82.5"
                    value={logWaist || ''}
                    onChange={e => setLogWaist(parseFloat(e.target.value) || undefined)}
                    className="w-full bg-[#181923] border border-[#2d2f40] rounded-2xl px-3.5 py-2.5 text-white font-mono focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
                    Arms (cm)
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    placeholder="e.g. 38.0"
                    value={logArms || ''}
                    onChange={e => setLogArms(parseFloat(e.target.value) || undefined)}
                    className="w-full bg-[#181923] border border-[#2d2f40] rounded-2xl px-3.5 py-2.5 text-white font-mono focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
                    Chest (cm)
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    placeholder="e.g. 103"
                    value={logChest || ''}
                    onChange={e => setLogChest(parseFloat(e.target.value) || undefined)}
                    className="w-full bg-[#181923] border border-[#2d2f40] rounded-2xl px-3.5 py-2.5 text-white font-mono focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-300 uppercase tracking-wider mb-1.5">
                  Notes
                </label>
                <input
                  type="text"
                  placeholder="e.g. Post-cardio morning weigh in, fasted"
                  value={logNotes}
                  onChange={e => setLogNotes(e.target.value)}
                  className="w-full bg-[#181923] border border-[#2d2f40] rounded-2xl px-3.5 py-2.5 text-white focus:outline-none"
                />
              </div>

              <div className="pt-3 border-t border-[#222432] flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowLogModal(false)}
                  className="px-5 py-2.5 rounded-2xl bg-zinc-800 text-zinc-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-2xl bg-white text-black font-black hover:bg-zinc-200"
                >
                  Save Check-In
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

import {
  CompletedWorkout,
  Routine,
  ExerciseDefinition,
  BodyMeasurement,
  PersonalRecord,
  WeightUnit,
  WorkoutExercise
} from '../types/gym';
import { DEFAULT_EXERCISES } from '../data/defaultExercises';
import { DEFAULT_ROUTINES } from '../data/defaultRoutines';
import { SAMPLE_WORKOUTS, SAMPLE_MEASUREMENTS } from '../data/sampleHistory';
import { calculate1RM } from './calculators';

const KEYS = {
  WORKOUTS: 'infinity_gym_workouts_v1',
  ROUTINES: 'infinity_gym_routines_v1',
  EXERCISES: 'infinity_gym_exercises_v1',
  MEASUREMENTS: 'infinity_gym_measurements_v1',
  UNIT: 'infinity_gym_unit_v1',
  ACTIVE_WORKOUT: 'infinity_gym_active_workout_v1'
};

export interface ActiveWorkoutState {
  id: string;
  name: string;
  routineId?: string;
  startTime: string;
  elapsedSeconds: number;
  exercises: WorkoutExercise[];
  notes?: string;
}

// Load Workouts
export function loadWorkouts(): CompletedWorkout[] {
  try {
    const raw = localStorage.getItem(KEYS.WORKOUTS);
    if (!raw) {
      localStorage.setItem(KEYS.WORKOUTS, JSON.stringify(SAMPLE_WORKOUTS));
      return SAMPLE_WORKOUTS;
    }
    return JSON.parse(raw);
  } catch (err) {
    console.error('Failed to parse workouts from storage', err);
    return SAMPLE_WORKOUTS;
  }
}

export function saveWorkouts(workouts: CompletedWorkout[]) {
  try {
    localStorage.setItem(KEYS.WORKOUTS, JSON.stringify(workouts));
  } catch (err) {
    console.error('Failed to save workouts', err);
  }
}

// Load Routines
export function loadRoutines(): Routine[] {
  try {
    const raw = localStorage.getItem(KEYS.ROUTINES);
    if (!raw) {
      localStorage.setItem(KEYS.ROUTINES, JSON.stringify(DEFAULT_ROUTINES));
      return DEFAULT_ROUTINES;
    }
    return JSON.parse(raw);
  } catch (err) {
    console.error('Failed to parse routines', err);
    return DEFAULT_ROUTINES;
  }
}

export function saveRoutines(routines: Routine[]) {
  try {
    localStorage.setItem(KEYS.ROUTINES, JSON.stringify(routines));
  } catch (err) {
    console.error('Failed to save routines', err);
  }
}

// Load Exercises
export function loadExercises(): ExerciseDefinition[] {
  try {
    const raw = localStorage.getItem(KEYS.EXERCISES);
    if (!raw) {
      localStorage.setItem(KEYS.EXERCISES, JSON.stringify(DEFAULT_EXERCISES));
      return DEFAULT_EXERCISES;
    }
    const saved = JSON.parse(raw) as ExerciseDefinition[];
    // Ensure all default exercises exist in case user updated
    const savedIds = new Set(saved.map(e => e.id));
    const merged = [...saved];
    for (const def of DEFAULT_EXERCISES) {
      if (!savedIds.has(def.id)) {
        merged.push(def);
      }
    }
    return merged;
  } catch (err) {
    console.error('Failed to parse exercises', err);
    return DEFAULT_EXERCISES;
  }
}

export function saveExercises(exercises: ExerciseDefinition[]) {
  try {
    localStorage.setItem(KEYS.EXERCISES, JSON.stringify(exercises));
  } catch (err) {
    console.error('Failed to save exercises', err);
  }
}

// Load Body Measurements
export function loadMeasurements(): BodyMeasurement[] {
  try {
    const raw = localStorage.getItem(KEYS.MEASUREMENTS);
    if (!raw) {
      localStorage.setItem(KEYS.MEASUREMENTS, JSON.stringify(SAMPLE_MEASUREMENTS));
      return SAMPLE_MEASUREMENTS;
    }
    return JSON.parse(raw);
  } catch (err) {
    console.error('Failed to parse measurements', err);
    return SAMPLE_MEASUREMENTS;
  }
}

export function saveMeasurements(measurements: BodyMeasurement[]) {
  try {
    localStorage.setItem(KEYS.MEASUREMENTS, JSON.stringify(measurements));
  } catch (err) {
    console.error('Failed to save measurements', err);
  }
}

// Unit
export function loadWeightUnit(): WeightUnit {
  try {
    const val = localStorage.getItem(KEYS.UNIT);
    return val === 'lbs' ? 'lbs' : 'kg';
  } catch {
    return 'kg';
  }
}

export function saveWeightUnit(unit: WeightUnit) {
  try {
    localStorage.setItem(KEYS.UNIT, unit);
  } catch (err) {
    console.error('Failed to save unit', err);
  }
}

// Active workout
export function loadActiveWorkout(): ActiveWorkoutState | null {
  try {
    const raw = localStorage.getItem(KEYS.ACTIVE_WORKOUT);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

export function saveActiveWorkout(state: ActiveWorkoutState | null) {
  try {
    if (state === null) {
      localStorage.removeItem(KEYS.ACTIVE_WORKOUT);
    } else {
      localStorage.setItem(KEYS.ACTIVE_WORKOUT, JSON.stringify(state));
    }
  } catch (err) {
    console.error('Failed to save active workout', err);
  }
}

// Compute Personal Records (PRs)
export function computePersonalRecords(workouts: CompletedWorkout[]): PersonalRecord[] {
  const prMap = new Map<string, PersonalRecord>();

  for (const workout of workouts) {
    for (const ex of workout.exercises) {
      for (const set of ex.sets) {
        if (!set.completed || set.type === 'Warmup' || set.weight <= 0 || set.reps <= 0) {
          continue;
        }

        const est1RM = calculate1RM(set.weight, set.reps).average;
        const current = prMap.get(ex.exerciseId);

        if (!current) {
          prMap.set(ex.exerciseId, {
            exerciseId: ex.exerciseId,
            exerciseName: ex.exerciseName,
            maxWeight: set.weight,
            maxReps: set.reps,
            estimated1RM: est1RM,
            date: workout.startTime
          });
        } else {
          // If this set achieves a higher estimated 1RM, update
          if (est1RM > current.estimated1RM) {
            current.estimated1RM = est1RM;
            current.maxWeight = Math.max(current.maxWeight, set.weight);
            current.maxReps = Math.max(current.maxReps, set.reps);
            current.date = workout.startTime;
          } else {
            if (set.weight > current.maxWeight) {
              current.maxWeight = set.weight;
            }
            if (set.reps > current.maxReps && set.weight >= current.maxWeight * 0.9) {
              current.maxReps = set.reps;
            }
          }
        }
      }
    }
  }

  return Array.from(prMap.values()).sort((a, b) => b.estimated1RM - a.estimated1RM);
}

// Export and Import
export function exportAllData() {
  const data = {
    appName: 'Infinity Gym',
    version: '1.0.0',
    exportDate: new Date().toISOString(),
    workouts: loadWorkouts(),
    routines: loadRoutines(),
    exercises: loadExercises(),
    measurements: loadMeasurements(),
    unit: loadWeightUnit()
  };

  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `infinity-gym-backup-${new Date().toISOString().split('T')[0]}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

export function importAllData(jsonStr: string): boolean {
  try {
    const data = JSON.parse(jsonStr);
    if (Array.isArray(data.workouts)) saveWorkouts(data.workouts);
    if (Array.isArray(data.routines)) saveRoutines(data.routines);
    if (Array.isArray(data.exercises)) saveExercises(data.exercises);
    if (Array.isArray(data.measurements)) saveMeasurements(data.measurements);
    if (data.unit === 'kg' || data.unit === 'lbs') saveWeightUnit(data.unit);
    return true;
  } catch (err) {
    console.error('Import failed', err);
    return false;
  }
}

export function resetAllDataToDefault() {
  localStorage.setItem(KEYS.WORKOUTS, JSON.stringify(SAMPLE_WORKOUTS));
  localStorage.setItem(KEYS.ROUTINES, JSON.stringify(DEFAULT_ROUTINES));
  localStorage.setItem(KEYS.EXERCISES, JSON.stringify(DEFAULT_EXERCISES));
  localStorage.setItem(KEYS.MEASUREMENTS, JSON.stringify(SAMPLE_MEASUREMENTS));
  localStorage.setItem(KEYS.UNIT, 'kg');
  localStorage.removeItem(KEYS.ACTIVE_WORKOUT);
}
